const { pool } = require('./mysql');
const productIcons = require('../items/productIcons');

// =====================================================
//  reckmarket_items_mysql.js
//
//  كل وحدة في المخزون صف منفرد برقم تسلسلي خاص
//  ELECTRONICS / POLICE / WEAPONS / DOCUMENTS → serial منفرد
//  باقي المنتجات → serial منفرد كمان (نفس النظام)
//
//  Table: reckmarket_stock
//    id           INT PK AUTO_INCREMENT
//    item_serial  VARCHAR(20) UNIQUE     رقم تسلسلي فريد لكل وحدة
//    item_name    VARCHAR(100)
//    category     VARCHAR(100)
//    price        DECIMAL(10,2)
//    expiry_date  DATE
//    imported_at  DATETIME DEFAULT NOW()
// =====================================================

// ================= ENSURE TABLE =================
async function ensureTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS reckmarket_stock (
      id          INT            NOT NULL AUTO_INCREMENT,
      item_serial VARCHAR(20)    NOT NULL,
      item_name   VARCHAR(100)   NOT NULL,
      category    VARCHAR(100)   NOT NULL DEFAULT 'misc',
      price       DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
      expiry_date DATE           NULL DEFAULT NULL,
      imported_at DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_serial    (item_serial),
      INDEX idx_item_name (item_name),
      INDEX idx_category  (category),
      INDEX idx_expiry    (expiry_date)
    )
  `);
}

ensureTable().catch(err => console.error('[reckmarket_stock] ensureTable failed:', err));

// ================= HELPERS =================
async function generateUniqueStoreSerial() {
  let serial;
  let exists = true;

  while (exists) {
    serial = `RM${Math.floor(10000000 + Math.random() * 90000000)}`;
    const [rows] = await pool.query(
      `SELECT item_serial FROM reckmarket_stock WHERE item_serial = ?`,
      [serial]
    );
    exists = rows.length > 0;
  }

  return serial;
}

function calcExpiryDate(itemName) {
  const days = productIcons[itemName]?.expiry ?? null;
  if (!days || days <= 0) return null;
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

// ================= IMPORT ITEMS (استيراد) =================
// amount = عدد الوحدات المستوردة، كل وحدة برقم تسلسلي خاص
async function importItems(itemName, category, price, amount = 1) {
  if (!itemName || amount < 1) return [];

  const expiryDate = calcExpiryDate(itemName);
  const serials    = [];

  for (let i = 0; i < amount; i++) {
    const serial = await generateUniqueStoreSerial();

    await pool.query(
      `INSERT INTO reckmarket_stock (item_serial, item_name, category, price, expiry_date)
       VALUES (?, ?, ?, ?, ?)`,
      [serial, itemName, category, price, expiryDate]
    );

    serials.push(serial);
  }

  return serials;
}

// ================= GET STOCK SUMMARY (للعرض) =================
// يرجع قائمة موحدة: اسم المنتج + الكمية المتاحة + أرخص سعر
async function getStockSummary() {
  const [rows] = await pool.query(`
    SELECT
      item_name,
      category,
      COUNT(*)          AS quantity,
      MIN(price)        AS price,
      MIN(expiry_date)  AS nearest_expiry
    FROM reckmarket_stock
    WHERE expiry_date IS NULL OR expiry_date >= CURDATE()
    GROUP BY item_name, category
    ORDER BY category ASC, item_name ASC
  `);
  return rows;
}

// ================= GET STOCK CATEGORIES =================
async function getStockCategories() {
  const [rows] = await pool.query(`
    SELECT DISTINCT category
    FROM reckmarket_stock
    WHERE expiry_date IS NULL OR expiry_date >= CURDATE()
    ORDER BY category ASC
  `);
  return rows.map(r => r.category);
}

// ================= GET ITEMS BY CATEGORY (للشراء) =================
async function getStockByCategory(category) {
  const [rows] = await pool.query(`
    SELECT
      item_name,
      COUNT(*)         AS quantity,
      MIN(price)       AS price,
      MIN(expiry_date) AS nearest_expiry
    FROM reckmarket_stock
    WHERE category = ?
      AND (expiry_date IS NULL OR expiry_date >= CURDATE())
    GROUP BY item_name
    ORDER BY item_name ASC
  `, [category]);
  return rows;
}

// ================= GET ONE UNIT (أرخص وحدة من المنتج) =================
async function getOneUnit(itemName) {
  const [rows] = await pool.query(`
    SELECT * FROM reckmarket_stock
    WHERE item_name = ?
      AND (expiry_date IS NULL OR expiry_date >= CURDATE())
    ORDER BY price ASC, imported_at ASC
    LIMIT 1
  `, [itemName]);
  return rows[0] || null;
}

// ================= SELL UNIT (يحذف الوحدة من المخزن) =================
async function sellUnit(itemSerial) {
  const [rows] = await pool.query(
    `SELECT * FROM reckmarket_stock WHERE item_serial = ? LIMIT 1`,
    [itemSerial]
  );
  if (!rows.length) return null;

  await pool.query(
    `DELETE FROM reckmarket_stock WHERE item_serial = ? LIMIT 1`,
    [itemSerial]
  );

  return rows[0];
}

// ================= UPDATE PRICE =================
async function updateItemPrice(itemName, newPrice) {
  await pool.query(
    `UPDATE reckmarket_stock SET price = ? WHERE item_name = ?`,
    [newPrice, itemName]
  );
}

// ================= REMOVE EXPIRED =================
async function removeExpiredItems() {
  const [result] = await pool.query(
    `DELETE FROM reckmarket_stock WHERE expiry_date IS NOT NULL AND expiry_date < CURDATE()`
  );
  return result.affectedRows;
}

// ================= GET ALL STOCK (كامل للإدارة) =================
async function getAllStock() {
  const [rows] = await pool.query(`
    SELECT * FROM reckmarket_stock
    ORDER BY category ASC, item_name ASC, imported_at ASC
  `);
  return rows;
}

// ================= GET STOCK COUNT =================
async function getStockCount(itemName) {
  const [rows] = await pool.query(`
    SELECT COUNT(*) AS qty FROM reckmarket_stock
    WHERE item_name = ?
      AND (expiry_date IS NULL OR expiry_date >= CURDATE())
  `, [itemName]);
  return rows[0]?.qty ?? 0;
}

module.exports = {
  ensureTable,
  importItems,
  getStockSummary,
  getStockCategories,
  getStockByCategory,
  getOneUnit,
  sellUnit,
  updateItemPrice,
  removeExpiredItems,
  getAllStock,
  getStockCount,
  calcExpiryDate
};