const { pool } = require('./mysql');

// ================= ENSURE TABLE =================
async function ensureTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS reckmarket (
      owner_user_id VARCHAR(30) NOT NULL,
      owner_id      VARCHAR(20) NOT NULL,
      PRIMARY KEY (owner_user_id)
    )
  `);
}

ensureTable().catch(err => console.error('[reckmarket] ensureTable failed:', err));

// ================= SET MARKET OWNER =================
async function setMarketOwner(userDiscordId, nationalId) {
  await pool.query(
    `INSERT INTO reckmarket (owner_user_id, owner_id)
     VALUES (?, ?)
     ON DUPLICATE KEY UPDATE owner_id = VALUES(owner_id)`,
    [userDiscordId, nationalId]
  );
}

// ================= GET MARKET OWNER =================
async function getMarketOwner(userDiscordId) {
  const [rows] = await pool.query(
    `SELECT * FROM reckmarket WHERE owner_user_id = ?`,
    [userDiscordId]
  );
  return rows[0] || null;
}

// ================= GET CHARACTER BY NATIONAL ID =================
async function getCharacterByNationalId(nationalId) {
  const [rows] = await pool.query(
    `SELECT * FROM characters WHERE national_id = ?`,
    [nationalId]
  );
  return rows[0] || null;
}

// ================= GET ONLINE CHARACTER =================
async function getOnlineCharacter(userDiscordId) {
  const [rows] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
    [userDiscordId]
  );
  return rows[0] || null;
}

// ================= UPDATE CHARACTER JOB =================
async function updateCharacterJob(nationalId, newJob) {
  const [result] = await pool.query(
    `UPDATE characters SET job = ? WHERE national_id = ?`,
    [newJob, nationalId]
  );
  return result.affectedRows > 0;
}

// ================= GET MARKET EMPLOYEES =================
async function getMarketEmployees() {
  const [rows] = await pool.query(
    `SELECT * FROM characters
     WHERE job IN ('market employee', 'market manager')
     ORDER BY job DESC, firstname ASC`
  );
  return rows;
}

module.exports = {
  setMarketOwner,
  getMarketOwner,
  getCharacterByNationalId,
  getOnlineCharacter,
  updateCharacterJob,
  getMarketEmployees
};