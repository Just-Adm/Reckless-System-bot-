const { pool } = require('./mysql');

// ================= ENSURE TABLES =================
async function ensureTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS phone_data (
      serial            VARCHAR(50)   NOT NULL,
      owner_user_id     VARCHAR(30)   NOT NULL,
      owner_national_id VARCHAR(20)   NOT NULL,
      char_number       INT           NOT NULL,
      phone_number      VARCHAR(20)   NOT NULL,
      language          VARCHAR(5)    NOT NULL DEFAULT 'en',
      passcode          VARCHAR(10)   NULL DEFAULT NULL,
      setup_done        TINYINT(1)    NOT NULL DEFAULT 0,
      created_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (serial),
      UNIQUE KEY uq_phone_number (phone_number),
      INDEX idx_owner_user (owner_user_id),
      INDEX idx_owner_nat  (owner_national_id)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS phone_setup_temp (
      user_id    VARCHAR(30)  NOT NULL,
      language   VARCHAR(5)   NOT NULL,
      passcode   VARCHAR(10)  NOT NULL,
      updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id)
    )
  `);

  // تحقق من أعمدة characters المرتبطة بالهاتف
  const [columns] = await pool.query(`SHOW COLUMNS FROM characters`);
  const cols = columns.map(c => c.Field);

  if (!cols.includes('phone_number')) {
    await pool.query(`ALTER TABLE characters ADD COLUMN phone_number VARCHAR(20) NULL DEFAULT NULL`);
    console.log('[phone] Added missing column phone_number to characters');
  }
  if (!cols.includes('phone_serial')) {
    await pool.query(`ALTER TABLE characters ADD COLUMN phone_serial VARCHAR(50) NULL DEFAULT NULL`);
    console.log('[phone] Added missing column phone_serial to characters');
  }
}

ensureTables().catch(err => console.error('[phone] ensureTables failed:', err));

// ================= GET PHONE =================
async function getPhone(serial) {
  if (!serial) return null;
  const [rows] = await pool.query(
    `SELECT * FROM phone_data WHERE serial = ? LIMIT 1`,
    [serial]
  );
  return rows[0] || null;
}

// ================= GENERATE UNIQUE PHONE NUMBER =================
async function generateUniqueUSPhoneNumber() {
  let phoneNumber;
  let exists = true;

  while (exists) {
    const areaCode  = Math.floor(200 + Math.random() * 800);
    const exchange  = Math.floor(200 + Math.random() * 800);
    const subscriber = Math.floor(1000 + Math.random() * 9000);
    phoneNumber = `+1 (${areaCode}) ${exchange}-${subscriber}`;
    const [rows] = await pool.query(
      `SELECT phone_number FROM phone_data WHERE phone_number = ? LIMIT 1`,
      [phoneNumber]
    );
    exists = rows.length > 0;
  }

  return phoneNumber;
}

// ================= CREATE PHONE =================
async function createPhone(data) {
  await pool.query(
    `INSERT INTO phone_data (serial, owner_user_id, owner_national_id, char_number, phone_number)
     VALUES (?, ?, ?, ?, ?)`,
    [data.serial, data.ownerUserId, data.ownerNationalId, data.charNumber, data.phoneNumber]
  );

  return {
    serial:           data.serial,
    owner_user_id:    data.ownerUserId,
    owner_national_id: data.ownerNationalId,
    char_number:      data.charNumber,
    phone_number:     data.phoneNumber,
    language:         'en',
    passcode:         null,
    setup_done:       0
  };
}

// ================= SETUP TEMP =================
async function saveTempSetup(userId, data) {
  await pool.query(
    `INSERT INTO phone_setup_temp (user_id, language, passcode)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE language = VALUES(language), passcode = VALUES(passcode)`,
    [userId, data.lang, data.passcode]
  );
  return true;
}

async function getTempSetup(userId) {
  const [rows] = await pool.query(
    `SELECT language AS lang, passcode FROM phone_setup_temp WHERE user_id = ? LIMIT 1`,
    [userId]
  );
  return rows[0] || null;
}

async function clearTempSetup(userId) {
  await pool.query(`DELETE FROM phone_setup_temp WHERE user_id = ?`, [userId]);
  return true;
}

// ================= FINALIZE SETUP =================
async function finalizeSetup(serial, data) {
  await pool.query(
    `UPDATE phone_data SET language = ?, passcode = ?, setup_done = 1 WHERE serial = ?`,
    [data.language, data.passcode, serial]
  );
  return true;
}

module.exports = {
  getPhone,
  generateUniqueUSPhoneNumber,
  createPhone,
  saveTempSetup,
  getTempSetup,
  clearTempSetup,
  finalizeSetup
};