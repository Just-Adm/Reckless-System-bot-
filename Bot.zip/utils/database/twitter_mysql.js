const { pool } = require('./mysql');

// ================= ENSURE TABLES =================
async function ensureTable() {
  // 1. جدول الحسابات (مع حقل الثيم المضاف حديثاً)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS x_accounts (
      id           INT           NOT NULL AUTO_INCREMENT,
      user_id      VARCHAR(30)   NOT NULL,
      char_number  INT           NOT NULL,
      phone_serial VARCHAR(50)   NULL DEFAULT NULL,
      display_name VARCHAR(50)   NOT NULL,
      username     VARCHAR(20)   NOT NULL,
      bio          VARCHAR(40)   NULL DEFAULT NULL,
      avatar_url   TEXT          NULL DEFAULT NULL,
      theme        VARCHAR(10)   NOT NULL DEFAULT 'light', -- 'light' or 'dark'
      followers    INT           NOT NULL DEFAULT 0,
      following    INT           NOT NULL DEFAULT 0,
      created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_username (username),
      INDEX idx_owner (user_id, char_number),
      INDEX idx_phone (phone_serial)
    )
  `);

  // 2. جدول التغريدات
  await pool.query(`
    CREATE TABLE IF NOT EXISTS x_posts (
      id         INT      NOT NULL AUTO_INCREMENT,
      author_id  INT      NOT NULL,
      content    TEXT     NOT NULL,
      image_url  TEXT     NULL DEFAULT NULL,
      likes      INT      NOT NULL DEFAULT 0,
      reposts    INT      NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      INDEX idx_author  (author_id),
      INDEX idx_created (created_at)
    )
  `);

  // 3. جدول تسجيل الإعجابات
  await pool.query(`
    CREATE TABLE IF NOT EXISTS x_likes (
      account_id INT NOT NULL,
      post_id    INT NOT NULL,
      PRIMARY KEY (account_id, post_id)
    )
  `);

  // 4. جدول المتابعات
  await pool.query(`
    CREATE TABLE IF NOT EXISTS x_follows (
      follower_id  INT      NOT NULL,
      following_id INT      NOT NULL,
      created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (follower_id, following_id)
    )
  `);
}

// تشغيل دالة التحقق من الجداول عند بدء التشغيل
ensureTable().catch(err => console.error('[x] ensureTable failed:', err));

// ── Accounts ──────────────────────────────────────────────────────────────────

async function getAccountByPhone(phoneSerial) {
  const [rows] = await pool.query(
    `SELECT * FROM x_accounts WHERE phone_serial = ? LIMIT 1`,
    [phoneSerial]
  );
  return rows[0] || null;
}

async function getAccountByUsername(username) {
  const [rows] = await pool.query(
    `SELECT * FROM x_accounts WHERE username = ? LIMIT 1`,
    [username]
  );
  return rows[0] || null;
}

async function getAccountById(id) {
  const [rows] = await pool.query(
    `SELECT * FROM x_accounts WHERE id = ? LIMIT 1`,
    [id]
  );
  return rows[0] || null;
}

async function createAccount(userId, charNumber, phoneSerial, data) {
  const existing = await getAccountByUsername(data.username);
  if (existing) return { error: 'USERNAME_TAKEN' };

  // فصل الهاتف القديم لو كان مرتبط بحساب آخر
  await pool.query(
    `UPDATE x_accounts SET phone_serial = NULL WHERE phone_serial = ?`,
    [phoneSerial]
  );

  const [result] = await pool.query(
    `INSERT INTO x_accounts (user_id, char_number, phone_serial, display_name, username, bio, avatar_url, theme)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'light')`,
    [userId, charNumber, phoneSerial, data.display_name, data.username, data.bio || null, data.avatar_url || null]
  );

  return { id: result.insertId };
}

async function linkAccountToPhone(accountId, newPhoneSerial) {
  // فصل الهاتف الجديد من أي حساب آخر
  await pool.query(
    `UPDATE x_accounts SET phone_serial = NULL WHERE phone_serial = ? AND id != ?`,
    [newPhoneSerial, accountId]
  );
  await pool.query(
    `UPDATE x_accounts SET phone_serial = ? WHERE id = ?`,
    [newPhoneSerial, accountId]
  );
  return true;
}

async function signOut(phoneSerial) {
  await pool.query(
    `UPDATE x_accounts SET phone_serial = NULL WHERE phone_serial = ?`,
    [phoneSerial]
  );
  return true;
}

// دالة تحديث الثيم المختار (Dark/Light)
async function updateTheme(accountId, theme) {
  await pool.query(`UPDATE x_accounts SET theme = ? WHERE id = ?`, [theme, accountId]);
  return true;
}

// دالة تحديث البيانات الأساسية للملف الشخصي (الإسم والنبذة)
async function updateProfileData(accountId, displayName, bio) {
  await pool.query(`UPDATE x_accounts SET display_name = ?, bio = ? WHERE id = ?`, [displayName, bio, accountId]);
  return true;
}

// ── Posts ──────────────────────────────────────────────────────────────────────

async function createPost(authorId, content, imageUrl = null) {
  const [result] = await pool.query(
    `INSERT INTO x_posts (author_id, content, image_url) VALUES (?, ?, ?)`,
    [authorId, content, imageUrl]
  );
  return result.insertId;
}

async function getPosts(limit = 5, offset = 0) {
  const [rows] = await pool.query(`
    SELECT p.*, a.display_name, a.username, a.avatar_url
    FROM x_posts p
    JOIN x_accounts a ON p.author_id = a.id
    ORDER BY p.created_at DESC
    LIMIT ? OFFSET ?
  `, [limit, offset]);
  return rows;
}

async function getUserPosts(accountId, limit = 5, offset = 0) {
  const [rows] = await pool.query(`
    SELECT p.*, a.display_name, a.username, a.avatar_url
    FROM x_posts p
    JOIN x_accounts a ON p.author_id = a.id
    WHERE p.author_id = ?
    ORDER BY p.created_at DESC
    LIMIT ? OFFSET ?
  `, [accountId, limit, offset]);
  return rows;
}

// ── Likes & Reposts ─────────────────────────────────────────────────────────────

async function toggleLike(accountId, postId) {
  const [rows] = await pool.query(
    `SELECT 1 FROM x_likes WHERE account_id = ? AND post_id = ?`,
    [accountId, postId]
  );
  if (rows.length) {
    await pool.query(`DELETE FROM x_likes WHERE account_id = ? AND post_id = ?`, [accountId, postId]);
    await pool.query(`UPDATE x_posts SET likes = GREATEST(0, likes - 1) WHERE id = ?`, [postId]);
    return 'UNLIKED';
  }
  await pool.query(`INSERT INTO x_likes (account_id, post_id) VALUES (?, ?)`, [accountId, postId]);
  await pool.query(`UPDATE x_posts SET likes = likes + 1 WHERE id = ?`, [postId]);
  return 'LIKED';
}

async function hasLiked(accountId, postId) {
  const [rows] = await pool.query(
    `SELECT 1 FROM x_likes WHERE account_id = ? AND post_id = ?`,
    [accountId, postId]
  );
  return rows.length > 0;
}

// ── Search ─────────────────────────────────────────────────────────────────────

async function searchAccounts(query) {
  const [rows] = await pool.query(`
    SELECT * FROM x_accounts
    WHERE username LIKE ? OR display_name LIKE ?
    LIMIT 10
  `, [`%${query}%`, `%${query}%`]);
  return rows;
}

module.exports = {
  getAccountByPhone,
  getAccountByUsername,
  getAccountById,
  createAccount,
  linkAccountToPhone,
  signOut,
  updateTheme,
  updateProfileData,
  createPost,
  getPosts,
  getUserPosts,
  toggleLike,
  hasLiked,
  searchAccounts,
};