const { pool } = require('./mysql');

const MAX_NOTES = 10;

// ================= ENSURE TABLE =================
async function ensureTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS phone_notes (
      id             INT           NOT NULL AUTO_INCREMENT,
      owner_user_id  VARCHAR(30)   NOT NULL,
      owner_char_num INT           NOT NULL,
      title          VARCHAR(100)  NULL DEFAULT NULL,
      content        TEXT          NOT NULL,
      created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      INDEX idx_owner (owner_user_id, owner_char_num)
    )
  `);
}

ensureTable().catch(err => console.error('[phone_notes] ensureTable failed:', err));

// ================= GET NOTES =================
async function getNotes(userId, charNum) {
  const [rows] = await pool.query(
    `SELECT * FROM phone_notes
     WHERE owner_user_id = ? AND owner_char_num = ?
     ORDER BY created_at DESC`,
    [userId, charNum]
  );
  return rows;
}

// ================= ADD NOTE =================
async function addNote(userId, charNum, content, title = null) {
  const count = await getNotesCount(userId, charNum);
  if (count >= MAX_NOTES) return false;

  const [result] = await pool.query(
    `INSERT INTO phone_notes (owner_user_id, owner_char_num, title, content)
     VALUES (?, ?, ?, ?)`,
    [userId, charNum, title || null, content]
  );
  return result.insertId;
}

// ================= DELETE NOTE =================
async function deleteNote(id, userId, charNum) {
  const [result] = await pool.query(
    `DELETE FROM phone_notes
     WHERE id = ? AND owner_user_id = ? AND owner_char_num = ?`,
    [id, userId, charNum]
  );
  return result.affectedRows > 0;
}

// ================= GET NOTES COUNT =================
async function getNotesCount(userId, charNum) {
  const [rows] = await pool.query(
    `SELECT COUNT(*) AS cnt FROM phone_notes
     WHERE owner_user_id = ? AND owner_char_num = ?`,
    [userId, charNum]
  );
  return rows[0]?.cnt ?? 0;
}

module.exports = {
  getNotes,
  addNote,
  deleteNote,
  getNotesCount,
  MAX_NOTES,
};