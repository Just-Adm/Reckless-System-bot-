const { pool } = require('./mysql');

// ================= ENSURE TABLE =================
async function ensureTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS characters (
      id               VARCHAR(20)   NOT NULL,
      user_id          VARCHAR(30)   NOT NULL,
      character_number INT           NOT NULL,
      firstname        VARCHAR(50)   NOT NULL,
      lastname         VARCHAR(50)   NOT NULL,
      dateofbirth      DATE          NOT NULL,
      placeofbirth     VARCHAR(100)  NOT NULL,
      blood_type       VARCHAR(5)    NULL DEFAULT NULL,
      fingerprint      VARCHAR(20)   NULL DEFAULT NULL,
      job              VARCHAR(100)  NOT NULL DEFAULT 'Unemployed',
      job_level        INT           NOT NULL DEFAULT 0,
      crime_level      INT           NOT NULL DEFAULT 0,
      status           ENUM('WAITING','OFFLINE','ONLINE') NOT NULL DEFAULT 'WAITING',
      cash             DECIMAL(15,2) NOT NULL DEFAULT 500.00,
      bank             DECIMAL(15,2) NOT NULL DEFAULT 0.00,
      national_id      VARCHAR(20)   NOT NULL,
      serial_number    VARCHAR(20)   NOT NULL,
      iban             VARCHAR(20)   NOT NULL,
      issue_date       DATE          NOT NULL,
      expiry_date      DATE          NOT NULL,
      thirst           INT           NOT NULL DEFAULT 100,
      hunger           INT           NOT NULL DEFAULT 100,
      phone_number     VARCHAR(20)   NULL DEFAULT NULL,
      phone_serial     VARCHAR(50)   NULL DEFAULT NULL,
      image_url        TEXT          NULL DEFAULT NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uq_user_char   (user_id, character_number),
      UNIQUE KEY uq_national_id (national_id),
      UNIQUE KEY uq_serial      (serial_number),
      UNIQUE KEY uq_iban        (iban)
    )
  `);

  // تحقق من الأعمدة وأضف الناقص
  const [columns] = await pool.query(`SHOW COLUMNS FROM characters`);
  const cols = columns.map(c => c.Field);

  const toAdd = {
    blood_type:   `ALTER TABLE characters ADD COLUMN blood_type   VARCHAR(5)  NULL DEFAULT NULL`,
    fingerprint:  `ALTER TABLE characters ADD COLUMN fingerprint  VARCHAR(20) NULL DEFAULT NULL`,
    phone_number: `ALTER TABLE characters ADD COLUMN phone_number VARCHAR(20) NULL DEFAULT NULL`,
    phone_serial: `ALTER TABLE characters ADD COLUMN phone_serial VARCHAR(50) NULL DEFAULT NULL`,
  };

  for (const [col, sql] of Object.entries(toAdd)) {
    if (!cols.includes(col)) {
      await pool.query(sql);
      console.log(`[characters] Added missing column: ${col}`);
    }
  }
}

ensureTable().catch(err => console.error('[characters] ensureTable failed:', err));

// ================= CONSTANTS =================
const CHARACTER_STATUS = {
  WAITING: 'WAITING',
  OFFLINE: 'OFFLINE',
  ONLINE:  'ONLINE'
};

// ================= GENERATORS =================
async function generateUnique(query, prefix, length) {
  let value;
  let exists = true;

  while (exists) {
    if (prefix === 'RL') {
      value = `RL${Math.floor(10000000 + Math.random() * 90000000)}`;
    } else if (prefix === 'MZ') {
      value = `MZ${Math.floor(10000 + Math.random() * 90000000)}`;
    } else {
      value = '';
      for (let i = 0; i < length; i++) value += Math.floor(Math.random() * 10);
    }
    const [rows] = await pool.query(query, [value]);
    exists = rows.length > 0;
  }

  return value;
}

function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function generateBloodType() {
  const roll = Math.floor(Math.random() * 50) + 1;
  if (roll === 1) return 'A+';
  const types = ['A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  return types[Math.floor(Math.random() * types.length)];
}

async function generateUniqueFingerprint() {
  return generateUnique(`SELECT fingerprint FROM characters WHERE fingerprint = ?`, '', 8);
}

async function generateUniqueUSPhone() {
  let phone;
  let exists = true;

  while (exists) {
    const area  = Math.floor(200 + Math.random() * 800);
    const part1 = Math.floor(100 + Math.random() * 900);
    const part2 = Math.floor(1000 + Math.random() * 9000);
    phone = `+1${area}${part1}${part2}`;
    const [rows] = await pool.query(`SELECT phone_number FROM characters WHERE phone_number = ?`, [phone]);
    exists = rows.length > 0;
  }

  return phone;
}

// ================= CREATE CHARACTER =================
async function createCharacter(userId, charNumber, data) {
  const issueDate  = new Date().toISOString().split('T')[0];
  const expiryDate = addDays(new Date(), 21);

  const nationalId   = await generateUnique(`SELECT national_id  FROM characters WHERE national_id  = ?`, 'RL');
  const serialNumber = await generateUnique(`SELECT serial_number FROM characters WHERE serial_number = ?`, '', 14);
  const iban         = await generateUnique(`SELECT iban         FROM characters WHERE iban         = ?`, 'MZ');

  const bloodType   = generateBloodType();
  const fingerprint = await generateUniqueFingerprint();
  const phoneNumber = await generateUniqueUSPhone();

  await pool.query(
    `INSERT INTO characters (
        id, user_id, character_number,
        firstname, lastname, dateofbirth, placeofbirth,
        job, cash, bank,
        national_id, serial_number, iban,
        issue_date, expiry_date, status,
        thirst, hunger, job_level, crime_level,
        image_url, blood_type, fingerprint, phone_number
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
        firstname    = VALUES(firstname),
        lastname     = VALUES(lastname),
        dateofbirth  = VALUES(dateofbirth),
        placeofbirth = VALUES(placeofbirth),
        job          = VALUES(job),
        cash         = VALUES(cash),
        bank         = VALUES(bank),
        image_url    = VALUES(image_url)`,
    [
      nationalId, userId, charNumber,
      data.Firstname, data.Lastname, data.Dateofbirth, data.Placeofbirth,
      data.Job      || 'Unemployed',
      data.Cash     ?? 500,
      data.Bank     ?? 0,
      nationalId, serialNumber, iban,
      issueDate, expiryDate, CHARACTER_STATUS.WAITING,
      data.Thirst    ?? 100,
      data.Hunger    ?? 100,
      data.JobLevel  ?? 0,
      data.CrimeLevel ?? 0,
      data.ImageUrl  || null,
      bloodType, fingerprint, phoneNumber
    ]
  );

  return {
    id: nationalId, nationalId, serialNumber, iban,
    issueDate, expiryDate, bloodType, fingerprint, phoneNumber,
    job:        data.Job        || 'Unemployed',
    cash:       data.Cash       ?? 500,
    bank:       data.Bank       ?? 0,
    thirst:     data.Thirst     ?? 100,
    hunger:     data.Hunger     ?? 100,
    jobLevel:   data.JobLevel   ?? 0,
    crimeLevel: data.CrimeLevel ?? 0,
    imageUrl:   data.ImageUrl   || null,
    status:     CHARACTER_STATUS.WAITING
  };
}

// ================= GET CHARACTER =================
async function getCharacter(userId, charNumber) {
  const [rows] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ? AND character_number = ?`,
    [userId, charNumber]
  );
  return rows[0] || null;
}

// ================= GET ALL CHARACTERS =================
async function getAllCharacters(userId) {
  const [rows] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ? ORDER BY character_number ASC`,
    [userId]
  );
  return rows;
}

module.exports = {
  createCharacter,
  getCharacter,
  getAllCharacters
};