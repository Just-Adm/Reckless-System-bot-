const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'reckless',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

(async () => {
    try {
        const conn = await pool.getConnection();

        console.log("✅ Database connected successfully!");

        conn.release();
    } catch (err) {
        console.log("❌ Database connection failed!");
        console.error(err);
        process.exit(1);
    }
})();

module.exports = { pool };