const { pool } = require('./mysql');
const productIcons = require('../items/productIcons');

// ================= ENSURE TABLES =================
async function ensureTables() {
  // جدول الكتالوج (تعريف المنتجات)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS items (
      id              INT            NOT NULL AUTO_INCREMENT,
      item_name       VARCHAR(100)   NOT NULL,
      price           DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
      weight          DECIMAL(8,2)   NOT NULL DEFAULT 0.00,
      available       TINYINT(1)     NOT NULL DEFAULT 0,
      category        VARCHAR(100)   NULL DEFAULT NULL,
      expiry_days     INT            NULL DEFAULT NULL,
      serial_required TINYINT(1)     NOT NULL DEFAULT 0,
      PRIMARY KEY (id),
      UNIQUE KEY uq_item_name (item_name)
    )
  `);

  // جدول الحقيبة (كل وحدة برقم تسلسلي)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS inventory (
      id               INT           NOT NULL AUTO_INCREMENT,
      user_id          VARCHAR(30)   NOT NULL,
      character_number INT           NOT NULL,
      item_name        VARCHAR(100)  NOT NULL,
      item_serial      VARCHAR(20)   NOT NULL,
      category         VARCHAR(100)  NOT NULL DEFAULT 'misc',
      available        TINYINT(1)    NOT NULL DEFAULT 1,
      expiry_date      DATE          NULL DEFAULT NULL,
      used             TINYINT(1)    NOT NULL DEFAULT 0,
      PRIMARY KEY (id),
      UNIQUE KEY uq_serial (item_serial),
      INDEX idx_owner     (user_id, character_number),
      INDEX idx_item_name (item_name)
    )
  `);

  // تحقق من الأعمدة الناقصة في inventory
  const [invCols] = await pool.query(`SHOW COLUMNS FROM inventory`);
  const invColNames = invCols.map(c => c.Field);

  const invMissing = {
    item_serial: `ALTER TABLE inventory ADD COLUMN item_serial VARCHAR(20) NOT NULL DEFAULT '' AFTER item_name`,
    expiry_date: `ALTER TABLE inventory ADD COLUMN expiry_date DATE NULL DEFAULT NULL`,
    available:   `ALTER TABLE inventory ADD COLUMN available TINYINT(1) NOT NULL DEFAULT 1`,
    used:        `ALTER TABLE inventory ADD COLUMN used TINYINT(1) NOT NULL DEFAULT 0`,
  };

  for (const [col, sql] of Object.entries(invMissing)) {
    if (!invColNames.includes(col)) {
      await pool.query(sql);
      console.log(`[inventory] Added missing column: ${col}`);
    }
  }

  // تحقق من الأعمدة الناقصة في items
  const [itemCols] = await pool.query(`SHOW COLUMNS FROM items`);
  const itemColNames = itemCols.map(c => c.Field);

  const itemsMissing = {
    expiry_days:     `ALTER TABLE items ADD COLUMN expiry_days INT NULL DEFAULT NULL`,
    serial_required: `ALTER TABLE items ADD COLUMN serial_required TINYINT(1) NOT NULL DEFAULT 0`,
  };

  for (const [col, sql] of Object.entries(itemsMissing)) {
    if (!itemColNames.includes(col)) {
      await pool.query(sql);
      console.log(`[items] Added missing column: ${col}`);
    }
  }
}

ensureTables().catch(err => console.error('[inventory] ensureTables failed:', err));

// ================= CONSTANTS =================
const SERIAL_TRACKED_CATEGORIES = ['ELECTRONICS', 'POLICE', 'WEAPONS', 'DOCUMENTS'];

const DEFAULT_ITEMS = [
  { item: 'Id card', quantity: 1, category: 'documents', available: 1 }
];

// ================= HELPERS =================
function getExpiryDays(itemName) {
  return productIcons[itemName]?.expiry ?? null;
}

function calculateExpiryDate(expiryDays) {
  if (!expiryDays || expiryDays <= 0) return null;
  const date = new Date();
  date.setDate(date.getDate() + expiryDays);
  return date.toISOString().split('T')[0];
}

function isSerialTracked(category) {
  if (!category) return false;
  return SERIAL_TRACKED_CATEGORIES.includes(category.toUpperCase());
}

async function generateUniqueItemSerial() {
  let serial;
  let exists = true;

  while (exists) {
    serial = String(Math.floor(10000000 + Math.random() * 90000000));
    const [rows] = await pool.query(
      `SELECT item_serial FROM inventory WHERE item_serial = ?`,
      [serial]
    );
    exists = rows.length > 0;
  }

  return serial;
}

// ================= CREATE DEFAULT INVENTORY =================
async function createDefaultInventory(userId, charNumber) {
  for (const it of DEFAULT_ITEMS) {
    for (let i = 0; i < it.quantity; i++) {
      const serial     = await generateUniqueItemSerial();
      const expiryDate = calculateExpiryDate(getExpiryDays(it.item));

      await pool.query(
        `INSERT INTO inventory
          (user_id, character_number, item_name, item_serial, category, available, expiry_date)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [userId, charNumber, it.item, serial, it.category ?? 'misc', it.available ?? 1, expiryDate]
      );
    }
  }

  return true;
}

// ================= GET INVENTORY =================
async function getInventory(userId, charNumber) {
  const [rows] = await pool.query(
    `SELECT id, item_name, item_serial, category, available, expiry_date, used
     FROM inventory
     WHERE user_id = ? AND character_number = ?
     ORDER BY id ASC`,
    [userId, charNumber]
  );

  const inventory = {};

  for (const row of rows) {
    if (!inventory[row.item_name]) {
      inventory[row.item_name] = {
        quantity: 0,
        category: row.category,
        available: row.available,
        items: []
      };
    }

    inventory[row.item_name].quantity += 1;
    inventory[row.item_name].items.push({
      serial:      row.item_serial,
      available:   row.available,
      category:    row.category,
      expiry_date: row.expiry_date || null,
      used:        !!row.used
    });
  }

  return inventory;
}

// ================= GET ITEM QUANTITY =================
async function getItemQuantity(userId, charNumber, itemName) {
  const [rows] = await pool.query(
    `SELECT COUNT(*) AS qty FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_name = ?`,
    [userId, charNumber, itemName]
  );
  return rows[0]?.qty ?? 0;
}

// ================= ADD ITEM =================
async function addItem(userId, charNumber, itemName, amount = 1, category = 'misc', available = 1) {
  if (!itemName || typeof itemName !== 'string') return false;
  if (amount <= 0) return false;

  const expiryDate = calculateExpiryDate(getExpiryDays(itemName));

  for (let i = 0; i < amount; i++) {
    const serial = await generateUniqueItemSerial();
    await pool.query(
      `INSERT INTO inventory
        (user_id, character_number, item_name, item_serial, category, available, expiry_date)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userId, charNumber, itemName, serial, category, available, expiryDate]
    );
  }

  return true;
}

// ================= ADD ITEM WITH SPECIFIC SERIAL =================
async function addItemWithSerial(userId, charNumber, itemName, itemSerial, category = 'misc', available = 1, expiryDate = null) {
  if (!itemName || !itemSerial) return false;

  await pool.query(
    `INSERT INTO inventory
      (user_id, character_number, item_name, item_serial, category, available, expiry_date)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [userId, charNumber, itemName, itemSerial, category, available, expiryDate]
  );

  return true;
}

// ================= REMOVE ITEM =================
async function removeItem(userId, charNumber, itemName, amount = 1) {
  if (!itemName || typeof itemName !== 'string') return false;
  if (amount <= 0) return false;

  const current = await getItemQuantity(userId, charNumber, itemName);
  if (current < amount) return false;

  const [rows] = await pool.query(
    `SELECT item_serial, category, available, expiry_date
     FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_name = ?
     LIMIT ?`,
    [userId, charNumber, itemName, amount]
  );

  for (const row of rows) {
    await pool.query(
      `DELETE FROM inventory
       WHERE user_id = ? AND character_number = ? AND item_serial = ?
       LIMIT 1`,
      [userId, charNumber, row.item_serial]
    );
  }

  return rows;
}

// ================= REMOVE ITEM BY SERIAL =================
async function removeItemBySerial(userId, charNumber, itemSerial) {
  const [rows] = await pool.query(
    `SELECT item_serial, item_name, category, available, expiry_date
     FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_serial = ?
     LIMIT 1`,
    [userId, charNumber, itemSerial]
  );

  if (!rows.length) return null;

  await pool.query(
    `DELETE FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_serial = ?
     LIMIT 1`,
    [userId, charNumber, itemSerial]
  );

  return rows[0];
}

// ================= SET ITEM QUANTITY =================
async function setItemQuantity(userId, charNumber, itemName, quantity) {
  if (!itemName || typeof itemName !== 'string') return false;
  if (quantity < 0) return false;

  const current = await getItemQuantity(userId, charNumber, itemName);
  if (quantity === current) return true;

  if (quantity < current) {
    const diff = current - quantity;
    const [rows] = await pool.query(
      `SELECT item_serial FROM inventory
       WHERE user_id = ? AND character_number = ? AND item_name = ?
       LIMIT ?`,
      [userId, charNumber, itemName, diff]
    );
    for (const row of rows) {
      await pool.query(
        `DELETE FROM inventory
         WHERE user_id = ? AND character_number = ? AND item_serial = ?
         LIMIT 1`,
        [userId, charNumber, row.item_serial]
      );
    }
    return true;
  }

  const diff = quantity - current;
  for (let i = 0; i < diff; i++) {
    const serial     = await generateUniqueItemSerial();
    const expiryDate = calculateExpiryDate(getExpiryDays(itemName));
    await pool.query(
      `INSERT INTO inventory (user_id, character_number, item_name, item_serial, category, available, expiry_date)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userId, charNumber, itemName, serial, 'misc', 1, expiryDate]
    );
  }

  return true;
}

// ================= SET ITEM META =================
async function setItemMeta(userId, charNumber, itemName, category, available) {
  if (!itemName || typeof itemName !== 'string') return false;
  await pool.query(
    `UPDATE inventory SET category = ?, available = ?
     WHERE user_id = ? AND character_number = ? AND item_name = ?`,
    [category ?? 'misc', available ?? 1, userId, charNumber, itemName]
  );
  return true;
}

// ================= CLEAR INVENTORY =================
async function clearInventory(userId, charNumber) {
  await pool.query(
    `DELETE FROM inventory WHERE user_id = ? AND character_number = ?`,
    [userId, charNumber]
  );
  return true;
}

// ================= TRANSFER ITEM (same serial) =================
async function transferItem(fromUserId, fromChar, toUserId, toChar, itemName, amount = 1) {
  if (amount <= 0) return false;

  const current = await getItemQuantity(fromUserId, fromChar, itemName);
  if (current < amount) return false;

  const [rows] = await pool.query(
    `SELECT item_serial, category, available, expiry_date
     FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_name = ?
     LIMIT ?`,
    [fromUserId, fromChar, itemName, amount]
  );

  if (!rows.length) return false;

  for (const row of rows) {
    await pool.query(
      `DELETE FROM inventory
       WHERE user_id = ? AND character_number = ? AND item_serial = ?
       LIMIT 1`,
      [fromUserId, fromChar, row.item_serial]
    );
  }

  for (const row of rows) {
    await pool.query(
      `INSERT INTO inventory (user_id, character_number, item_name, item_serial, category, available, expiry_date)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [toUserId, toChar, itemName, row.item_serial, row.category, row.available, row.expiry_date]
    );
  }

  return rows;
}

// ================= SET ITEM USED =================
//
//  المنطق:
//  - لو الوحدة المختارة used=true  → نلغي (toggle off) → used=false
//  - لو الوحدة المختارة used=false → نشغّل (toggle on)
//    - لو في وحدة أخرى من نفس المنتج used=true → نبدّل (swap)
//    - لو ما في → نضع used=true مباشرة
//
//  يرجع:
//    'TOGGLED_OFF'  — تم إلغاء الاستخدام
//    'ACTIVATED'    — تم تفعيل (لم يكن في مستخدم قبله)
//    'SWAPPED'      — تم التبديل من وحدة أخرى
//    false          — الوحدة غير موجودة
//
async function setItemUsed(userId, charNumber, itemSerial) {
  // جيب بيانات الوحدة المطلوبة
  const [rows] = await pool.query(
    `SELECT item_name, category, used FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_serial = ?
     LIMIT 1`,
    [userId, charNumber, itemSerial]
  );

  if (!rows.length) return false;

  const { item_name, category, used } = rows[0];

  // ── الوحدة مستخدمة بالفعل → toggle off ──
  if (used) {
    await pool.query(
      `UPDATE inventory SET used = 0
       WHERE user_id = ? AND character_number = ? AND item_serial = ?`,
      [userId, charNumber, itemSerial]
    );
    return 'TOGGLED_OFF';
  }

  // ── الوحدة غير مستخدمة → نبحث عن وحدة أخرى used=true من نفس المنتج ──
  const [existing] = await pool.query(
    `SELECT item_serial FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_name = ? AND used = 1
     LIMIT 1`,
    [userId, charNumber, item_name]
  );

  if (existing.length) {
    // swap: نلغي القديمة ونفعّل الجديدة
    await pool.query(
      `UPDATE inventory SET used = 0
       WHERE user_id = ? AND character_number = ? AND item_serial = ?`,
      [userId, charNumber, existing[0].item_serial]
    );

    await pool.query(
      `UPDATE inventory SET used = 1
       WHERE user_id = ? AND character_number = ? AND item_serial = ?`,
      [userId, charNumber, itemSerial]
    );

    return 'SWAPPED';
  }

  // ── ما في وحدة مستخدمة → فعّل مباشرة ──
  await pool.query(
    `UPDATE inventory SET used = 1
     WHERE user_id = ? AND character_number = ? AND item_serial = ?`,
    [userId, charNumber, itemSerial]
  );

  return 'ACTIVATED';
}

// ================= GET USED ITEM =================
// يرجع الوحدة المستخدمة حالياً (used=true) من منتج معين
async function getUsedItem(userId, charNumber, itemName) {
  const [rows] = await pool.query(
    `SELECT * FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_name = ? AND used = 1
     LIMIT 1`,
    [userId, charNumber, itemName]
  );
  return rows[0] || null;
}

// ================= UNSET ALL USED =================
// يلغي used=true من جميع وحدات منتج معين (عند رمي أو تبديل)
async function unsetItemUsed(userId, charNumber, itemName) {
  await pool.query(
    `UPDATE inventory SET used = 0
     WHERE user_id = ? AND character_number = ? AND item_name = ?`,
    [userId, charNumber, itemName]
  );
  return true;
}


async function hasItem(userId, charNumber, itemName, amount = 1) {
  const qty = await getItemQuantity(userId, charNumber, itemName);
  return qty >= amount;
}

module.exports = {
  createDefaultInventory,
  getInventory,
  getItemQuantity,
  addItem,
  addItemWithSerial,
  removeItem,
  removeItemBySerial,
  setItemQuantity,
  setItemMeta,
  clearInventory,
  transferItem,
  hasItem,
  isSerialTracked,
  SERIAL_TRACKED_CATEGORIES,
  setItemUsed,
  getUsedItem,
  unsetItemUsed
};