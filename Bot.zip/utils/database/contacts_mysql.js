const { pool } = require('./mysql');

// ================= ENSURE TABLE =================
async function ensureTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS phone_contacts (
      id               INT           NOT NULL AUTO_INCREMENT,
      owner_user_id    VARCHAR(30)   NOT NULL,
      owner_char_num   INT           NOT NULL,
      contact_name     VARCHAR(100)  NULL DEFAULT NULL,
      contact_phone    VARCHAR(30)   NOT NULL,
      added_at         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      INDEX idx_owner (owner_user_id, owner_char_num),
      INDEX idx_phone (contact_phone)
    )
  `);

  // جدول رموز المشاركة المؤقتة
  await pool.query(`
    CREATE TABLE IF NOT EXISTS phone_share_codes (
      code         CHAR(4)      NOT NULL,
      phone_number VARCHAR(30)  NOT NULL,
      expires_at   DATETIME     NOT NULL,
      PRIMARY KEY (code)
    )
  `);
}

ensureTable().catch(err => console.error('[phone_contacts] ensureTable failed:', err));

// ================= ADD CONTACT =================
async function addContact(userId, charNum, contactPhone, contactName = null) {
  const [result] = await pool.query(
    `INSERT INTO phone_contacts (owner_user_id, owner_char_num, contact_name, contact_phone)
     VALUES (?, ?, ?, ?)`,
    [userId, charNum, contactName || null, contactPhone]
  );
  return result.insertId;
}

// ================= GET CONTACTS =================
async function getContacts(userId, charNum) {
  const [rows] = await pool.query(
    `SELECT * FROM phone_contacts
     WHERE owner_user_id = ? AND owner_char_num = ?
     ORDER BY added_at DESC`,
    [userId, charNum]
  );
  return rows;
}

// ================= GET CONTACT BY ID =================
async function getContactById(id) {
  const [rows] = await pool.query(
    `SELECT * FROM phone_contacts WHERE id = ? LIMIT 1`,
    [id]
  );
  return rows[0] || null;
}

// ================= FIND CONTACT BY PHONE =================
// يبحث لو الشخص حافظ رقم معين
async function findContactByPhone(userId, charNum, phone) {
  const [rows] = await pool.query(
    `SELECT * FROM phone_contacts
     WHERE owner_user_id = ? AND owner_char_num = ? AND contact_phone = ?
     LIMIT 1`,
    [userId, charNum, phone]
  );
  return rows[0] || null;
}

// ================= UPDATE CONTACT =================
async function updateContact(id, contactPhone, contactName = null) {
  await pool.query(
    `UPDATE phone_contacts SET contact_phone = ?, contact_name = ? WHERE id = ?`,
    [contactPhone, contactName || null, id]
  );
  return true;
}

// ================= DELETE CONTACT =================
async function deleteContact(id) {
  await pool.query(`DELETE FROM phone_contacts WHERE id = ?`, [id]);
  return true;
}

// ================= GET CHAR BY PHONE =================
// يبحث عن شخصية بناءً على رقم الهاتف (phone_data)
async function getCharByPhone(phoneNumber) {
  const [rows] = await pool.query(
    `SELECT pd.*, c.firstname, c.lastname, c.national_id, c.user_id, c.character_number
     FROM phone_data pd
     JOIN characters c ON pd.owner_national_id = c.national_id
     WHERE pd.phone_number = ?
     LIMIT 1`,
    [phoneNumber]
  );
  return rows[0] || null;
}

// ================= SHARE CODES =================

// ينشئ رمز 4 أرقام فريد صالح 10 دقائق
async function generateShareCode(phoneNumber) {
  // نحذف الرموز المنتهية أولاً
  await pool.query(`DELETE FROM phone_share_codes WHERE expires_at < NOW()`);

  let code;
  let exists = true;

  while (exists) {
    code = String(Math.floor(1000 + Math.random() * 9000));
    const [rows] = await pool.query(
      `SELECT code FROM phone_share_codes WHERE code = ?`,
      [code]
    );
    exists = rows.length > 0;
  }

  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 دقائق

  await pool.query(
    `INSERT INTO phone_share_codes (code, phone_number, expires_at) VALUES (?, ?, ?)`,
    [code, phoneNumber, expiresAt]
  );

  return { code, expiresAt };
}

// يتحقق من الرمز ويرجع رقم الهاتف لو صح، null لو منتهي أو غلط
async function redeemShareCode(code) {
  const [rows] = await pool.query(
    `SELECT * FROM phone_share_codes WHERE code = ? AND expires_at > NOW()`,
    [code]
  );

  if (!rows.length) return null;

  // نحذف الرمز بعد الاستخدام
  await pool.query(`DELETE FROM phone_share_codes WHERE code = ?`, [code]);

  return rows[0].phone_number;
}

module.exports = {
  addContact,
  getContacts,
  getContactById,
  findContactByPhone,
  updateContact,
  deleteContact,
  getCharByPhone,
  generateShareCode,
  redeemShareCode,
};