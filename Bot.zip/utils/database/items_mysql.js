const { pool } = require('./mysql');

// ================= GET ALL ITEMS =================
async function getAllItems() {
  const [rows] = await pool.query(
    `SELECT id, item_name, price, weight, available, category, expiry_days, serial_required
     FROM items
     ORDER BY id ASC`
  );

  return rows.map(row => ({
    id: row.id,
    item: row.item_name,
    price: row.price,
    weight: row.weight,
    available: !!row.available,
    category: row.category,
    expiry_days: row.expiry_days || null,
    serial_required: !!row.serial_required
  }));
}

// ================= GET ITEM BY NAME =================
async function getItemByName(itemName) {
  const [rows] = await pool.query(
    `SELECT id, item_name, price, weight, available, category, expiry_days, serial_required
     FROM items
     WHERE item_name = ?
     LIMIT 1`,
    [itemName]
  );

  if (!rows.length) return null;

  return {
    id: rows[0].id,
    item: rows[0].item_name,
    price: rows[0].price,
    weight: rows[0].weight,
    available: !!rows[0].available,
    category: rows[0].category,
    expiry_days: rows[0].expiry_days || null,
    serial_required: !!rows[0].serial_required
  };
}

// ================= ADD NEW ITEM =================
async function addCatalogItem(itemName, price = 0, weight = 0, available = false, category = null, expiryDays = null, serialRequired = false) {
  if (!itemName || typeof itemName !== "string") return false;
  if (price < 0) return false;
  if (weight < 0) return false;

  await pool.query(
    `INSERT INTO items (item_name, price, weight, available, category, expiry_days, serial_required)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [itemName, price, weight, available ? 1 : 0, category, expiryDays, serialRequired ? 1 : 0]
  );

  return true;
}

// ================= UPDATE ITEM =================
async function updateCatalogItem(itemName, data = {}) {
  if (!itemName || typeof itemName !== "string") return false;

  const fields = [];
  const values = [];

  if (data.price !== undefined) {
    fields.push("price = ?");
    values.push(data.price);
  }

  if (data.weight !== undefined) {
    fields.push("weight = ?");
    values.push(data.weight);
  }

  if (data.available !== undefined) {
    fields.push("available = ?");
    values.push(data.available ? 1 : 0);
  }

  if (data.category !== undefined) {
    fields.push("category = ?");
    values.push(data.category);
  }

  if (data.expiry_days !== undefined) {
    fields.push("expiry_days = ?");
    values.push(data.expiry_days);
  }

  if (data.serial_required !== undefined) {
    fields.push("serial_required = ?");
    values.push(data.serial_required ? 1 : 0);
  }

  if (!fields.length) return false;

  values.push(itemName);

  await pool.query(
    `UPDATE items
     SET ${fields.join(", ")}
     WHERE item_name = ?`,
    values
  );

  return true;
}

// ================= DELETE ITEM =================
async function deleteCatalogItem(itemName) {
  if (!itemName || typeof itemName !== "string") return false;

  await pool.query(
    `DELETE FROM items WHERE item_name = ?`,
    [itemName]
  );

  return true;
}

// ================= SET AVAILABLE =================
async function setItemAvailable(itemName, available = true) {
  if (!itemName || typeof itemName !== "string") return false;

  await pool.query(
    `UPDATE items
     SET available = ?
     WHERE item_name = ?`,
    [available ? 1 : 0, itemName]
  );

  return true;
}

// ================= GET AVAILABLE ITEMS ONLY =================
async function getAvailableItems() {
  const [rows] = await pool.query(
    `SELECT id, item_name, price, weight, available, category, expiry_days, serial_required
     FROM items
     WHERE available = 1
     ORDER BY category ASC, price ASC`
  );

  return rows.map(row => ({
    id: row.id,
    item: row.item_name,
    price: row.price,
    weight: row.weight,
    available: !!row.available,
    category: row.category,
    expiry_days: row.expiry_days || null,
    serial_required: !!row.serial_required
  }));
}

// ================= GET ITEMS BY CATEGORY =================
async function getItemsByCategory(category) {
  if (!category || typeof category !== "string") return [];

  const [rows] = await pool.query(
    `SELECT id, item_name, price, weight, available, category, expiry_days, serial_required
     FROM items
     WHERE category = ?
     ORDER BY price ASC`,
    [category]
  );

  return rows.map(row => ({
    id: row.id,
    item: row.item_name,
    price: row.price,
    weight: row.weight,
    available: !!row.available,
    category: row.category,
    expiry_days: row.expiry_days || null,
    serial_required: !!row.serial_required
  }));
}

module.exports = {
  getAllItems,
  getItemByName,
  addCatalogItem,
  updateCatalogItem,
  deleteCatalogItem,
  setItemAvailable,
  getAvailableItems,
  getItemsByCategory
};