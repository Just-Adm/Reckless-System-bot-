const { pool } = require('./mysql');

// ================= ENSURE TABLE =================
async function ensureTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS bank_transactions (
      id                 INT            NOT NULL AUTO_INCREMENT,
      transaction_number VARCHAR(10)    NOT NULL,
      user_id            VARCHAR(30)    NOT NULL,
      national_id        VARCHAR(20)    NOT NULL,
      iban               VARCHAR(20)    NOT NULL,
      firstname          VARCHAR(50)    NOT NULL,
      lastname           VARCHAR(50)    NOT NULL,
      type               ENUM('DEPOSIT','WITHDRAW','TRANSFER') NOT NULL,
      amount             DECIMAL(15,2)  NOT NULL,
      reason             TEXT           NULL DEFAULT NULL,
      cash_after         DECIMAL(15,2)  NOT NULL DEFAULT 0.00,
      bank_after         DECIMAL(15,2)  NOT NULL DEFAULT 0.00,
      created_at         DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_txn_number (transaction_number),
      INDEX idx_user_id    (user_id),
      INDEX idx_iban       (iban),
      INDEX idx_created_at (created_at)
    )
  `);
}

ensureTable().catch(err => console.error('[bank_transactions] ensureTable failed:', err));

// ================= CONSTANTS =================
const TRANSACTION_TYPE = {
  DEPOSIT:  'DEPOSIT',
  WITHDRAW: 'WITHDRAW',
  TRANSFER: 'TRANSFER'
};

// ================= HELPERS =================
function generateTransactionNumber(sequence) {
  let n = sequence - 1;
  const d4 = (n % 9) + 1; n = Math.floor(n / 9);
  const d3 = (n % 9) + 1; n = Math.floor(n / 9);
  const d2 = (n % 9) + 1; n = Math.floor(n / 9);
  const d1 = (n % 9) + 1;
  return `MB-${d1}${d2}${d3}${d4}`;
}

async function getNextTransactionNumber() {
  const [rows] = await pool.query(`SELECT COUNT(*) AS total FROM bank_transactions`);
  const sequence = (rows[0].total || 0) + 1;
  return generateTransactionNumber(sequence);
}

// ================= CREATE TRANSACTION =================
async function createTransaction(data) {
  const transactionNumber = await getNextTransactionNumber();

  await pool.query(
    `INSERT INTO bank_transactions (
      transaction_number, user_id, national_id, iban,
      firstname, lastname, type, amount, reason,
      cash_after, bank_after, created_at
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
    [
      transactionNumber,
      data.userId,
      data.nationalId,
      data.iban,
      data.firstname,
      data.lastname,
      data.type,
      data.amount,
      data.reason,
      data.cashAfter,
      data.bankAfter
    ]
  );

  return transactionNumber;
}

// ================= GET TRANSACTIONS =================
async function getTransactions(userId) {
  const [rows] = await pool.query(
    `SELECT * FROM bank_transactions WHERE user_id = ? ORDER BY created_at DESC`,
    [userId]
  );
  return rows;
}

async function getTransactionsByIban(iban) {
  const [rows] = await pool.query(
    `SELECT * FROM bank_transactions WHERE iban = ? ORDER BY created_at DESC`,
    [iban]
  );
  return rows;
}

module.exports = {
  TRANSACTION_TYPE,
  createTransaction,
  getTransactions,
  getTransactionsByIban,
  generateTransactionNumber
};