const { pool } = require('./mysql');

// ================= ENSURE TABLES =================
async function ensureTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS reckmarket_store (
      id                INT            NOT NULL AUTO_INCREMENT,
      owner_user_id     VARCHAR(30)    NOT NULL,
      owner_national_id VARCHAR(20)    NOT NULL,
      issue_date        DATETIME       NOT NULL,
      expiry_date       DATETIME       NOT NULL,
      total_balance     DECIMAL(15,2)  NOT NULL DEFAULT 0.00,
      PRIMARY KEY (id)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reckmarket_transactions (
      id          INT            NOT NULL AUTO_INCREMENT,
      type        ENUM('deposit','withdraw','purchase') NOT NULL,
      amount      DECIMAL(15,2)  NOT NULL,
      date        DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
      user_name   VARCHAR(100)   NOT NULL,
      item        VARCHAR(100)   NULL DEFAULT NULL,
      item_amount INT            NULL DEFAULT NULL,
      PRIMARY KEY (id),
      INDEX idx_type (type),
      INDEX idx_date (date)
    )
  `);
}

ensureTables().catch(err => console.error('[reckmarket_finance] ensureTables failed:', err));

// ================= STORE =================
async function getStore() {
  const [rows] = await pool.query(`SELECT * FROM reckmarket_store LIMIT 1`);
  return rows[0] || null;
}

async function initStore(ownerUserId, ownerNationalId) {
  const now    = new Date();
  const expiry = new Date(now);
  expiry.setDate(expiry.getDate() + 30);

  await pool.query(
    `INSERT INTO reckmarket_store (owner_user_id, owner_national_id, issue_date, expiry_date, total_balance)
     VALUES (?, ?, ?, ?, 0)`,
    [ownerUserId, ownerNationalId, now, expiry]
  );

  return getStore();
}

async function updateBalance(amount) {
  await pool.query(
    `UPDATE reckmarket_store SET total_balance = total_balance + ? LIMIT 1`,
    [amount]
  );
}

// ================= TRANSACTIONS =================
async function addTransaction(type, amount, userName, item = null, itemAmount = null) {
  await pool.query(
    `INSERT INTO reckmarket_transactions (type, amount, date, user_name, item, item_amount)
     VALUES (?, ?, NOW(), ?, ?, ?)`,
    [type, amount, userName, item, itemAmount]
  );
}

async function getLastTransactions(limit = 5) {
  const [rows] = await pool.query(
    `SELECT * FROM reckmarket_transactions ORDER BY date DESC LIMIT ?`,
    [limit]
  );
  return rows;
}

async function getTransactionsPaged(page = 1, perPage = 5) {
  const offset = (page - 1) * perPage;
  const [rows] = await pool.query(
    `SELECT * FROM reckmarket_transactions ORDER BY date DESC LIMIT ? OFFSET ?`,
    [perPage, offset]
  );
  const [[{ total }]] = await pool.query(
    `SELECT COUNT(*) AS total FROM reckmarket_transactions`
  );
  return { rows, total, pages: Math.ceil(total / perPage) };
}

async function getRevenueSummary(days) {
  const [rows] = await pool.query(
    `SELECT COALESCE(SUM(amount), 0) AS total FROM reckmarket_transactions
     WHERE type = 'deposit' AND date >= DATE_SUB(NOW(), INTERVAL ? DAY)`,
    [days]
  );
  return rows[0]?.total ?? 0;
}

async function getExpensesSummary(days) {
  const [rows] = await pool.query(
    `SELECT COALESCE(SUM(amount), 0) AS total FROM reckmarket_transactions
     WHERE type IN ('withdraw','purchase') AND date >= DATE_SUB(NOW(), INTERVAL ? DAY)`,
    [days]
  );
  return rows[0]?.total ?? 0;
}

async function getTodayRevenue() {
  const [rows] = await pool.query(
    `SELECT COALESCE(SUM(amount), 0) AS total FROM reckmarket_transactions
     WHERE type = 'deposit' AND DATE(date) = CURDATE()`
  );
  return rows[0]?.total ?? 0;
}

async function getTodayExpenses() {
  const [rows] = await pool.query(
    `SELECT COALESCE(SUM(amount), 0) AS total FROM reckmarket_transactions
     WHERE type IN ('withdraw','purchase') AND DATE(date) = CURDATE()`
  );
  return rows[0]?.total ?? 0;
}

module.exports = {
  getStore,
  initStore,
  updateBalance,
  addTransaction,
  getLastTransactions,
  getTransactionsPaged,
  getRevenueSummary,
  getExpensesSummary,
  getTodayRevenue,
  getTodayExpenses
};