// productIcons.js — icon filenames + expiry days per product

module.exports = {

  // ── ID ─────────────────────────────────────────────────────────────────────
  "Id card": { icon: "idcard.png", expiry: 365 },

  // ── FOOD ───────────────────────────────────────────────────────────────────
  "Burger":         { icon: "Burger.png",        expiry: 3   },
  "Sandwich":       { icon: "Sandwich.png",       expiry: 3   },
  "Hot Dog":        { icon: "hotdog.png",         expiry: 3   },
  "Pizza":          { icon: "Pizza.png",          expiry: 3   },
  "Donut":          { icon: "donut.png",          expiry: 3   },
  "Tacos":          { icon: "tacos.png",          expiry: 3   },
  "Burrito":        { icon: "burrito.png",        expiry: 3   },
  "Baik Meal":      { icon: "baik_meal.png",      expiry: 3   },
  "Nuggets":        { icon: "nuggets.png",        expiry: 3   },
  "Fries":          { icon: "fries.png",          expiry: 3   },
  "Sandwich Baik":  { icon: "sandwich_baik.png",  expiry: 3   },
  "Musahab":        { icon: "musahab.png",        expiry: 3   },
  "Mansaf":         { icon: "mansaf.png",         expiry: 2   },
  "Maqluba":        { icon: "maqluba.png",        expiry: 2   },
  "Hummus":         { icon: "hummus.png",         expiry: 5   },
  "Tabbouleh":      { icon: "tabbouleh.png",      expiry: 3   },
  "Shawarma":       { icon: "shawarma.png",       expiry: 3   },
  "Falafel":        { icon: "falafel.png",        expiry: 3   },
  "Musakhan":       { icon: "musakhan.png",       expiry: 3   },

  // ── DRINKS ─────────────────────────────────────────────────────────────────
  "Arabic Coffee":  { icon: "arabic_coffee.png",  expiry: 90  },
  "Espresso":       { icon: "espresso.png",       expiry: 90  },
  "Tea":            { icon: "tea.png",            expiry: 90  },
  "Orange Juice":   { icon: "orange_juice.png",   expiry: 14  },
  "Water":          { icon: "water.png",          expiry: 365 },
  "Cola":           { icon: "cola.png",           expiry: 60  },
  "Coffee":         { icon: "coffee.png",         expiry: 90  },
  "Energy Drink":   { icon: "redbull.png",        expiry: 60  },
  "Vodka":          { icon: "vodka.png",          expiry: 180 },
  "Rum":            { icon: "rum.png",            expiry: 180 },
  "Wine":           { icon: "wine.png",           expiry: 180 },
  "Beer":           { icon: "beer.png",           expiry: 60  },
  "Whiskey":        { icon: "whiskey.png",        expiry: 365 },
  "Marlboro":       { icon: "marlboro.png",       expiry: 90  },

  // ── ELECTRONICS ────────────────────────────────────────────────────────────
  "Phone":              { icon: "phone.png",              expiry: 730 },
  "Radio":              { icon: "radio.png",              expiry: 730 },
  "Laptop":             { icon: "laptop.png",             expiry: 730 },
  "Encrypted Laptop":   { icon: "encrypted_laptop.png",   expiry: 730 },
  "Camera":             { icon: "camera.png",             expiry: 730 },
  "Gopro":              { icon: "gopro.png",              expiry: 730 },
  "Tablet":             { icon: "tablet.png",             expiry: 730 },
  "USB":                { icon: "usb.png",                expiry: 365 },
  "Black USB":          { icon: "black_usb.png",          expiry: 365 },
  "Red USB":            { icon: "red_usb.png",            expiry: 365 },

  // ── TOOLS ──────────────────────────────────────────────────────────────────
  "Pickaxe":           { icon: "pickaxe.png",           expiry: 365 },
  "Lockpick":          { icon: "Lockpick.png",          expiry: 30  },
  "Advanced Lockpick": { icon: "advanced_lockpick.png", expiry: 30  },
  "Bolt Cutter":       { icon: "bolt_cutter.png",       expiry: 365 },
  "Drill":             { icon: "drill.png",             expiry: 365 },
  "Keys":              { icon: "keys.png",              expiry: 365 },
  "A Keys":            { icon: "akeys.png",             expiry: 365 },
  "Packbag":           { icon: "packbag.png",           expiry: 365 },
  "Diving Kit":        { icon: "diving_kit.png",        expiry: 365 },
  "Tool Kit":          { icon: "tool_kit.png",          expiry: 365 },
  "Parachute":         { icon: "parachute.png",         expiry: 365 },
  "Screwdriver":       { icon: "screwdriver.png",       expiry: 365 },
  "Ziptip":            { icon: "ziptip.png",            expiry: 90  },
  "Wires":             { icon: "wires.png",             expiry: 365 },
  "Black Card":        { icon: "black_card.png",        expiry: 365 },
  "Green Card":        { icon: "green_card.png",        expiry: 365 },
  "Tube":              { icon: "tube.png",              expiry: 365 },
  "Gas mask":          { icon: "gas_mask.png",          expiry: 365 },

  // ── مسروقات ────────────────────────────────────────────────────────────────
  "Neck chain":    { icon: "neck_chain.png",    expiry: 730 },
  "Gold Bar":      { icon: "gold_bar.png",      expiry: 730 },
  "Golden Nugget": { icon: "golden_nugget.png", expiry: 730 },
  "Gold Ring":     { icon: "gold_ring.png",     expiry: 730 },
  "Gold Watch":    { icon: "gold_watch.png",    expiry: 730 },
  "Silver Bar":    { icon: "silver_bar.png",    expiry: 730 },
  "Silver Coins":  { icon: "silver_coins.png",  expiry: 730 },
  "Silver Ring":   { icon: "silver_ring.png",   expiry: 730 },
  "Cash Roll":     { icon: "cash_roll.png",     expiry: 730 },

  // ── DRUGS ──────────────────────────────────────────────────────────────────
  "Cocaine":    { icon: "cocaine.png",    expiry: 14 },
  "Weed":       { icon: "weed.png",       expiry: 14 },
  "Smoke Weed": { icon: "smoke_weed.png", expiry: 14 },

  // ── POLICE ─────────────────────────────────────────────────────────────────
  "Badge":      { icon: "badge.png",      expiry: 365 },
  "Handcuffs":  { icon: "badge.png.png",  expiry: 365 },
  "Radar":      { icon: "radar.png",      expiry: 730 },
  "Nightstick": { icon: "nightstick.png", expiry: 365 },

  // ── EMS ────────────────────────────────────────────────────────────────────
  "Treatments": { icon: "treatments.png", expiry: 180 },
  "Sedatives":  { icon: "sedatives.png",  expiry: 180 },
  "Bandage":    { icon: "bandage.png",    expiry: 180 },

  // ── تصنيع ──────────────────────────────────────────────────────────────────
  "Copper":              { icon: "copper.png",              expiry: 365 },
  "Steel":               { icon: "steel.png",               expiry: 365 },
  "Iron":                { icon: "iron.png",                expiry: 365 },
  "Gun Powder":          { icon: "gun_powder.png",          expiry: 180 },
  "Plastic":             { icon: "plastic.png",             expiry: 365 },
  "Weapon Manuscript":   { icon: "weapon_manuscript.png",   expiry: 365 },

  // ── أسلحة بيضاء ────────────────────────────────────────────────────────────
  "Knife":       { icon: "knife.png",       expiry: 365 },
  "Switchblade": { icon: "switchblade.png", expiry: 365 },
  "Pipe":        { icon: "pipe.png",        expiry: 365 },
  "Hammer":      { icon: "hammer.png",      expiry: 365 },
  "Flashlight":  { icon: "flashlight.png",  expiry: 365 },
  "Axe":         { icon: "axe.png",         expiry: 365 },

  // ── PISTOL ─────────────────────────────────────────────────────────────────
  "Pistol":                  { icon: "pistol.png",                  expiry: 365 },
  "Pistol Mk II":            { icon: "pistol_mk2.png",              expiry: 365 },
  "Combat Pistol":           { icon: "combat_pistol.png",           expiry: 365 },
  "SNS Pistol":              { icon: "sns_pistol.png",              expiry: 365 },
  "SNS Pistol Mk II":        { icon: "sns_pistol_mk2.png",          expiry: 365 },
  "Vintage Pistol":          { icon: "vintage_pistol.png",          expiry: 365 },
  "Ceramic Pistol":          { icon: "ceramic_pistol.png",          expiry: 365 },
  "Heavy Pistol":            { icon: "heavy_pistol.png",            expiry: 365 },
  "Pistol.50":               { icon: "pistol_50.png",               expiry: 365 },
  "Perico Pistol":           { icon: "perico_pistol.png",           expiry: 365 },
  "Double-Action Revolver":  { icon: "double_action_revolver.png",  expiry: 365 },
  "Heavy Revolver":          { icon: "heavy_revolver.png",          expiry: 365 },
  "Stun Gun":                { icon: "stun_gun.png",                expiry: 365 },
  "Flare Gun":               { icon: "flare_gun.png",               expiry: 365 },

  // ── SMG ────────────────────────────────────────────────────────────────────
  "Tec-9":      { icon: "tec9.png",       expiry: 365 },
  "Mini SMG":   { icon: "mini_smg.png",   expiry: 365 },
  "SMG":        { icon: "smg.png",        expiry: 365 },
  "Combat PDW": { icon: "combat_pdw.png", expiry: 365 },

  // ── RIFLES ─────────────────────────────────────────────────────────────────
  "Assault Rifle":  { icon: "assault_rifle.png",  expiry: 365 },
  "Bullpup Rifle":  { icon: "bullpup_rifle.png",  expiry: 365 },
  "Compact Rifle":  { icon: "compact_rifle.png",  expiry: 365 },
  "Carbine Rifle":  { icon: "carbine_rifle.png",  expiry: 365 },
  "Special Carbine":{ icon: "special_carbine.png",expiry: 365 },
  "Heavy Rifle":    { icon: "heavy_rifle.png",    expiry: 365 },
  "Service Carbine":{ icon: "service_carbine.png",expiry: 365 },
  "Battle Rifle":   { icon: "battle_rifle.png",   expiry: 365 },

  // ── MG ─────────────────────────────────────────────────────────────────────
  "Gusenberg Sweeper": { icon: "gusenberg_sweeper.png", expiry: 365 },
  "MG":                { icon: "mg.png",                expiry: 365 },
  "Combat MG":         { icon: "combat_mg.png",         expiry: 365 },

  // ── SNIPERS ────────────────────────────────────────────────────────────────
  "Sniper Rifle":   { icon: "sniper_rifle.png",   expiry: 365 },
  "Heavy Sniper":   { icon: "heavy_sniper.png",   expiry: 365 },
  "Marksman Rifle": { icon: "marksman_rifle.png", expiry: 365 },

  // ── OTHER WEAPONS ──────────────────────────────────────────────────────────
  "Grenade Launcher":   { icon: "grenade_launcher.png",   expiry: 365 },
  "RPG":                { icon: "rpg.png",                expiry: 365 },
  "Homing Launcher":    { icon: "homing_launcher.png",    expiry: 365 },
  "Firework Launcher":  { icon: "firework_launcher.png",  expiry: 365 },
  "EMP Launcher":       { icon: "emp_launcher.png",       expiry: 365 },
  "Snowball Launcher":  { icon: "snowball_launcher.png",  expiry: 365 },
};