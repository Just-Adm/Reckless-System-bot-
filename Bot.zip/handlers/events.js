const fs = require('fs');
const path = require('path');

module.exports = (client) => {
    const loadEvents = (dir) => {
        const eventFiles = fs.readdirSync(dir);
        for (const file of eventFiles) {
            const filePath = path.join(dir, file);
            if (fs.statSync(filePath).isDirectory()) {
                loadEvents(filePath);
            } else if (file.endsWith('.js')) {
                const event = require(filePath);
                if (event.name) {
                    if (event.once) {
                        client.once(event.name, (...args) => event.execute(...args, client));
                    } else {
                        client.on(event.name, (...args) => event.execute(...args, client));
                    }
                }
            }
        }
    };

    loadEvents(path.join(__dirname, '../events'));
}