require('dotenv').config({ quiet: true });
const { Collection, REST, Routes } = require('discord.js');
const { readdirSync } = require('fs');

module.exports = (client) => {

    const lines = [];
    const push = (text = '') => lines.push(text);

    client.slashCommands = new Collection();
    const commands = [];

    let loaded = 0;
    let failed = 0;

    //push('SLASH COMMAND LOADER');
   // push('');

    const folders = readdirSync('./slashCommands');

    for (const folder of folders) {
        //push(`📂 [${folder.toUpperCase()}]`);

        const files = readdirSync(`./slashCommands/${folder}`)
            .filter(file => file.endsWith('.js'));

        for (const file of files) {
            const command = require(`../slashCommands/${folder}/${file}`);

            if (command?.data?.name && command?.data?.description) {
                client.slashCommands.set(command.data.name, command);
                commands.push(command.data.toJSON());
                loaded++;
                //push(`  🟢 /${command.data.name}`);
            } else {
                failed++;
                //push(`  🔴 ${file} (Missing name or description)`);
            }
        }

        //push('');
    }

    push('📊 SUMMARY');
    push(`🟢 Loaded : ${loaded}`);
    push(`🔴 Failed : ${failed}`);
    push(`📋 Total  : ${loaded + failed}`);

    const width = Math.max(...lines.map(l => l.length)) + 4;

    console.log('.' + '-'.repeat(width) + '.');

    lines.forEach(line => {
        console.log('| ' + line.padEnd(width - 2) + '|');
    });

    console.log("'" + '-'.repeat(width) + "'");

    client.once('clientReady', async () => {
        const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

        const guilds = [
            process.env.GUILD_ID,
            process.env.GUILD_ID2,
            process.env.GUILD_ID3
        ];

        for (let i = 0; i < guilds.length; i++) {
            try {
                await rest.put(
                    Routes.applicationGuildCommands(client.user.id, guilds[i]),
                    { body: commands }
                );

                //console.log(`🟢 Slash commands registered for Guild ${i + 1}: ${guilds[i]}`);
            } catch (error) {
                //console.log(`🔴 Failed to register for Guild ${i + 1}: ${guilds[i]}`);
            }
        }
    });
};