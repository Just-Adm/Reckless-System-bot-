require('dotenv').config({ quiet: true });
const fs = require('fs');
const path = require('path');

module.exports = (client) => {

    const lines = [];
    const push = (text = '') => lines.push(text);

    let loaded = 0;
    let failed = 0;

    push('COMMAND LOADER');
    push('');

    fs.readdirSync('./commands').forEach((folder) => {
        //push(`📂 [${folder.toUpperCase()}]`);

        const commandFiles = fs.readdirSync(
            path.join(__dirname, `../commands/${folder}`)
        ).filter(file => file.endsWith('.js'));

        commandFiles.forEach((file) => {
            try {
                const command = require(
                    path.join(__dirname, `../commands/${folder}/${file}`)
                );

                if (command.name) {
                    client.commands.set(command.name, command);
                    loaded++;
                    //push(`  ✅  ${file}`);
                } else {
                    throw new Error('No command name');
                }
            } catch (error) {
                failed++;
                //push(`  ❌ ${file.padEnd(20)} ${error.message}`);
            }
        });

        //push('');
    });

    //push('📊 SUMMARY');
    //push(`✅ Loaded : ${loaded}`);
    //push(`❌ Failed : ${failed}`);
    //push(`📋 Total  : ${loaded + failed}`);

    if (failed === 0) {
        //push('🎉 All commands loaded successfully!');
    } else {
        //push(`⚠️  ${failed} command(s) need attention`);
    }

    const width = Math.max(...lines.map(l => l.length)) + 4;

    //console.log('.' + '-'.repeat(width) + '.');

    lines.forEach(line => {
        //console.log(
            //'| ' + line.padEnd(width - 2) + '|'
       // );
    });

    //console.log("'" + '-'.repeat(width) + "'");
};