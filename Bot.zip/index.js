require('dotenv').config({ quiet: true });
const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');
const { pool } = require('./utils/database/mysql');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.Reaction,
    Partials.User
  ]
});


const messageBot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

messageBot.on('interactionCreate', async (interaction) => {

  const phoneMessagesEvent = require('./events/Phone/Phonemessages');

  await phoneMessagesEvent.execute(interaction, messageBot);

});


client.commands = new Collection();
client.slashCommands = new Collection();

['commands', 'slashCommands', 'events'].forEach(handler => {
  require(`./handlers/${handler}`)(client);
});


client.login(process.env.TOKEN);