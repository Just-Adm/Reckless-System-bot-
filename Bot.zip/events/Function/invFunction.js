const { createCanvas, loadImage } = require('canvas');
const path = require('path');
const productIcons = require('../../utils/items/productIcons');

// كتيغوريات كل وحدة تظهر منفردة (بدون كمية)
const SERIAL_TRACKED_CATEGORIES = ['ELECTRONICS', 'POLICE', 'WEAPONS', 'DOCUMENTS'];

const SLOT_WIDTH_RIGHT  = 80;
const SLOT_HEIGHT_RIGHT = 75;

const SLOT_WIDTH_LEFT   = 122;
const SLOT_HEIGHT_LEFT  = 113;

const RIGHT_SLOTS = [
  { id: 1, x: 723, y: 410 },
  { id: 2, x: 723, y: 509 },
  { id: 3, x: 723, y: 604 },
  { id: 4, x: 723, y: 702 },
  { id: 5, x: 723, y: 798 },
];

const LEFT_SLOTS = [
  { id: 6,  x: 10,  y: 196 },
  { id: 7,  x: 147, y: 196 },
  { id: 8,  x: 283, y: 196 },
  { id: 9,  x: 421, y: 196 },
  { id: 10, x: 555, y: 196 },

  { id: 11, x: 10,  y: 333 },
  { id: 12, x: 147, y: 333 },
  { id: 13, x: 283, y: 333 },
  { id: 14, x: 421, y: 333 },
  { id: 15, x: 555, y: 333 },

  { id: 16, x: 10,  y: 467 },
  { id: 17, x: 147, y: 467 },
  { id: 18, x: 283, y: 467 },
  { id: 19, x: 421, y: 467 },
  { id: 20, x: 555, y: 467 },

  { id: 21, x: 10,  y: 601 },
  { id: 22, x: 147, y: 601 },
  { id: 23, x: 283, y: 601 },
  { id: 24, x: 421, y: 601 },
  { id: 25, x: 555, y: 601 },

  { id: 26, x: 10,  y: 738 },
  { id: 27, x: 147, y: 738 },
  { id: 28, x: 283, y: 738 },
  { id: 29, x: 421, y: 738 },
  { id: 30, x: 555, y: 738 },

  { id: 31, x: 10,  y: 875 },
  { id: 32, x: 147, y: 875 },
  { id: 33, x: 283, y: 875 },
  { id: 34, x: 421, y: 875 },
  { id: 35, x: 555, y: 875 },
];

// ================= DRAW SLOT =================
function drawSlotContent(ctx, icon, itemName, qty, x, y, w, h) {
  ctx.save();

  const pad       = Math.floor(Math.min(w, h) * 0.10);
  const nameH     = Math.floor(h * 0.22);
  const iconAreaH = h - nameH - pad;
  const maxIcon   = Math.floor(iconAreaH * 0.82);
  const cx        = x + w / 2;

  // ── Icon ──
  if (icon) {
    const iw    = icon.width  || maxIcon;
    const ih    = icon.height || maxIcon;
    const scale = Math.min(maxIcon / iw, maxIcon / ih, 1);
    const dw    = Math.round(iw * scale);
    const dh    = Math.round(ih * scale);
    const ix    = Math.round(cx - dw / 2);
    const iy    = Math.round(y + pad + (iconAreaH - dh) / 2);
    ctx.drawImage(icon, ix, iy, dw, dh);
  }

  // ── Name ──
  const fs = Math.max(11, Math.min(15, Math.floor(w / 8)));
  ctx.font          = `bold ${fs}px Arial`;
  ctx.textAlign     = 'center';
  ctx.textBaseline  = 'bottom';
  ctx.fillStyle     = '#fff';
  ctx.shadowColor   = 'rgba(0,0,0,0.9)';
  ctx.shadowBlur    = 4;

  let name = itemName;
  const maxW = w - pad * 2;
  while (ctx.measureText(name).width > maxW && name.length > 1) {
    name = name.slice(0, -1);
  }
  if (name !== itemName) name += '…';
  ctx.fillText(name, cx, y + h - 3);

  // ── Qty (فقط لو مش null) ──
  if (qty !== null) {
    const qfs = Math.max(9, Math.min(12, Math.floor(w / 10)));
    ctx.font          = `${qfs}px Arial`;
    ctx.textAlign     = 'left';
    ctx.textBaseline  = 'bottom';
    ctx.fillStyle     = '#e4e3e1';
    ctx.shadowBlur    = 3;
    ctx.fillText(`x${qty}`, x + 2, y + h - 2);
  }

  ctx.restore();
}

// ================= BUILD ITEM LIST =================
// يرجع مصفوفة من { name, qty } حيث:
// - المنتجات العادية: صف واحد بالكمية
// - TRACKED: صف لكل وحدة منفردة بدون كمية (qty = null)
function buildItemList(inventoryData) {
  const list = [];

  for (const [name, data] of Object.entries(inventoryData)) {
    if (!data.quantity || data.quantity <= 0) continue;

    const cat     = (data.category || '').toUpperCase();
    const tracked = SERIAL_TRACKED_CATEGORIES.includes(cat);

    if (tracked) {
      // كل وحدة صف منفرد
      for (let i = 0; i < data.quantity; i++) {
        list.push({ name, qty: null });
      }
    } else {
      // منتج عادي بكمية
      list.push({ name, qty: data.quantity });
    }
  }

  return list;
}

// ================= GENERATE IMAGE =================
async function generateInventoryImage(inventoryData) {
  const items = buildItemList(inventoryData);

  const canvas = createCanvas(848, 1000);
  const ctx    = canvas.getContext('2d');

  const bg = await loadImage(path.join(__dirname, '../../images/player/inventory.png'));
  ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

  const rightSlots = RIGHT_SLOTS.map(s => ({
    ...s,
    width:  SLOT_WIDTH_RIGHT,
    height: SLOT_HEIGHT_RIGHT
  }));

  const leftSlots = LEFT_SLOTS
    .filter((slot, index, self) =>
      index === self.findIndex(s => s.x === slot.x && s.y === slot.y)
    )
    .map(s => ({
      ...s,
      width:  SLOT_WIDTH_LEFT,
      height: SLOT_HEIGHT_LEFT
    }));

  const allSlots  = [...rightSlots, ...leftSlots];
  const maxItems  = Math.min(items.length, allSlots.length);

  const icons = await Promise.all(
    items.slice(0, maxItems).map(async ({ name: itemName }) => {
      const fileName = productIcons[itemName]?.icon || 'unfinded.png';
      const iconPath = path.join(__dirname, '../../images/items/', fileName);
      try {
        return await loadImage(iconPath);
      } catch {
        return await loadImage(path.join(__dirname, '../../images/items/unfinded.png'));
      }
    })
  );

  for (let i = 0; i < maxItems; i++) {
    const { name: itemName, qty } = items[i];
    const slot = allSlots[i];

    drawSlotContent(ctx, icons[i], itemName, qty, slot.x, slot.y, slot.width, slot.height);
  }

  return canvas.toBuffer('image/png');
}

module.exports = { generateInventoryImage };