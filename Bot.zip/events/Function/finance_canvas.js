const { createCanvas, loadImage } = require('canvas');
const path = require('path');

const BG_PATH = path.join(__dirname, '../../images/server/store-panel.png');

function formatRemaining(expiryDate) {
  const diff = Math.max(0, new Date(expiryDate).getTime() - Date.now());
  const days  = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins  = Math.floor((diff % 3600000)  / 60000);

  if (days  > 0) return `${days}d`;
  if (hours > 0) return `${hours}h`;
  if (mins  > 0) return `${mins}m`;
  return 'Expired';
}

function formatRemainingLong(expiryDate) {
  const diff = Math.max(0, new Date(expiryDate).getTime() - Date.now());
  const days  = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);

  const parts = [];
  if (days  > 0) parts.push(`${days} days`);
  if (hours > 0) parts.push(`${hours} hours`);
  return parts.length ? parts.join(', ') : 'Expired';
}

function formatExpiryDate(expiryDate) {
  const d = new Date(expiryDate);
  const months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
  return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

function formatMoney(n) {
  return `$${Number(n || 0).toLocaleString('en-US')}`;
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

async function drawFinancePanel({
  projectName,
  expiryDate,
  ownerFullName,
  todayRevenue,
  totalRevenue,
  totalExpenses,
  transactions,
  last7Days = [],
}) {
  const bg     = await loadImage(BG_PATH);
  const W      = bg.width;
  const H      = bg.height;
  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext('2d');

  ctx.drawImage(bg, 0, 0, W, H);

  const WHITE  = '#ffffff';
  const GREY   = '#999999';
  const LGREY  = '#cccccc';
  const YELLOW = '#f1c40f';
  const GREEN  = '#2ecc71';
  const RED    = '#e74c3c';

  // ── TOP STAT BOXES ────────────────────────────────────────────────────────
  const boxes = [
    { sub: projectName,                 cx: 128 },
    { sub: formatRemaining(expiryDate), cx: 316 },
    { sub: formatMoney(todayRevenue),   cx: 505 },
    { sub: formatMoney(totalRevenue),   cx: 690 },
    { sub: formatMoney(totalExpenses),  cx: 880 },
  ];

  for (const box of boxes) {
    ctx.font      = 'bold 16px Sans';
    ctx.fillStyle = WHITE;
    ctx.textAlign = 'center';
    ctx.fillText(box.sub, box.cx, 66);
  }

  // ── LEFT CARD ─────────────────────────────────────────────────────────────
  const LX = 78 + 40;
  const LY = 120;

  ctx.font      = 'bold 28px Sans';
  ctx.fillStyle = WHITE;
  ctx.textAlign = 'left';
  ctx.fillText(formatExpiryDate(expiryDate), LX + 20, LY + 118);

  ctx.font      = '15px Sans';
  ctx.fillStyle = GREY;
  ctx.fillText(formatRemainingLong(expiryDate), LX + 40, LY + 140);

  ctx.font      = 'bold 17px Sans';
  ctx.fillStyle = WHITE;
  ctx.fillText(ownerFullName, LX + 80, LY + 210);

  // ── RIGHT CARD — 7-day bar chart ──────────────────────────────────────────
  const RX = 430;
  const RY = 128;
  const RW = 475;
  const RH = 228;

  const chartPadL = 10;
  const chartPadR = 14;
  const chartPadT = 20;
  const chartPadB = 36;
  const chartX    = RX + chartPadL;
  const chartY    = RY + chartPadT;
  const chartW    = RW - chartPadL - chartPadR;
  const chartH    = RH - chartPadT - chartPadB;

  ctx.font      = 'bold 13px Sans';
  ctx.fillStyle = LGREY;
  ctx.textAlign = 'left';
  ctx.fillText('Revenue — Last 7 Days', chartX, RY + 14);

  const gridLines = 4;
  const maxVal    = Math.max(...last7Days.map(d => d.revenue), 1);

  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  ctx.lineWidth   = 1;
  for (let i = 0; i <= gridLines; i++) {
    const gy = chartY + chartH - (i / gridLines) * chartH;
    ctx.beginPath();
    ctx.moveTo(chartX, gy);
    ctx.lineTo(chartX + chartW, gy);
    ctx.stroke();

    ctx.font      = '7px Sans';
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.textAlign = 'right';
    ctx.fillText(
      i === 0 ? '$0' : `$${Math.round((maxVal * i) / gridLines).toLocaleString()}`,
      chartX - 4,
      gy + 4
    );
  }

  const barCount = last7Days.length || 7;
  const barSlot  = chartW / barCount;
  const barWidth = Math.max(barSlot * 0.55, 8);

  last7Days.forEach((d, i) => {
    const barH2 = maxVal > 0 ? (d.revenue / maxVal) * chartH : 2;
    const bx    = chartX + i * barSlot + (barSlot - barWidth) / 2;
    const by    = chartY + chartH - barH2;

    ctx.fillStyle = d.revenue > 0 ? GREEN : 'rgba(255,255,255,0.1)';
    roundRect(ctx, bx, by, barWidth, barH2, 3);
    ctx.fill();

    if (d.revenue > 0) {
      ctx.font      = '10px Sans';
      ctx.fillStyle = WHITE;
      ctx.textAlign = 'center';
      ctx.fillText(formatMoney(d.revenue), bx + barWidth / 2, by - 4);
    }

    ctx.font      = '11px Sans';
    ctx.fillStyle = GREY;
    ctx.textAlign = 'center';
    ctx.fillText(d.day, bx + barWidth / 2, chartY + chartH + 16);
  });

  // ── TRANSACTION TABLE ─────────────────────────────────────────────────────
  const TY     = 395;
  const ROW_H  = 26;
  const DATA_Y = TY + ROW_H + 6;

  const COL = {
    type:   190,
    amount: 390,
    date:   630,
    user:   840,
  };

  const typeColor = { deposit: GREEN, withdraw: RED, purchase: YELLOW };
  const typeLabel = { deposit: 'Deposit', withdraw: 'Withdraw', purchase: 'Purchase' };

  transactions.slice(0, 5).forEach((tx, i) => {
    const ry = DATA_Y + i * ROW_H;

    if (i % 2 === 0) {
      ctx.fillStyle = 'rgba(255,255,255,0.03)';
      ctx.fillRect(60, ry - 16, 870, ROW_H);
    }

    ctx.font      = '13px Sans';
    ctx.textAlign = 'center';

    ctx.fillStyle = typeColor[tx.type] || WHITE;
    ctx.fillText(typeLabel[tx.type] || tx.type, COL.type, ry);

    ctx.fillStyle = WHITE;
    ctx.fillText(formatMoney(tx.amount), COL.amount, ry);

    ctx.fillStyle = GREY;
    const d = new Date(tx.date);
    ctx.fillText(
      `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`,
      COL.date, ry
    );

    ctx.fillStyle = WHITE;
    ctx.fillText(tx.user_name, COL.user, ry);
  });

  return canvas.toBuffer('image/png');
}

module.exports = { drawFinancePanel };