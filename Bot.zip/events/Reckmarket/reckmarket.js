const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');

const { pool }      = require('../../utils/database/mysql');
const { DateTime }  = require('luxon');
const {
  getStockCategories,
  getStockByCategory,
  getOneUnit,
  sellUnit,
  getStockCount,
} = require('../../utils/database/reckmarket_items_mysql');
const { addTransaction, updateBalance } = require('../../utils/database/reckmarket_finance_mysql');

const { ReckmarketSaleLog } = require('../../JSON/channels.json');

// كتيغوريات يطلب فيها كمية (bulk) — باقيها x1 مباشرة
const BULK_CATEGORIES = ['FOOD', 'DRINKS', 'DRUGS', 'EMS'];

const ITEMS_PER_MENU = 8;
const MAX_SELECT     = 3;

// ── helpers ───────────────────────────────────────────────────────────────────

async function getOnlineChar(userId) {
  const [rows] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
    [userId]
  );
  return rows[0] || null;
}

function formatMoney(n) {
  return `$${Number(n || 0).toLocaleString('en-US')}`;
}

// ── Main handler ──────────────────────────────────────────────────────────────

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    // ── 1. Reckmarket button ───────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'reckmarket') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [charRows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!charRows.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولاً`,
        });
      }

      const char = charRows.find(c => c.status === 'ONLINE') || null;
      if (!char) {
        return interaction.editReply({
          content: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولاً`,
        });
      }

      const cats = await getStockCategories();
      if (!cats.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | البقالة فارغة حالياً`,
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setTitle('<:market:1502345111273603234> | Reckmarket')
        .setDescription(`> مرحباً **${char.firstname} ${char.lastname}** — اختر الكتالوج`)
        .addFields({ name: '💵 Cash', value: formatMoney(char.cash), inline: true });

      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('shop-cat')
          .setPlaceholder('اختر الكتالوج')
          .addOptions(
            cats.slice(0, 25).map(cat =>
              new StringSelectMenuOptionBuilder().setLabel(cat).setValue(cat)
            )
          )
      );

      return interaction.editReply({ embeds: [embed], components: [menu] });
    }

    // ── 2. Category selected ───────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'shop-cat') {
      await interaction.deferUpdate();

      const category  = interaction.values[0];
      const items     = await getStockByCategory(category);
      const available = items.filter(i => i.quantity > 0 && i.price > 0);

      if (!available.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | لا يوجد منتجات متاحة في **${category}**`,
          embeds: [], components: [],
        });
      }

      const isBulk = BULK_CATEGORIES.includes(category.toUpperCase());

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setTitle(`<:market:1502345111273603234> | ${category}`)
        .setDescription(
          isBulk
            ? `> اختر حتى **${MAX_SELECT}** منتجات`
            : `> اختر المنتج — كل وحدة x1 منفردة`
        );

      const components = [];

      const chunks = [];
      for (let i = 0; i < available.length; i += ITEMS_PER_MENU) {
        chunks.push(available.slice(i, i + ITEMS_PER_MENU));
      }

      for (let ci = 0; ci < Math.min(chunks.length, 3); ci++) {
        const chunk = chunks[ci];
        components.push(
          new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId(`shop-items_${category}_${ci}`)
              .setPlaceholder(`${category} — (${ci * ITEMS_PER_MENU + 1}-${ci * ITEMS_PER_MENU + chunk.length})`)
              .setMinValues(0)
              .setMaxValues(Math.min(MAX_SELECT, chunk.length))
              .addOptions(
                chunk.map(i =>
                  new StringSelectMenuOptionBuilder()
                    .setLabel(i.item_name)
                    .setDescription(
                      isBulk
                        ? `${formatMoney(i.price)} — متوفر: x${i.quantity}`
                        : `${formatMoney(i.price)} — x1`
                    )
                    .setValue(i.item_name)
                )
              )
          )
        );
      }

      components.push(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`shop-confirm_${category}`)
            .setLabel('تأكيد الاختيار')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('shop-back')
            .setLabel('◀ رجوع')
            .setStyle(ButtonStyle.Secondary),
        )
      );

      return interaction.editReply({ embeds: [embed], components });
    }

    // ── 3. Items selected → qty modal (bulk) أو شراء مباشر (x1) ──────────────
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('shop-items_')) {
      const parts    = interaction.customId.split('_');
      const category = parts[1];
      const selected = interaction.values;

      if (!selected.length) return;

      const isBulk = BULK_CATEGORIES.includes(category.toUpperCase());

      if (isBulk) {
        // نطلب كمية عبر modal
        const items = await getStockByCategory(category);

        const modal = new ModalBuilder()
          .setCustomId(`shop-qty-modal_${category}|${selected.join('|')}`)
          .setTitle('تحديد الكمية | Quantity');

        for (const itemName of selected.slice(0, MAX_SELECT)) {
          const found = items.find(i => i.item_name === itemName);
          const max   = found?.quantity || 1;
          const price = found?.price    || 0;

          modal.addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId(`qty_${itemName}`)
                .setLabel(`${itemName} — ${formatMoney(price)}/unit (max ${max})`)
                .setStyle(TextInputStyle.Short)
                .setPlaceholder(`1 - ${max}`)
                .setRequired(true)
            )
          );
        }

        return interaction.showModal(modal);
      }

      // غير bulk → نشتري x1 مباشرة لكل منتج مختار
      await interaction.deferUpdate();

      const char = await getOnlineChar(interaction.user.id);
      if (!char) {
        return interaction.editReply({
          content: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولاً`,
          embeds: [], components: [],
        });
      }

      return executePurchase(interaction, client, char, category, selected.map(name => ({ name, qty: 1 })));
    }

    // ── 3b. Confirm button (fallback) ─────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('shop-confirm_')) {
      return interaction.reply({
        content: `<:Warn:1497627240177991780> | اختر المنتجات من القوائم أعلاه أولاً`,
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── 4. Back ────────────────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'shop-back') {
      await interaction.deferUpdate();

      const cats = await getStockCategories();

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setTitle('<:market:1502345111273603234> | Reckmarket')
        .setDescription('> اختر الكتالوج');

      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('shop-cat')
          .setPlaceholder('اختر الكتالوج')
          .addOptions(
            cats.slice(0, 25).map(cat =>
              new StringSelectMenuOptionBuilder().setLabel(cat).setValue(cat)
            )
          )
      );

      return interaction.editReply({ embeds: [embed], components: [menu] });
    }

    // ── 5. Qty modal submit (bulk purchase) ───────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('shop-qty-modal_')) {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const raw      = interaction.customId.replace('shop-qty-modal_', '');
      const parts    = raw.split('|');
      const category = parts[0];
      const items    = parts.slice(1);

      const char = await getOnlineChar(interaction.user.id);
      if (!char) {
        return interaction.editReply({ content: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولاً` });
      }

      const parsed = [];
      for (const itemName of items) {
        const value  = interaction.fields.getTextInputValue(`qty_${itemName}`);
        const amount = parseInt(value);
        if (!amount || amount < 1) continue;
        parsed.push({ name: itemName, qty: amount });
      }

      if (!parsed.length) {
        return interaction.editReply({ content: `<:No:1497627141465178132> | لم يتم إدخال كميات صحيحة` });
      }

      return executePurchase(interaction, client, char, category, parsed);
    }
  },
};

// ── Purchase executor ──────────────────────────────────────────────────────────

async function executePurchase(interaction, client, char, category, items) {
  // items = [{ name, qty }]

  // جمع الوحدات المطلوبة من المخزن
  const toProcess = [];
  let totalCost   = 0;

  for (const { name: itemName, qty } of items) {
    const available = await getStockCount(itemName);

    if (available < qty) {
      const msg = `<:No:1497627141465178132> | الكمية المتاحة من **${itemName}**: x${available}`;
      if (interaction.deferred || interaction.replied) return interaction.editReply({ content: msg, components: [] });
      return interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
    }

    // نجيب الوحدات بالترتيب (أرخص أولاً)
    const [units] = await pool.query(`
      SELECT * FROM reckmarket_stock
      WHERE item_name = ?
        AND (expiry_date IS NULL OR expiry_date >= CURDATE())
      ORDER BY price ASC, imported_at ASC
      LIMIT ?
    `, [itemName, qty]);

    if (units.length < qty) {
      const msg = `<:No:1497627141465178132> | الكمية المتاحة من **${itemName}** في المخزن: x${units.length}`;
      if (interaction.deferred || interaction.replied) return interaction.editReply({ content: msg, components: [] });
      return interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
    }

    if (units[0].price <= 0) {
      const msg = `<:No:1497627141465178132> | سعر **${itemName}** غير محدد — تواصل مع المسؤول`;
      if (interaction.deferred || interaction.replied) return interaction.editReply({ content: msg, components: [] });
      return interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
    }

    const lineCost = units.reduce((s, u) => s + parseFloat(u.price), 0);
    totalCost += lineCost;
    toProcess.push({ itemName, units, lineCost, qty });
  }

  // تحقق من الرصيد
  if (char.cash < totalCost) {
    const msg = `<:No:1497627141465178132> | الكاش غير كافٍ\n**المطلوب:** ${formatMoney(totalCost)}\n**كاشك:** ${formatMoney(char.cash)}`;
    if (interaction.deferred || interaction.replied) return interaction.editReply({ content: msg, components: [] });
    return interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
  }

  // خصم الكاش
  await pool.query(
    `UPDATE characters SET cash = cash - ? WHERE user_id = ? AND status = 'ONLINE'`,
    [totalCost, interaction.user.id]
  );

  await updateBalance(totalCost);

  const purchased = [];

  for (const { itemName, units, lineCost, qty } of toProcess) {
    const serials = [];

    for (const unit of units) {
      // احذف من المخزن
      await sellUnit(unit.item_serial);

      // أضف للحقيبة بنفس السيريال
      await pool.query(
        `INSERT INTO inventory (user_id, character_number, item_name, item_serial, category, available, expiry_date)
         VALUES (?, ?, ?, ?, ?, 1, ?)`,
        [interaction.user.id, char.character_number, unit.item_name, unit.item_serial, unit.category, unit.expiry_date]
      );

      serials.push(unit.item_serial);
    }

    await addTransaction('purchase', lineCost, `${char.firstname} ${char.lastname}`, itemName, qty);

    purchased.push(`**${itemName}** x${qty} — ${formatMoney(lineCost)}`);
  }

  // Log
  const { ReckmarketSaleLog } = require('../../JSON/channels.json');
  const logChannel = client.channels.cache.get(ReckmarketSaleLog);
  if (logChannel) {
    const logEmbed = new EmbedBuilder()
      .setTitle('Reckmarket Log | Sale')
      .setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Character:** ${char.firstname} ${char.lastname}
**National ID:** ${char.national_id}

─────────────────────

**Category:** ${category}
${purchased.join('\n')}

**Total:** ${formatMoney(totalCost)}`)
      .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
      .setFooter({ text: 'Reckmarket | Log', iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

    await logChannel.send({ embeds: [logEmbed] });
  }

  const replyContent = `<:Yes:1497627245873991750> | تم الشراء بنجاح!\n${purchased.join('\n')}\n\n**الإجمالي:** ${formatMoney(totalCost)}`;

  if (interaction.deferred || interaction.replied) {
    return interaction.editReply({ content: replyContent, embeds: [], components: [] });
  }
  return interaction.reply({ content: replyContent, flags: MessageFlags.Ephemeral });
}