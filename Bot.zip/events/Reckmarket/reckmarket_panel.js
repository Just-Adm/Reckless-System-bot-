const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, MessageFlags, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { getStore, getLastTransactions, getRevenueSummary, getExpensesSummary, getTodayRevenue, getTodayExpenses } = require('../../utils/database/reckmarket_finance_mysql');

const MARKET_JOBS = ['market employee', 'market manager'];

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-panel') {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [charRows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!charRows.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولاً`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const char = charRows.find(c => c.status === 'ONLINE') || null;

      if (!char) {
        return interaction.editReply({
          content: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولاً`,
          flags: MessageFlags.Ephemeral,
        });
      }

      if (!MARKET_JOBS.includes(char.job)) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | يجب أن تكون موظفاً في البقالة`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const selected = interaction.values[0];

      // ── HR Section ────────────────────────────────────────────────────────────
      if (selected === 'reckmarket-hr_section') {
        if (char.job !== 'market manager') {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | يجب أن تكون مسؤول البقالة للوصول إلى قسم الموارد البشرية`,
            flags: MessageFlags.Ephemeral,
          });
        }

        const container = new ContainerBuilder()
          .setAccentColor(0x2f3136)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# <:people:1497627159341174814> | HR Section')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('> <:Control:1497627036653715637> | إختر العملية التي تريد تنفيذها')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Large)
          )
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new StringSelectMenuBuilder()
                .setCustomId('reckmarket-hr_action')
                .setPlaceholder('Select an option')
                .addOptions(
                  new StringSelectMenuOptionBuilder()
                    .setLabel('Hire')
                    .setDescription('توظيف موظف جديد في البقالة')
                    .setEmoji('<:newemployee:1502630015601217597>')
                    .setValue('hr-hire'),
                  new StringSelectMenuOptionBuilder()
                    .setLabel('Fire')
                    .setDescription('فصل موظف من البقالة')
                    .setEmoji('<:kick:1502629820369080462>')
                    .setValue('hr-fire'),
                  new StringSelectMenuOptionBuilder()
                    .setLabel('Change Position')
                    .setDescription('تغيير منصب الموظف')
                    .setEmoji('<:careerpromotion:1502629756745678868>')
                    .setValue('hr-position'),
                  new StringSelectMenuOptionBuilder()
                    .setLabel('Employees List')
                    .setDescription('عرض جميع موظفي البقالة')
                    .setEmoji('<:people:1497627159341174814>')
                    .setValue('hr-list')
                )
            )
          );

        return interaction.editReply({
          components: [container],
          flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        });
      }

      // ── Finance Section ───────────────────────────────────────────────────────
      if (selected === 'reckmarket-finance_section') {
        const store = await getStore();

        if (!store) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | لم يتم تهيئة نظام المالية بعد، استخدم \`-reckmarket-setup\``,
            flags: MessageFlags.Ephemeral,
          });
        }

        const [ownerCharRows] = await pool.query(
          `SELECT * FROM characters WHERE national_id = ?`,
          [store.owner_national_id]
        );
        const ownerChar = ownerCharRows[0] || null;
        const ownerName = ownerChar ? `${ownerChar.firstname} ${ownerChar.lastname}` : 'Unknown';

        const todayRev = await getTodayRevenue();
        const totalRev = await getRevenueSummary(9999);
        const totalExp = await getExpensesSummary(9999);
        const lastTx   = await getLastTransactions(5);

        const dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
        const days7    = [];
        for (let i = 6; i >= 0; i--) {
          const d       = new Date();
          d.setDate(d.getDate() - i);
          const dateStr = d.toISOString().split('T')[0];
          const [[{ total }]] = await pool.query(
            `SELECT COALESCE(SUM(amount), 0) AS total FROM reckmarket_transactions
             WHERE type = 'deposit' AND DATE(date) = ?`,
            [dateStr]
          );
          days7.push({ day: dayNames[d.getDay()], revenue: Number(total) });
        }

        const financeCanvasModule = require('../Function/finance_canvas');
        const drawFinancePanel    = financeCanvasModule.drawFinancePanel;
        const buffer = await drawFinancePanel({
          projectName:   'Reckmarket',
          expiryDate:    store.expiry_date,
          ownerFullName: ownerName,
          todayRevenue:  todayRev,
          totalRevenue:  totalRev,
          totalExpenses: totalExp,
          transactions:  lastTx,
          last7Days:     days7,
        });

        const attachment = new AttachmentBuilder(buffer, { name: 'finance.png' });

        const financeMenu = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('reckmarket-finance_action')
            .setPlaceholder('Select an option')
            .addOptions(
              new StringSelectMenuOptionBuilder()
                .setLabel('Revenues / Expenses')
                .setDescription('عرض الإيرادات والمصاريف')
                .setEmoji('<:Finance:1502348311095410849>')
                .setValue('finance-revenue'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Deposit / Withdraw')
                .setDescription('إيداع أو سحب من الخزنة')
                .setEmoji('<:Money:1497627135920308405>')
                .setValue('finance-transfer'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Transaction Log')
                .setDescription('عرض سجل المعاملات')
                .setEmoji('📋')
                .setValue('finance-log')
            )
        );

        return interaction.editReply({
          files:      [attachment],
          components: [financeMenu],
          flags:      MessageFlags.Ephemeral,
        });
      }

      // ── Market Control ────────────────────────────────────────────────────────
      if (selected === 'reckmarket-control') {
        const embed = new EmbedBuilder()
          .setColor(0x2f3136)
          .setTitle('<:control2:1502348593120415744> | Market Control')
          .setDescription('> <:Control:1497627036653715637> | إختر العملية التي تريد تنفيذها');

        const menu = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('reckmarket-control_action')
            .setPlaceholder('Select an option')
            .addOptions(
              new StringSelectMenuOptionBuilder()
                .setLabel('Inventory')
                .setDescription('عرض مخزون البقالة')
                .setEmoji('📦')
                .setValue('control-inventory'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Import Items')
                .setDescription('استيراد منتجات للخزنة')
                .setEmoji('📥')
                .setValue('control-import'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Edit Prices')
                .setDescription('تعديل أسعار المنتجات')
                .setEmoji('💲')
                .setValue('control-prices')
            )
        );

        return interaction.editReply({
          embeds:     [embed],
          components: [menu],
          flags:      MessageFlags.Ephemeral,
        });
      }
    }
  },
};