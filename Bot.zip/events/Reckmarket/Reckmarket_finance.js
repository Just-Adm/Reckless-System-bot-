const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
  AttachmentBuilder,
} = require('discord.js');

const { pool }       = require('../../utils/database/mysql');
const { DateTime }   = require('luxon');
const { drawFinancePanel } = require('../Function/finance_canvas');
const {
  getStore,
  updateBalance,
  addTransaction,
  getLastTransactions,
  getTransactionsPaged,
  getRevenueSummary,
  getExpensesSummary,
  getTodayRevenue,
  getTodayExpenses,
} = require('../../utils/database/reckmarket_finance_mysql');

const LOG_CHANNEL_ID = '1498054239174398108';
const MARKET_JOBS    = ['market employee', 'market manager'];

// ── helpers ───────────────────────────────────────────────────────────────────

async function getOnlineChar(userId) {
  const [rows] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
    [userId]
  );
  return rows[0] || null;
}

function formatMoney(n) {
  return `$${Number(n || 0).toLocaleString('en-US')}`;
}

function daysLabel(d) {
  if (d === 1)  return 'Last Day';
  if (d === 3)  return 'Last 3 Days';
  if (d === 7)  return 'Last 7 Days';
  if (d === 30) return 'Last Month';
  return `Last ${d} Days`;
}

function pageButtons(page, totalPages, prefix) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`${prefix}_prev_${page}`)
      .setLabel('◀')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 1),
    new ButtonBuilder()
      .setCustomId(`${prefix}_next_${page}`)
      .setLabel('▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages)
  );
}

function financeMenu() {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('reckmarket-finance_action')
      .setPlaceholder('Select an option')
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel('Revenues / Expenses')
          .setDescription('عرض الإيرادات والمصاريف')
          .setEmoji('<:Finance:1502348311095410849>')
          .setValue('finance-revenue'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Deposit / Withdraw')
          .setDescription('إيداع أو سحب من الخزنة')
          .setEmoji('<:Money:1497627135920308405>')
          .setValue('finance-transfer'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Transaction Log')
          .setDescription('عرض سجل المعاملات')
          .setEmoji('📋')
          .setValue('finance-log')
      )
  );
}

// ── Main handler ──────────────────────────────────────────────────────────────

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    // ── Finance action select ─────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-finance_action') {
      const action = interaction.values[0];

      // ── Revenue / Expenses ────────────────────────────────────────────────────
      if (action === 'finance-revenue') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const char = await getOnlineChar(interaction.user.id);
        if (!char || !MARKET_JOBS.includes(char.job)) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | يجب أن تكون موظفاً في البقالة`,
            flags: MessageFlags.Ephemeral,
          });
        }

        const days = 3;
        const rev  = await getRevenueSummary(days);
        const exp  = await getExpensesSummary(days);

        const periodMenu = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('finance-revenue-period_revenue_0')
            .setPlaceholder('اختر الفترة الزمنية — الإيرادات')
            .addOptions(
              new StringSelectMenuOptionBuilder().setLabel('Last Day').setValue('revenue_1'),
              new StringSelectMenuOptionBuilder().setLabel('Last 3 Days').setValue('revenue_3').setDefault(true),
              new StringSelectMenuOptionBuilder().setLabel('Last 7 Days').setValue('revenue_7'),
              new StringSelectMenuOptionBuilder().setLabel('Last Month').setValue('revenue_30'),
            )
        );

        const embed = new EmbedBuilder()
          .setColor(0x2ecc71)
          .setTitle('<:Finance:1502348311095410849> | Revenues — Last 3 Days')
          .setDescription(`**Total Revenue:** ${formatMoney(rev)}\n**Total Expenses:** ${formatMoney(exp)}`)
          .setFooter({ text: 'Page 1 / 2 — Revenues' })
          .setTimestamp();

        const navRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('finance-revpage_2')
            .setLabel('Expenses →')
            .setStyle(ButtonStyle.Secondary)
        );

        return interaction.editReply({
          embeds:     [embed],
          components: [periodMenu, navRow],
          flags:      MessageFlags.Ephemeral,
        });
      }

      // ── Deposit / Withdraw ────────────────────────────────────────────────────
      if (action === 'finance-transfer') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const char = await getOnlineChar(interaction.user.id);
        if (!char || char.job !== 'market manager') {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | يجب أن تكون مسؤول البقالة للقيام بهذه العملية`,
            flags: MessageFlags.Ephemeral,
          });
        }

        const store = await getStore();
        const balance = store?.total_balance ?? 0;

        const [charBankRows] = await pool.query(
          `SELECT bank FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
          [interaction.user.id]
        );
        const userBank = charBankRows[0]?.bank ?? 0;

        const embed = new EmbedBuilder()
          .setColor(0x2f3136)
          .setTitle('<:Money:1497627135920308405> | Deposit / Withdraw')
          .addFields(
            { name: '🏦 Store Balance', value: formatMoney(balance),  inline: true },
            { name: '💳 Your Bank',     value: formatMoney(userBank), inline: true },
          )
          .setTimestamp();

        const btns = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('finance-btn-deposit')
            .setLabel('Deposit')
            .setEmoji('⬆️')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('finance-btn-withdraw')
            .setLabel('Withdraw')
            .setEmoji('⬇️')
            .setStyle(ButtonStyle.Danger),
        );

        return interaction.editReply({
          embeds:     [embed],
          components: [btns],
          flags:      MessageFlags.Ephemeral,
        });
      }

      // ── Transaction Log ───────────────────────────────────────────────────────
      if (action === 'finance-log') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const { rows, total, pages } = await getTransactionsPaged(1, 5);

        const typeMap   = { deposit: '⬆️ Deposit', withdraw: '⬇️ Withdraw', purchase: '🛒 Purchase' };
        const lines     = rows.map(tx =>
          `**${typeMap[tx.type] || tx.type}** — ${formatMoney(tx.amount)} — ${tx.user_name} — <t:${Math.floor(new Date(tx.date).getTime() / 1000)}:d>`
        );

        const embed = new EmbedBuilder()
          .setColor(0x2f3136)
          .setTitle('📋 | Transaction Log')
          .setDescription(lines.length ? lines.join('\n') : 'لا يوجد معاملات')
          .setFooter({ text: `Page 1 / ${pages} — Total: ${total}` })
          .setTimestamp();

        const components = pages > 1
          ? [pageButtons(1, pages, 'finance-log')]
          : [];

        return interaction.editReply({
          embeds:     [embed],
          components,
          flags:      MessageFlags.Ephemeral,
        });
      }
    }

    // ── 3. Revenue period select ───────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('finance-revenue-period_')) {
      await interaction.deferUpdate();

      const val      = interaction.values[0];
      const [mode, daysStr] = val.split('_');
      const days     = parseInt(daysStr);
      const isRev    = mode === 'revenue';

      const rev  = await getRevenueSummary(days);
      const exp  = await getExpensesSummary(days);

      const periodMenu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`finance-revenue-period_${mode}_${days}`)
          .setPlaceholder(`اختر الفترة الزمنية — ${isRev ? 'الإيرادات' : 'المصاريف'}`)
          .addOptions(
            new StringSelectMenuOptionBuilder().setLabel('Last Day').setValue(`${mode}_1`).setDefault(days === 1),
            new StringSelectMenuOptionBuilder().setLabel('Last 3 Days').setValue(`${mode}_3`).setDefault(days === 3),
            new StringSelectMenuOptionBuilder().setLabel('Last 7 Days').setValue(`${mode}_7`).setDefault(days === 7),
            new StringSelectMenuOptionBuilder().setLabel('Last Month').setValue(`${mode}_30`).setDefault(days === 30),
          )
      );

      const embed = new EmbedBuilder()
        .setColor(isRev ? 0x2ecc71 : 0xe74c3c)
        .setTitle(`<:Finance:1502348311095410849> | ${isRev ? 'Revenues' : 'Expenses'} — ${daysLabel(days)}`)
        .setDescription(isRev
          ? `**Total Revenue:** ${formatMoney(rev)}`
          : `**Total Expenses:** ${formatMoney(exp)}`
        )
        .setFooter({ text: `Page ${isRev ? 1 : 2} / 2 — ${isRev ? 'Revenues' : 'Expenses'}` })
        .setTimestamp();

      const navRow = new ActionRowBuilder().addComponents(
        isRev
          ? new ButtonBuilder().setCustomId(`finance-revpage_2_${days}`).setLabel('Expenses →').setStyle(ButtonStyle.Secondary)
          : new ButtonBuilder().setCustomId(`finance-revpage_1_${days}`).setLabel('← Revenues').setStyle(ButtonStyle.Secondary)
      );

      return interaction.editReply({
        embeds:     [embed],
        components: [periodMenu, navRow],
        flags:      MessageFlags.Ephemeral,
      });
    }

    // ── 4. Revenue page flip ───────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('finance-revpage_')) {
      await interaction.deferUpdate();

      const parts  = interaction.customId.split('_');
      const toPage = parseInt(parts[1]);
      const days   = parseInt(parts[2]) || 3;
      const isRev  = toPage === 1;
      const mode   = isRev ? 'revenue' : 'expenses';

      const rev  = await getRevenueSummary(days);
      const exp  = await getExpensesSummary(days);

      const periodMenu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`finance-revenue-period_${mode}_${days}`)
          .setPlaceholder(`اختر الفترة الزمنية — ${isRev ? 'الإيرادات' : 'المصاريف'}`)
          .addOptions(
            new StringSelectMenuOptionBuilder().setLabel('Last Day').setValue(`${mode}_1`).setDefault(days === 1),
            new StringSelectMenuOptionBuilder().setLabel('Last 3 Days').setValue(`${mode}_3`).setDefault(days === 3),
            new StringSelectMenuOptionBuilder().setLabel('Last 7 Days').setValue(`${mode}_7`).setDefault(days === 7),
            new StringSelectMenuOptionBuilder().setLabel('Last Month').setValue(`${mode}_30`).setDefault(days === 30),
          )
      );

      const embed = new EmbedBuilder()
        .setColor(isRev ? 0x2ecc71 : 0xe74c3c)
        .setTitle(`<:Finance:1502348311095410849> | ${isRev ? 'Revenues' : 'Expenses'} — ${daysLabel(days)}`)
        .setDescription(isRev
          ? `**Total Revenue:** ${formatMoney(rev)}`
          : `**Total Expenses:** ${formatMoney(exp)}`
        )
        .setFooter({ text: `Page ${toPage} / 2 — ${isRev ? 'Revenues' : 'Expenses'}` })
        .setTimestamp();

      const navRow = new ActionRowBuilder().addComponents(
        isRev
          ? new ButtonBuilder().setCustomId(`finance-revpage_2_${days}`).setLabel('Expenses →').setStyle(ButtonStyle.Secondary)
          : new ButtonBuilder().setCustomId(`finance-revpage_1_${days}`).setLabel('← Revenues').setStyle(ButtonStyle.Secondary)
      );

      return interaction.editReply({
        embeds:     [embed],
        components: [periodMenu, navRow],
        flags:      MessageFlags.Ephemeral,
      });
    }

    // ── 5. Deposit button ──────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'finance-btn-deposit') {
      const modal = new ModalBuilder()
        .setCustomId('finance-modal-deposit')
        .setTitle('Deposit | إيداع')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('transfer_amount')
              .setLabel('Amount')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('ادخل المبلغ')
              .setRequired(true)
          )
        );
      return interaction.showModal(modal);
    }

    // ── 6. Withdraw button ─────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'finance-btn-withdraw') {
      const modal = new ModalBuilder()
        .setCustomId('finance-modal-withdraw')
        .setTitle('Withdraw | سحب')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('transfer_amount')
              .setLabel('Amount')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('ادخل المبلغ')
              .setRequired(true)
          )
        );
      return interaction.showModal(modal);
    }

    // ── 7. Modal: Deposit ──────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'finance-modal-deposit') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const amount = parseFloat(interaction.fields.getTextInputValue('transfer_amount').replace(/,/g, ''));

      if (isNaN(amount) || amount <= 0) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | مبلغ غير صحيح`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const char = await getOnlineChar(interaction.user.id);
      if (!char) {
        return interaction.editReply({
          content: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولاً`,
          flags: MessageFlags.Ephemeral,
        });
      }

      if (char.bank < amount) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | رصيد البنك غير كافٍ — رصيدك: **${formatMoney(char.bank)}**`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const store = await getStore();

const balance = store?.total_balance ?? 0;

const embed = new EmbedBuilder()
  .setColor(0x2ecc71)
  .setTitle('⬆️ Confirm Deposit')
  .addFields(
    { name: 'Amount',        value: formatMoney(amount),           inline: true },
    { name: 'Store Balance', value: formatMoney(balance),          inline: true },
    { name: 'After Deposit', value: formatMoney(balance + amount), inline: true },
  )
  .setTimestamp();

      const btns = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`finance-confirm-deposit_${amount}`)
          .setLabel('✅ Confirm')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('finance-cancel-transfer')
          .setLabel('❌ Cancel')
          .setStyle(ButtonStyle.Danger),
      );

      return interaction.editReply({
        embeds:     [embed],
        components: [btns],
        flags:      MessageFlags.Ephemeral,
      });
    }

    // ── 8. Modal: Withdraw ─────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'finance-modal-withdraw') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const amount = parseFloat(interaction.fields.getTextInputValue('transfer_amount').replace(/,/g, ''));

      if (isNaN(amount) || amount <= 0) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | مبلغ غير صحيح`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const store = await getStore();
      const balance = store?.total_balance ?? 0;

      if (balance < amount) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | رصيد الخزنة غير كافٍ — الخزنة: **${formatMoney(balance)}**`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('⬇️ Confirm Withdraw')
        .addFields(
          { name: 'Amount',        value: formatMoney(amount),             inline: true },
          { name: 'Store Balance', value: formatMoney(balance),            inline: true },
          { name: 'After Withdraw', value: formatMoney(balance - amount),  inline: true },
        )
        .setTimestamp();

      const btns = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`finance-confirm-withdraw_${amount}`)
          .setLabel('✅ Confirm')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('finance-cancel-transfer')
          .setLabel('❌ Cancel')
          .setStyle(ButtonStyle.Danger),
      );

      return interaction.editReply({
        embeds:     [embed],
        components: [btns],
        flags:      MessageFlags.Ephemeral,
      });
    }

    // ── 9. Confirm Deposit ─────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('finance-confirm-deposit_')) {
      await interaction.deferUpdate();

      const amount = parseFloat(interaction.customId.replace('finance-confirm-deposit_', ''));
      const char   = await getOnlineChar(interaction.user.id);

      if (!char || char.bank < amount) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | رصيد غير كافٍ`,
          components: [],
          flags: MessageFlags.Ephemeral,
        });
      }

      // Deduct from character bank
      await pool.query(
        `UPDATE characters SET bank = bank - ? WHERE user_id = ? AND status = 'ONLINE'`,
        [amount, interaction.user.id]
      );

      // Add to store balance
      await updateBalance(amount);
      await addTransaction('deposit', amount, `${char.firstname} ${char.lastname}`);

      // Log
      const logChannel = await client.channels.fetch(LOG_CHANNEL_ID);
      if (logChannel?.isTextBased()) {
        const logEmbed = new EmbedBuilder()
          .setColor(0x2ecc71)
          .setTitle('Reckmarket Log | Deposit')
          .setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Character:** ${char.firstname} ${char.lastname}
**National ID:** \`${char.national_id}\`
**Job:** ${char.job}

─────────────────────

**Amount Deposited:** ${formatMoney(amount)}`
          )
          .setTimestamp()
          .setFooter({ text: 'Reckmarket | Log', iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم إيداع **${formatMoney(amount)}** في الخزنة بنجاح`,
        embeds:      [],
        components:  [],
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── 10. Confirm Withdraw ───────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('finance-confirm-withdraw_')) {
      await interaction.deferUpdate();

      const amount  = parseFloat(interaction.customId.replace('finance-confirm-withdraw_', ''));
      const store = await getStore();
      const char    = await getOnlineChar(interaction.user.id);

      if (!store || store.total_balance < amount) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | رصيد الخزنة غير كافٍ`,
          components: [],
          flags: MessageFlags.Ephemeral,
        });
      }

      // Add to character bank
      await pool.query(
        `UPDATE characters SET bank = bank + ? WHERE user_id = ? AND status = 'ONLINE'`,
        [amount, interaction.user.id]
      );

      // Deduct from store balance
      await updateBalance(-amount);
      await addTransaction('withdraw', amount, `${char.firstname} ${char.lastname}`);

      // Log
      const logChannel = await client.channels.fetch(LOG_CHANNEL_ID);
      if (logChannel?.isTextBased()) {
        const logEmbed = new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('Reckmarket Log | Withdraw')
          .setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Character:** ${char.firstname} ${char.lastname}
**National ID:** \`${char.national_id}\`
**Job:** ${char.job}

─────────────────────

**Amount Withdrawn:** ${formatMoney(amount)}`
          )
          .setTimestamp()
          .setFooter({ text: 'Reckmarket | Log', iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم سحب **${formatMoney(amount)}** من الخزنة بنجاح`,
        embeds:     [],
        components: [],
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── 11. Cancel transfer ────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'finance-cancel-transfer') {
      await interaction.deferUpdate();
      return interaction.editReply({
        content: `❌ | تم إلغاء العملية`,
        embeds:     [],
        components: [],
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── 12. Transaction log pagination ─────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('finance-log_')) {
      await interaction.deferUpdate();

      const parts   = interaction.customId.split('_');
      const dir     = parts[1];
      const curPage = parseInt(parts[2]);
      const newPage = dir === 'next' ? curPage + 1 : curPage - 1;

      const { rows, total, pages } = await getTransactionsPaged(newPage, 5);

      const typeMap = { deposit: '⬆️ Deposit', withdraw: '⬇️ Withdraw', purchase: '🛒 Purchase' };
      const lines   = rows.map(tx =>
        `**${typeMap[tx.type] || tx.type}** — ${formatMoney(tx.amount)} — ${tx.user_name} — <t:${Math.floor(new Date(tx.date).getTime() / 1000)}:d>`
      );

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setTitle('📋 | Transaction Log')
        .setDescription(lines.length ? lines.join('\n') : 'لا يوجد معاملات')
        .setFooter({ text: `Page ${newPage} / ${pages} — Total: ${total}` })
        .setTimestamp();

      return interaction.editReply({
        embeds:     [embed],
        components: [pageButtons(newPage, pages, 'finance-log')],
        flags:      MessageFlags.Ephemeral,
      });
    }
  },
};