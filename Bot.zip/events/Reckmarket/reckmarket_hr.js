const { ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags, EmbedBuilder } = require('discord.js');
const { pool }                   = require('../../utils/database/mysql');
const { DateTime }               = require('luxon');
const { getCharacterByNationalId, updateCharacterJob, getMarketEmployees } = require('../../utils/database/reckmarket_mysql');

const { ReckmarketHireLog, ReckmarketFireLog, ReckmarketPositionLog } = require('../../JSON/channels.json');
const MARKET_JOBS = ['market employee', 'market manager'];

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    // ── HR action select ───────────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-hr_action') {
      const action = interaction.values[0];

      if (action === 'hr-hire') {
        const modal = new ModalBuilder()
          .setCustomId('reckmarket-modal-hire')
          .setTitle('Hire Employee | توظيف موظف')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('hire_national_id')
                .setLabel('National ID')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('ادخل رقم الوطني, مثل RL93497025')
                .setMinLength(2)
                .setMaxLength(12)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      if (action === 'hr-fire') {
        const modal = new ModalBuilder()
          .setCustomId('reckmarket-modal-fire')
          .setTitle('Fire Employee | فصل موظف')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('fire_national_id')
                .setLabel('National ID')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('ادخل رقم الوطني, مثل RL93497025')
                .setMinLength(2)
                .setMaxLength(12)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      if (action === 'hr-position') {
        const modal = new ModalBuilder()
          .setCustomId('reckmarket-modal-position')
          .setTitle('Change Position | تغير منصب الموظف')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('position_national_id')
                .setLabel('National ID')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('ادخل رقم الوطني, مثل RL93497025')
                .setMinLength(2)
                .setMaxLength(12)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      if (action === 'hr-list') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize } = require('discord.js');

        const employees = await getMarketEmployees();

        if (!employees.length) {
          return interaction.editReply({
            content: '📋 | لا يوجد موظفين',
            flags: MessageFlags.Ephemeral,
          });
        }

        const container = new ContainerBuilder()
          .setAccentColor(0x2f3136)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent('> Employees List')
          )
          .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          );

        for (const e of employees) {
          container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `Name: **${e.firstname} ${e.lastname}**\nNational ID: **\`${e.national_id}\`**\nPosition: **${e.job === 'market manager' ? 'Manager' : 'Employee'}**`
            )
          );

          container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
          );
        }

        return interaction.editReply({
          components: [container],
          flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        });
      }
    }

    // ── Modal: Hire ────────────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'reckmarket-modal-hire') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const nationalId = interaction.fields.getTextInputValue('hire_national_id').trim().toUpperCase();
      const target     = await getCharacterByNationalId(nationalId);

      if (!target) {
        return interaction.editReply({
          content: `<:Warn:1497627240177991780> | لم يتم العثور على مواطن بالرقم الوطني: \`${nationalId}\``,
          flags: MessageFlags.Ephemeral,
        });
      }

      if (MARKET_JOBS.includes(target.job)) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | هذا المواطن موظف بالفعل في البقالة: **${target.job}**`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const fullName = `${target.firstname} ${target.lastname}`;

      const embed = new EmbedBuilder()
        .setDescription(`> اختر المنصب للمواطن: **${fullName}**`);

      const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`reckmarket-jobselect-hire_${nationalId}`)
          .setPlaceholder('اختار المنصب')
          .addOptions(
            new StringSelectMenuOptionBuilder()
              .setLabel('Market Employee')
              .setDescription('موظف بقالة')
              .setValue('market employee'),
            new StringSelectMenuOptionBuilder()
              .setLabel('Market Manager')
              .setDescription('مسؤول البقالة')
              .setValue('market manager')
          )
      );

      return interaction.editReply({
        embeds: [embed],
        components: [row],
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── Modal: Fire ────────────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'reckmarket-modal-fire') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const nationalId = interaction.fields.getTextInputValue('fire_national_id').trim().toUpperCase();
      const target     = await getCharacterByNationalId(nationalId);

      if (!target) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | لم يتم العثور على مواطن بالرقم الوطني: \`${nationalId}\``,
          flags: MessageFlags.Ephemeral,
        });
      }

      if (!MARKET_JOBS.includes(target.job)) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | هذه المواطن ليس موظف في البقالة`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const oldJob = target.job;

      const [managerRows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
        [interaction.user.id]
      );
      const manager = managerRows[0] || null;

      await updateCharacterJob(nationalId, 'Unemployed');

      const logChannel = client.channels.cache.get(ReckmarketFireLog);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle(`Reckmarket Log | Fire`)
          .setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Character:** ${manager ? `${manager.firstname} ${manager.lastname}` : 'غير معروف'}
**National ID:** ${manager ? manager.national_id : 'غير معروف'}
**Job:** ${manager ? manager.job : 'غير معروف'}
 
─────────────────────
 
**Full Name:** ${target.firstname} ${target.lastname}
**National ID:** ${nationalId}
**Previous Job:** ${oldJob}`)
          .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
          .setFooter({ text: `Reckmarket | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم فصل **${target.firstname} ${target.lastname}** بنجاح`,
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── Modal: Position ────────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'reckmarket-modal-position') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const nationalId = interaction.fields.getTextInputValue('position_national_id').trim().toUpperCase();
      const target     = await getCharacterByNationalId(nationalId);

      if (!target) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | لم يتم العثور على مواطن بالرقم الوطني: \`${nationalId}\``,
          flags: MessageFlags.Ephemeral,
        });
      }

      if (!MARKET_JOBS.includes(target.job)) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | هذا المواطن ليس موظف في البقالة`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const embed = new EmbedBuilder()
        .setDescription(`> اختر المنصب الموظف: **${target.firstname} ${target.lastname}**`);

      const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`reckmarket-jobselect-promote_${nationalId}`)
          .setPlaceholder('اختار المنصب')
          .addOptions(
            new StringSelectMenuOptionBuilder()
              .setLabel('Market Employee')
              .setDescription('موظف بقالة')
              .setValue('market employee'),
            new StringSelectMenuOptionBuilder()
              .setLabel('Market Manager')
              .setDescription('مسؤول البقالة')
              .setValue('market manager')
          )
      );

      return interaction.editReply({
        embeds: [embed],
        components: [row],
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── Job select: Hire ───────────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('reckmarket-jobselect-hire_')) {
      await interaction.deferUpdate();

      const nationalId = interaction.customId.replace('reckmarket-jobselect-hire_', '');
      const newJob     = interaction.values[0];
      const target     = await getCharacterByNationalId(nationalId);

      if (!target) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | الشخصية غير موجودة`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const [managerRows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
        [interaction.user.id]
      );
      const manager = managerRows[0] || null;

      await updateCharacterJob(nationalId, newJob);

      const logChannel = client.channels.cache.get(ReckmarketHireLog);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle(`Reckmarket Log | Hire`)
          .setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Character:** ${manager ? `${manager.firstname} ${manager.lastname}` : 'غير معروف'}
**National ID:** ${manager ? manager.national_id : 'غير معروف'}
**Job:** ${manager ? manager.job : 'غير معروف'}
 
─────────────────────
 
**Full Name:** ${target.firstname} ${target.lastname}
**National ID:** ${nationalId}
**New Job:** ${newJob}`)
          .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
          .setFooter({ text: `Reckmarket | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم توظيف **${target.firstname} ${target.lastname}** كـ **${newJob}** بنجاح`,
        components: [],
        flags: MessageFlags.Ephemeral,
      });
    }

    // ── Job select: Position ───────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('reckmarket-jobselect-promote_')) {
      await interaction.deferUpdate();

      const nationalId = interaction.customId.replace('reckmarket-jobselect-promote_', '');
      const newJob     = interaction.values[0];
      const target     = await getCharacterByNationalId(nationalId);

      if (!target) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | الشخصية غير موجودة`,
          flags: MessageFlags.Ephemeral,
        });
      }

      const oldJob = target.job;

      const [managerRows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
        [interaction.user.id]
      );
      const manager = managerRows[0] || null;

      await updateCharacterJob(nationalId, newJob);

      const logChannel = client.channels.cache.get(ReckmarketPositionLog);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle(`Reckmarket Log | Position`)
          .setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Character:** ${manager ? `${manager.firstname} ${manager.lastname}` : 'غير معروف'}
**National ID:** ${manager ? manager.national_id : 'غير معروف'}
**Job:** ${manager ? manager.job : 'غير معروف'}
 
─────────────────────
 
**Full Name:** ${target.firstname} ${target.lastname}
**National ID:** ${nationalId}
**Previous Job:** ${oldJob}
**New Job:** ${newJob}`)
          .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
          .setFooter({ text: `Reckmarket | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم تعديل رتبة **${target.firstname} ${target.lastname}** من **${oldJob}** إلى **${newJob}** بنجاح`,
        components: [],
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};