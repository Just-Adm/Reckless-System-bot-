const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');

const { pool }     = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const {
  getStockSummary,
  getStockCategories,
  getStockByCategory,
  importItems,
  removeExpiredItems,
  updateItemPrice,
  getAllStock,
} = require('../../utils/database/reckmarket_items_mysql');
const { getAvailableItems, getItemsByCategory } = require('../../utils/database/items_mysql');
const { getStore, updateBalance }               = require('../../utils/database/reckmarket_finance_mysql');

const { ReckmarketImportLog } = require('../../JSON/channels.json');

const MARKET_JOBS = ['market employee', 'market manager'];
const CUSTOMS_TAX = 0.01;
const STOCK_PER_PAGE = 8;

// ── helpers ───────────────────────────────────────────────────────────────────

async function getOnlineChar(userId) {
  const [rows] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
    [userId]
  );
  return rows[0] || null;
}

function formatMoney(n) {
  return `$${Number(n || 0).toLocaleString('en-US')}`;
}

function formatDate(d) {
  if (!d) return '—';
  return DateTime.fromJSDate(new Date(d)).setZone('Asia/Amman').toFormat('dd/MM/yyyy');
}

function pageButtons(page, totalPages, prefix) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`${prefix}_prev_${page}`)
      .setLabel('◀')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 1),
    new ButtonBuilder()
      .setCustomId(`${prefix}_next_${page}`)
      .setLabel('▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages)
  );
}

async function getAvailableCategories() {
  const items = await getAvailableItems();
  const cats  = [...new Set(items.map(i => i.category).filter(Boolean))];
  return cats.sort();
}

// ── Inventory page (summary per item) ─────────────────────────────────────────

async function sendInventoryPage(interaction, page) {
  await removeExpiredItems();

  const summary = await getStockSummary();

  if (!summary.length) {
    return interaction.editReply({
      content: '📦 | المخزون فارغ',
      embeds: [], components: [],
    });
  }

  const totalPages = Math.ceil(summary.length / STOCK_PER_PAGE);
  const slice      = summary.slice((page - 1) * STOCK_PER_PAGE, page * STOCK_PER_PAGE);

  const lines = slice.map(i => {
    const expText = i.nearest_expiry ? ` — exp: ${formatDate(i.nearest_expiry)}` : '';
    return `**${i.item_name}** — x${i.quantity} — ${formatMoney(i.price)}${expText}`;
  });

  const embed = new EmbedBuilder()
    .setColor(0x2f3136)
    .setTitle('📦 | Inventory')
    .setDescription(lines.join('\n'))
    .setFooter({ text: `Page ${page} / ${totalPages} — Total items: ${summary.length}` });

  const components = [];
  if (totalPages > 1) components.push(pageButtons(page, totalPages, 'control-inv'));

  components.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('control-remove-expired')
        .setLabel('🗑️ Remove Expired')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('control-throw-item')
        .setLabel('📤 Throw Item')
        .setStyle(ButtonStyle.Secondary),
    )
  );

  return interaction.editReply({ embeds: [embed], components });
}

// ── Main handler ──────────────────────────────────────────────────────────────

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    // ── Control action select ──────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-control_action') {
      const action = interaction.values[0];

      // ─ Inventory ─
      if (action === 'control-inventory') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        return sendInventoryPage(interaction, 1);
      }

      // ─ Import ─
      if (action === 'control-import') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const char = await getOnlineChar(interaction.user.id);
        if (!char || !MARKET_JOBS.includes(char.job)) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | يجب أن تكون موظفاً في البقالة`,
          });
        }

        const cats = await getAvailableCategories();
        if (!cats.length) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | لا يوجد منتجات متاحة للاستيراد`,
          });
        }

        const menu = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('reckmarket-import-cat')
            .setPlaceholder('اختر الكتالوج')
            .addOptions(
              cats.slice(0, 25).map(cat =>
                new StringSelectMenuOptionBuilder().setLabel(cat).setValue(cat)
              )
            )
        );

        return interaction.editReply({ components: [menu] });
      }

      // ─ Prices ─
      if (action === 'control-prices') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const char = await getOnlineChar(interaction.user.id);
        if (!char || char.job !== 'market manager') {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | يجب أن تكون مسؤول البقالة لتعديل الأسعار`,
          });
        }

        const cats = await getStockCategories();
        if (!cats.length) {
          return interaction.editReply({ content: `<:No:1497627141465178132> | المخزون فارغ` });
        }

        const embed = new EmbedBuilder()
          .setColor(0x2f3136)
          .setTitle('💲 | Edit Prices')
          .setDescription('> اختر الكتالوج أولاً');

        const menu = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('reckmarket-prices-cat')
            .setPlaceholder('اختر الكتالوج')
            .addOptions(
              cats.slice(0, 25).map(cat =>
                new StringSelectMenuOptionBuilder().setLabel(cat).setValue(cat)
              )
            )
        );

        return interaction.editReply({ embeds: [embed], components: [menu] });
      }
    }

    // ── Inventory pagination ───────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('control-inv_')) {
      await interaction.deferUpdate();
      const parts   = interaction.customId.split('_');
      const dir     = parts[1];
      const curPage = parseInt(parts[2]);
      return sendInventoryPage(interaction, dir === 'next' ? curPage + 1 : curPage - 1);
    }

    // ── Remove expired ─────────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'control-remove-expired') {
      await interaction.deferUpdate();
      const removed = await removeExpiredItems();

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم حذف **${removed}** وحدة منتهية الصلاحية`,
        embeds: [], components: [],
      });
    }

    // ── Throw — category select ────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'control-throw-item') {
      await interaction.deferUpdate();

      const cats = await getStockCategories();
      if (!cats.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | المخزون فارغ`,
          embeds: [], components: [],
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setDescription('> اختر الكتالوج لرمي المنتج');

      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('reckmarket-throw-cat')
          .setPlaceholder('اختر الكتالوج')
          .addOptions(
            cats.slice(0, 25).map(cat =>
              new StringSelectMenuOptionBuilder().setLabel(cat).setValue(cat)
            )
          )
      );

      return interaction.editReply({ embeds: [embed], components: [menu] });
    }

    // ── Throw — item select ────────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-throw-cat') {
      await interaction.deferUpdate();

      const category = interaction.values[0];
      const items    = await getStockByCategory(category);

      if (!items.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | لا يوجد منتجات في هذا الكتالوج`,
          embeds: [], components: [],
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setDescription(`> اختر المنتجات من كتالوج **${category}** (حتى 5)`);

      // label = اسم + كمية، value = اسم
      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`reckmarket-throw-items_${category}`)
          .setPlaceholder('اختر المنتجات')
          .setMinValues(1)
          .setMaxValues(Math.min(5, items.length))
          .addOptions(
            items.slice(0, 25).map(i =>
              new StringSelectMenuOptionBuilder()
                .setLabel(`${i.item_name} (x${i.quantity})`)
                .setValue(String(i.item_name))
            )
          )
      );

      return interaction.editReply({ embeds: [embed], components: [menu] });
    }

    // ── Throw — quantity modal ─────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('reckmarket-throw-items_')) {
      const selectedItems = interaction.values;
      const category      = interaction.customId.replace('reckmarket-throw-items_', '');
      const storeItems    = await getStockByCategory(category);

      const modal = new ModalBuilder()
        .setCustomId(`reckmarket-throw-modal_${category}|${selectedItems.join('|')}`)
        .setTitle('رمي منتج | Throw Item');

      for (const itemName of selectedItems.slice(0, 5)) {
        const found = storeItems.find(i => i.item_name === itemName);
        const max   = found?.quantity || 1;

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId(`qty_${itemName}`)
              .setLabel(`${itemName} (max ${max})`)
              .setStyle(TextInputStyle.Short)
              .setPlaceholder(`1 - ${max}`)
              .setRequired(true)
          )
        );
      }

      return interaction.showModal(modal);
    }

    // ── Throw — modal submit ───────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('reckmarket-throw-modal_')) {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const raw      = interaction.customId.replace('reckmarket-throw-modal_', '');
      const parts    = raw.split('|');
      const category = parts[0];
      const items    = parts.slice(1);

      const removed = [];

      for (const itemName of items) {
        const value  = interaction.fields.getTextInputValue(`qty_${itemName}`);
        const amount = parseInt(value);
        if (!amount || amount < 1) continue;

        // نحذف بالترتيب (الأقدم أولاً)
        const [units] = await pool.query(`
          SELECT item_serial FROM reckmarket_stock
          WHERE item_name = ?
            AND (expiry_date IS NULL OR expiry_date >= CURDATE())
          ORDER BY imported_at ASC
          LIMIT ?
        `, [itemName, amount]);

        for (const unit of units) {
          await pool.query(
            `DELETE FROM reckmarket_stock WHERE item_serial = ? LIMIT 1`,
            [unit.item_serial]
          );
        }

        if (units.length) removed.push(`${itemName} x${units.length}`);
      }

      return interaction.editReply({
        content: removed.length
          ? `<:Yes:1497627245873991750> | تم رمي:\n${removed.join('\n')}`
          : `<:No:1497627141465178132> | لم يتم رمي أي منتج`,
      });
    }

    // ── Import — category selected ─────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-import-cat') {
      await interaction.deferUpdate();

      const category  = interaction.values[0];
      const items     = await getItemsByCategory(category);
      const available = items.filter(i => i.available);

      if (!available.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | لا يوجد منتجات متاحة في هذا الكتالوج`,
          embeds: [], components: [],
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setTitle('📥 | Import — ' + category)
        .setDescription(`> اختر المنتجات (حتى 10) — السعر يشمل **${(CUSTOMS_TAX * 100).toFixed(0)}%** جمارك`);

      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`reckmarket-import-items_${category}`)
          .setPlaceholder('اختر المنتجات')
          .setMinValues(1)
          .setMaxValues(Math.min(10, available.length))
          .addOptions(
            available.slice(0, 25).map(i => {
              const totalPrice = (i.price * (1 + CUSTOMS_TAX)).toFixed(2);
              return new StringSelectMenuOptionBuilder()
                .setLabel(`${i.item}`)
                .setDescription(`سعر الوحدة: ${formatMoney(totalPrice)} (شامل جمارك)`)
                .setValue(String(i.id));
            })
          )
      );

      return interaction.editReply({ embeds: [embed], components: [menu] });
    }

    // ── Import — items selected → modal ───────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('reckmarket-import-items_')) {
      const selectedItems = interaction.values;
      const category      = interaction.customId.replace('reckmarket-import-items_', '');

      const modal = new ModalBuilder()
        .setCustomId(`reckmarket-import-modal_${category}|${selectedItems.join('|')}`)
        .setTitle('استيراد منتجات | Import');

      for (const itemId of selectedItems.slice(0, 5)) {
        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId(`qty_${itemId}`)
              .setLabel(`ID: ${itemId} — الكمية (عدد الوحدات)`)
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('مثال: 50')
              .setRequired(true)
          )
        );
      }

      return interaction.showModal(modal);
    }

    // ── Import — modal submit ──────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('reckmarket-import-modal_')) {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const raw      = interaction.customId.replace('reckmarket-import-modal_', '');
      const parts    = raw.split('|');
      const category = parts[0];
      const itemIds  = parts.slice(1);

      const char  = await getOnlineChar(interaction.user.id);
      const store = await getStore();

      if (!store) {
        return interaction.editReply({ content: `<:No:1497627141465178132> | لم يتم تهيئة نظام المالية بعد` });
      }

      const catalogList = await getItemsByCategory(category);

      let totalCost = 0;
      const parsed  = [];

      for (const itemId of itemIds) {
        const value  = interaction.fields.getTextInputValue(`qty_${itemId}`);
        const amount = parseInt(value);
        if (!amount || amount < 1) continue;

        const catalogItem = catalogList.find(i => String(i.id) === String(itemId));
        if (!catalogItem) continue;

        const basePrice = catalogItem.price ?? 0;
        const unitCost  = parseFloat((basePrice * (1 + CUSTOMS_TAX)).toFixed(2));
        const lineCost  = parseFloat((unitCost * amount).toFixed(2));

        totalCost += lineCost;
        parsed.push({ itemName: catalogItem.item, amount, unitCost, lineCost });
      }

      if (!parsed.length) {
        return interaction.editReply({ content: `<:No:1497627141465178132> | لم يتم إدخال كميات صحيحة` });
      }

      if (store.total_balance < totalCost) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | رصيد خزنة البقالة غير كافٍ\n**التكلفة:** ${formatMoney(totalCost)}\n**الخزنة:** ${formatMoney(store.total_balance)}`,
        });
      }

      await updateBalance(-totalCost);

      const added   = [];
      let allSerials = [];

      for (const { itemName, amount, lineCost, unitCost } of parsed) {
        // كل وحدة بسيريال منفرد
        const serials = await importItems(itemName, category, unitCost, amount);
        allSerials = allSerials.concat(serials);
        added.push(`**${itemName}** x${amount} — ${formatMoney(lineCost)}`);
      }

      // Log
      const logChannel = client.channels.cache.get(ReckmarketImportLog);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('Reckmarket Log | Import')
          .setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Character:** ${char ? `${char.firstname} ${char.lastname}` : 'غير معروف'}
**National ID:** ${char ? char.national_id : 'غير معروف'}
**Job:** ${char ? char.job : 'غير معروف'}

─────────────────────

**Category:** ${category}
${added.join('\n')}

**Total Cost:** ${formatMoney(totalCost)} (شامل ${(CUSTOMS_TAX * 100).toFixed(0)}% جمارك)

**Serials:**
${allSerials.slice(0, 30).map(s => `- ${s}`).join('\n')}${allSerials.length > 30 ? `\n... و ${allSerials.length - 30} أخرى` : ''}`)
          .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
          .setFooter({ text: 'Reckmarket | Log', iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم استيراد المنتجات بنجاح\n${added.join('\n')}\n\n**التكلفة الإجمالية:** ${formatMoney(totalCost)}`,
      });
    }

    // ── Prices — category selected ─────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-prices-cat') {
      await interaction.deferUpdate();

      const category = interaction.values[0];
      const items    = await getStockByCategory(category);

      if (!items.length) {
        return interaction.editReply({
          content: `<:No:1497627141465178132> | لا يوجد منتجات في هذا الكتالوج`,
          embeds: [], components: [],
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setDescription('> اختر المنتج لتعديل سعره');

      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('reckmarket-prices-item')
          .setPlaceholder('اختر المنتج')
          .addOptions(
            items.slice(0, 25).map(i =>
              new StringSelectMenuOptionBuilder()
                .setLabel(`${i.item_name} — ${formatMoney(i.price)}`)
                .setValue(String(i.item_name))
            )
          )
      );

      return interaction.editReply({ embeds: [embed], components: [menu] });
    }

    // ── Prices — item selected → modal ────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'reckmarket-prices-item') {
      const itemName = interaction.values[0];

      const modal = new ModalBuilder()
        .setCustomId(`reckmarket-prices-modal_${itemName}`)
        .setTitle('تعديل السعر | Edit Price')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('new_price')
              .setLabel(`السعر الجديد لـ ${itemName}`)
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('مثال: 150')
              .setRequired(true)
          )
        );

      return interaction.showModal(modal);
    }

    // ── Prices — modal submit ──────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('reckmarket-prices-modal_')) {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const itemName = interaction.customId.replace('reckmarket-prices-modal_', '');
      const newPrice = parseFloat(interaction.fields.getTextInputValue('new_price').replace(/,/g, ''));

      if (isNaN(newPrice) || newPrice < 0) {
        return interaction.editReply({ content: `<:No:1497627141465178132> | سعر غير صحيح` });
      }

      await updateItemPrice(itemName, newPrice);

      return interaction.editReply({
        content: `<:Yes:1497627245873991750> | تم تحديث سعر **${itemName}** إلى **${formatMoney(newPrice)}**`,
      });
    }
  },
};