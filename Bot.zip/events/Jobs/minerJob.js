const { Events, MessageFlags, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const { Name } = require('../../JSON/config.json');

// أيدي روم لوغ الوظائف الخاصة بك
const JOBS_LOG_CHANNEL_ID = '1511457318985007304';

// 🌟 [ثابت اللفلات]: متطلبات الـ XP لكل مستوى (تراكمي بدون تصفير)
const JOB_LEVELS = [
  { level: 1, xpRequired: 50 },
  { level: 2, xpRequired: 100 },
  { level: 3, xpRequired: 200 },
  { level: 4, xpRequired: 350 },
  { level: 5, xpRequired: 500 },
  { level: 6, xpRequired: 750 },
  { level: 7, xpRequired: 1000 },
  { level: 8, xpRequired: 1850 },
  { level: 9, xpRequired: 3000 },
  { level: 10, xpRequired: 10000 }
];

// دالة برمجة مساعدة لحساب اللفل الحالي بناءً على إجمالي الـ XP التراكمي
function calculateLevel(currentXp) {
  let currentLevel = 0;
  for (const lvl of JOB_LEVELS) {
    if (currentXp >= lvl.xpRequired) {
      currentLevel = lvl.level;
    } else {
      break;
    }
  }
  return currentLevel;
}

// تعريف موارد المنجم ونسبها وأسعارها
const MINER_RESOURCES = [
  { name: 'Copper', chance: 0.90, price: 0.2, minQty: 1, maxQty: 10 },
  { name: 'Gun Powder', chance: 0.60, price: 2.0, minQty: 1, maxQty: 10 },
  { name: 'Steel', chance: 0.50, price: 3.0, minQty: 1, maxQty: 10 },
  { name: 'Plastic', chance: 0.50, price: 1.0, minQty: 1, maxQty: 10 },
  { name: 'Iron', chance: 0.30, price: 10.0, minQty: 1, maxQty: 10 }
];

// كائنات في الذاكرة لتتبع نظام التعب ونظام متانة البكاكس
const minerCooldowns = new Map();
const pickaxeDurability = new Map();

module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction, client) {
    try {
      if (!interaction.isButton()) return;

      const { customId } = interaction;

      // =========================================================================
      // 1. تفاعل إلغاء الوردية (خاص البوت)
      // =========================================================================
      if (customId === 'miner_cancel_shift') {
        await interaction.deferUpdate();
        return interaction.editReply({
          components: [
            new ContainerBuilder()
              .setAccentColor(0x3A0008)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent('❌ تم إلغاء بدء نوبة عمل التعدين بناءً على طلبك.'))
          ],
          flags: MessageFlags.IsComponentsV2
        });
      }

      // =========================================================================
      // 2. تفاعل تأكيد التكسير والتجميع مدمج معه الجوع، العطش، البكاكس ونظام الـ XP والـ Levels
      // =========================================================================
      if (customId.startsWith('miner_confirm_start_') || customId.startsWith('miner_mine_again_')) {
        await interaction.deferUpdate();

        const charNum = customId.split('_').pop();
        
        // جلب بيانات الشخصية المتصلة للتحقق من المؤشرات الحيوية والـ XP من حقل JOB_XP
        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ? AND character_number = ?`, [interaction.user.id, charNum]);
        const onlineChar = chars[0];

        if (!onlineChar || onlineChar.status !== 'ONLINE') {
          return interaction.editReply({ 
            components: [
              new ContainerBuilder()
                .setAccentColor(0x3A0008)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent('<:Warn:1497627240177991780> | انتهت جلستك أو أن شخصيتك الحالية غير متصلة الآن.'))
            ], 
            flags: MessageFlags.IsComponentsV2 
          });
        }

        // قراءة الـ XP التراكمي وحساب المستوى الحالي للشخصية قبل معالجة الضربة
        const playerXpBefore = onlineChar.JOB_XP || 0;
        const playerLevel = calculateLevel(playerXpBefore);

        // [شرط البكاكس]: التحقق من وجود أداة Pickaxe في حقيبة الشخصية
        const [pickaxeCheck] = await pool.query(
          `SELECT id FROM inventory WHERE user_id = ? AND character_number = ? AND item_name = 'Pickaxe' LIMIT 1`,
          [interaction.user.id, onlineChar.character_number]
        );

        if (pickaxeCheck.length === 0) {
          const noPickaxeContainer = new ContainerBuilder()
            .setAccentColor(0x3A0008)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:No:1497627141465178132> | أداة العمل مفقودة!`))
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`> ⚠️ عذراً يا **${onlineChar.firstname}**، لا يمكنك بدء أو مواصلة التنقيب لأنك لا تملك **Pickaxe (معول تعدين)** في حقيبتك حالياً.\n\n> 🛒 يرجى شراء **Pickaxe** جديد لتتمكن من تكسير الصخور واستخراج الموارد.`)
            );

          return interaction.editReply({
            components: [noPickaxeContainer],
            flags: MessageFlags.IsComponentsV2
          });
        }

        // تهيئة متانة البكاكس في الذاكرة (عشوائي بين 6 إلى 8 ضربات)
        if (!pickaxeDurability.has(interaction.user.id)) {
          const randomLifetime = Math.floor(Math.random() * (8 - 6 + 1)) + 6;
          pickaxeDurability.set(interaction.user.id, randomLifetime);
        }

        // [نظام فحص المؤشرات الحيوية]: التحقق من الجوع والعطش (يجب ألا يقلا عن 30%)
        if (onlineChar.hunger < 30 || onlineChar.thirst < 30) {
          const vitalContainer = new ContainerBuilder()
            .setAccentColor(0x3A0008)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:No:1497627141465178132> | إرهاق جسدي حاد!`))
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`> <:Warn:1497627240177991780> يا **${onlineChar.firstname}**، مؤشراتك الحيوية ضعيفة جداً وتكاد يغمى عليك!\n\n> 🍗 الجوع: **${Math.floor(onlineChar.hunger)}%** | 💧 العطش: **${Math.floor(onlineChar.thirst)}%**\n\n**يرجى تناول الطعام والشراب أولاً قبل العودة للعمل الشاق.**`)
            );

          return interaction.editReply({
            components: [vitalContainer],
            flags: MessageFlags.IsComponentsV2
          });
        }

        // معالجة وتحديث مستويات استنزاف الجوع والعطش (5% - 15%)
        const hungerLoss = Math.floor(Math.random() * (15 - 5 + 1)) + 5;
        const thirstLoss = Math.floor(Math.random() * (15 - 5 + 1)) + 5;

        // 🌟 [ميزة السرعة بناءً على اللفل]: الوقت الأساسي يقل بمقدار 250 ملي ثانية عن كل لفل يمتلكه اللاعب
        const miningDuration = Math.max(1500, 4000 - (playerLevel * 250)); 

        // تشغيل واجهة الـ Loading المتوافقة مع V2
        const loadingContainer = new ContainerBuilder()
          .setAccentColor(0x3A0008)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ⛏️ | Mining In Progress... [LVL ${playerLevel}]`))
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> يتم الآن تكسير الصخور ومعالجتها...\n> سرعة التكسير الحالية: **${(miningDuration / 1000).toFixed(2)} ثانية**.\n\n⚡ استهلاك المجهود: **-${hungerLoss}%** جوع و **-${thirstLoss}%** عطش.`)
          )
          .addMediaGalleryComponents(
            new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL('https://i.imgur.com/vH2gbyG.gif'))
          );

        await interaction.editReply({
          components: [loadingContainer],
          flags: MessageFlags.IsComponentsV2
        });

        // الانتظار الفني المرن القائم على مستوى اللفل لسرعة تكسير واقعية
        await new Promise(resolve => setTimeout(resolve, miningDuration));

        // 🌟 [ميزة نسب الـ XP بناءً على اللفل]: الأساسي بين 1 و 10، ويضاف بونص للحد الأقصى بمقدار +2 عن كل لفل
        const minXpGive = 1;
        const maxXpGive = 10 + (playerLevel * 2);
        const generatedXp = Math.floor(Math.random() * (maxXpGive - minXpGive + 1)) + minXpGive;
        const newTotalXp = playerXpBefore + generatedXp;
        const playerNewLevel = calculateLevel(newTotalXp);

        // التحقق مما إذا ارتفع لفل اللاعب (Level Up)
        const leveledUp = playerNewLevel > playerLevel;

        // 🌟 [ميزة كميات الموارد بناءً على اللفل]: معامل مضاعف يرفع حد تجميع الكميات بشكل منطقي تدريجي
        const levelMultiplier = 1 + (playerNewLevel * 0.1);

        // حساب الموارد العشوائية بناءً على الاحتماليات في جدول الحقيبة
        const availableCount = Math.min(
  MINER_RESOURCES.length,
  Math.floor(Math.random() * 3) + 1 + Math.floor(playerNewLevel / 3)
);
        const shuffledResources = [...MINER_RESOURCES].sort(() => 0.5 - Math.random());
        const chosenTypes = shuffledResources.slice(0, availableCount);

        let rewardedItemsSummary = [];
        let logSummaryText = [];

        for (const res of chosenTypes) {

  // زيادة الحظ 5% لكل لفل
  const luckMultiplier = 1 + (playerNewLevel * 0.05);

  // حساب النسبة النهائية
  const finalChance = Math.min(
    res.chance * luckMultiplier,
    0.99
  );

  const roll = Math.random();

  if (roll <= finalChance) {

    const calculatedMin = Math.floor(res.minQty * levelMultiplier);
    const calculatedMax = Math.floor(res.maxQty * levelMultiplier);

    const randomQty =
      Math.floor(
        Math.random() *
        (calculatedMax - calculatedMin + 1)
      ) + calculatedMin;

    const [itemRows] = await pool.query(
      `SELECT * FROM items WHERE item_name = ?`,
      [res.name]
    );

    if (itemRows.length > 0) {

      for (let i = 0; i < randomQty; i++) {

        const generatedSerial =
          `MIN-${Math.floor(100000 + Math.random() * 900000)}`;

        await pool.query(
          `INSERT INTO inventory
          (user_id, character_number, item_name, item_serial, category, available, used)
          VALUES (?, ?, ?, ?, 'misc', 1, 0)`,
          [
            interaction.user.id,
            onlineChar.character_number,
            res.name,
            generatedSerial
          ]
        );
      }

      rewardedItemsSummary.push(
        `- **${res.name}** | الكمية: \`${randomQty}\` وحدات | الحظ ${(finalChance * 100).toFixed(0)}%`
      );

      logSummaryText.push(
        `${res.name} (x${randomQty}) [Luck ${(finalChance * 100).toFixed(0)}%]`
      );
    }
  }
}

        if (rewardedItemsSummary.length === 0) {
          rewardedItemsSummary.push(`- لم تتمكن من استخراج أي موارد صالحة هذه المرة، حاول تكسير صخرة أخرى.`);
          logSummaryText.push(`None (Unlucky Roll)`);
        }

        // تحديث البيانات فوراً في الـ MySQL وتخزين الـ XP الجديد في عمود JOB_XP
        await pool.query(
  `UPDATE characters
   SET
     hunger = GREATEST(0, hunger - ?),
     thirst = GREATEST(0, thirst - ?),
     JOB_XP = ?,
     job_level = ?
   WHERE user_id = ? AND character_number = ?`,
  [
    hungerLoss,
    thirstLoss,
    newTotalXp,
    playerNewLevel,
    interaction.user.id,
    onlineChar.character_number
  ]
);

        // خصم ضربة واحدة من متانة البكاكس الحالي في الذاكرة
        let remainingStrikes = pickaxeDurability.get(interaction.user.id) - 1;
        pickaxeDurability.set(interaction.user.id, remainingStrikes);

        let pickaxeBroken = false;

        if (remainingStrikes <= 0) {
          pickaxeBroken = true;
          pickaxeDurability.delete(interaction.user.id);

          await pool.query(
            `DELETE FROM inventory WHERE user_id = ? AND character_number = ? AND item_name = 'Pickaxe' LIMIT 1`,
            [interaction.user.id, onlineChar.character_number]
          );
        }

        // تتبع عدد الضربات لنظام الراحة والـ Timeout العام
        let userStrikes = minerCooldowns.get(interaction.user.id) || 0;
        userStrikes += 1;
        minerCooldowns.set(interaction.user.id, userStrikes);

        if (pickaxeBroken) {
          minerCooldowns.set(interaction.user.id, 0);

          const brokenContainer = new ContainerBuilder()
            .setAccentColor(0x3A0008)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 💥 | انكسر معول التعدين الخاص بك!`))
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`> 🛑 لقد تحطم الـ **Pickaxe** تماماً نتيجة الاستهلاك العالي أثناء العمل الصخري.\n\n**الموارد الأخيرة المستخرجة:**\n${rewardedItemsSummary.join('\n')}\n\n✨ حصلت أيضاً على **+${generatedXp}XP** تراكمي.\n\n⚠️ **يجب عليك تزويد حقيبتك بـ Pickaxe جديد لتتمكن من التعدين مرة أخرى.**`)
            )
            .addActionRowComponents(
              new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('miner_finish_shift').setLabel('End Shift & Return').setStyle(ButtonStyle.Danger)
              )
            );

          await interaction.editReply({ components: [brokenContainer], flags: MessageFlags.IsComponentsV2 });
          return;
        }

        // =========================================================================
        // 🌟 [نظام الراحة المتقدم والمسرّع بناءً على اللفل]
        // =========================================================================
        if (userStrikes >= 5) {
          minerCooldowns.set(interaction.user.id, 0);
          
          // الحساب الديناميكي لوقت الراحة: يبدأ من 30 ثانية ويقل بمقدار ثانيتين عن كل لفل (حد أدنى 10 ثوانٍ لضمان بقاء عامل الواقعية)
          let timeLeft = Math.max(10, 30 - (playerNewLevel * 2));

          const interval = setInterval(async () => {
            timeLeft -= 1;

            if (timeLeft <= 0) {
              clearInterval(interval);

              const readyContainer = new ContainerBuilder()
                .setAccentColor(0x3A0008)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ✅ | استعادت الشخصية قوتها`))
                .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent(`> لقد ارتاحت شخصيتك **${onlineChar.firstname}** تماماً وجاهزة الآن للعودة للتنقيب الشاق بكامل قوتها.`)
                )
                .addActionRowComponents(
                  new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`miner_mine_again_${onlineChar.character_number}`).setLabel('Break Another Rock').setEmoji('⛏️').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('miner_finish_shift').setLabel('End Shift').setStyle(ButtonStyle.Danger)
                  )
                );

              return interaction.editReply({ components: [readyContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
            }

            const restContainer = new ContainerBuilder()
              .setAccentColor(0x3A0008)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ⏳ | الشخصية متعبة (نظام الواقعية)`))
              .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`> ⚠️ لقد بذلت مجهوداً شاقاً في تكسير 5 صخور متتالية!\n> يرجى الانتظار: **${timeLeft}** ثانية للراحة والتقاط الأنفاس...\n\n⚡ *ملاحظة: لفل وظيفتك الحالي [LVL ${playerNewLevel}] يجعل استرجاع طاقتك أسرع!*`)
              )
              .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                  new ButtonBuilder().setCustomId('disabled_mine').setLabel(`متعب جداً (${timeLeft}s)`).setStyle(ButtonStyle.Secondary).setDisabled(true),
                  new ButtonBuilder().setCustomId('miner_finish_shift').setLabel('End Shift').setStyle(ButtonStyle.Danger)
                )
              );

            await interaction.editReply({ components: [restContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => clearInterval(interval));
          }, 1000);

          const fatigueContainer = new ContainerBuilder()
            .setAccentColor(0x3A0008)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ⏳ | الشخصية متعبة (نظام الواقعية)`))
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`> ⚠️ لقد بذلت مجهوداً شاقاً في تكسير 5 صخور متتالية!\n> يرجى الانتظار: **${timeLeft}** ثانية للراحة قبل تكسير حجر آخر...\n\n⚡ *ملاحظة: لفل وظيفتك الحالي [LVL ${playerNewLevel}] يجعل استرجاع طاقتك أسرع!*`)
            )
            .addActionRowComponents(
              new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('disabled_mine').setLabel(`متعب جداً (${timeLeft}s)`).setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('miner_finish_shift').setLabel('End Shift').setStyle(ButtonStyle.Danger)
              )
            );

          return interaction.editReply({ components: [fatigueContainer], flags: MessageFlags.IsComponentsV2 });
        }

        // إعداد نص التقرير وإضافة تهنئة خاصة في حال ارتفع المستوى (Level Up 🎉)
        let reportTitle = `# 📦 | Mining Operation Report`;
        let levelUpMessage = ``;
        if (leveledUp) {
          reportTitle = `# 🎉 | LEVEL UP! LEVEL ${playerNewLevel}`;
          levelUpMessage = `\n**🎊 تهانينا الشديدة! لقد ارتفع مستوى خبرتك المهنية رسمياً إلى [Level ${playerNewLevel}]، سرعة تكسيرك ووقت استرداد طاقتك أصبحت أسرع، وكميات الموارد ونسب الـ XP الممنوحة لك تضاعفت الآن!**\n`;
        }

        // واجهة التقرير الطبيعي شاملة الـ XP الجديد
        const finalContainer = new ContainerBuilder()
          .setAccentColor(0x3A0008)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(reportTitle))
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> عمل ممتاز يا **${onlineChar.firstname}**! تم تكسير الصخرة الحالية واكتمل التحميل.\n${levelUpMessage}\n**الموارد التي تم نقلها لحقيبتك:**\n${rewardedItemsSummary.join('\n')}\n\n📊 **مؤشرات الخبرة والتطوير:**\n> 🌟 الـ XP الممنوح حالياً: **+${generatedXp} XP**\n> 📈 إجمالي الـ XP التراكمي: **${newTotalXp} JOB_XP**\n> 🎖️ لفل الوظائف الحالي لشخصيتك: **Level ${playerNewLevel}**\n\n> 📋 الضربات المتبقية قبل التعب: **${5 - userStrikes}/5** ضربات.\n> 🛠️ جودة الـ Pickaxe: متبقي له **${remainingStrikes}** ضربات تقريبية قبل التلف.`)
          )
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId(`miner_mine_again_${onlineChar.character_number}`).setLabel('Break Another Rock').setEmoji('⛏️').setStyle(ButtonStyle.Success),
              new ButtonBuilder().setCustomId('miner_finish_shift').setLabel('End Shift').setStyle(ButtonStyle.Danger)
            )
          );

        await interaction.editReply({
          components: [finalContainer],
          flags: MessageFlags.IsComponentsV2
        });

        // إرسال اللوغ المخصص إلى روم اللوغز
        const logChannel = interaction.client.channels.cache.get(JOBS_LOG_CHANNEL_ID);
        if (logChannel) {
          const mineLogEmbed = new EmbedBuilder()
            .setTitle('Mining System Log | XP Progress & Leveling Up')
            .setDescription(`**Miner Details:**\nCitizen: <@${interaction.user.id}>\nCharacter: **${onlineChar.firstname} ${onlineChar.lastname}**\n\n**XP & Level Progression:**\nXP Added: **+${generatedXp} XP**\nTotal Accumulated XP (Stored in JOB_XP): **${newTotalXp} XP**\nCalculated Job Level: **Level ${playerNewLevel}** ${leveledUp ? '📈 (LEVEL UP EVENT)' : ''}\n\n**Gathering Results:**\nItems Appended (Level Multiplier: x${levelMultiplier.toFixed(1)}):\n\`\`\`\n${logSummaryText.join('\n')}\n\`\`\`\nStatus: Core Data Updated Successfully ✅`)
            .setColor('#3A0008')
            .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
            .setFooter({ text: `${Name} | Leveling & Job Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

          await logChannel.send({ embeds: [mineLogEmbed] }).catch(() => {});
        }
      }

      // =========================================================================
      // 3. تفاعل إنهاء وردية العمل والتعدين بالكامل
      // =========================================================================
      if (customId === 'miner_finish_shift') {
        await interaction.deferUpdate();
        minerCooldowns.delete(interaction.user.id);

        return interaction.editReply({
          components: [
            new ContainerBuilder()
              .setAccentColor(0x3A0008)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent('<:Yes:1497627245873991750> | بارك الله لك في عملك. تم إنهاء نوبة عمل التعدين بنجاح وحفظ كافة بيانات الـ JOB_XP والخبرة المهنية لشخصيتك بسجلات المدينة.'))
          ],
          flags: MessageFlags.IsComponentsV2
        });
      }

    } catch (error) {
      console.error('Error in miner job interactive handler:', error);
    }
  }
};