const { Events, MessageFlags, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const { Name } = require('../../JSON/config.json');

// الوظائف المسموح التقديم عليها وبدء العمل فيها
const ALLOWED_JOBS = ['Taxi Driver', 'Miner', 'Pizza Delivery', 'Security Company'];
// أيدي روم لوغ الوظائف الخاصة بك
const JOBS_LOG_CHANNEL_ID = '1511457318985007304';

module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction, client) {
    try {
      const { customId } = interaction;

      // =========================================================================
      // 1. التفاعل مع الزر الرئيسي لمكتب الوظائف
      // =========================================================================
      if (interaction.isButton() && customId === 'jobs_main_menu') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        if (!chars.length) {
          return interaction.editReply({ 
            components: [
              new ContainerBuilder()
                .setAccentColor(0x3A0008)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`))
            ],
            flags: MessageFlags.IsComponentsV2 
          });
        }

        const onlineChar = chars.find(c => c.status === 'ONLINE');
        if (!onlineChar) {
          return interaction.editReply({ 
            components: [
              new ContainerBuilder()
                .setAccentColor(0x3A0008)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا (يجب أن تكون متصلاً)'))
            ],
            flags: MessageFlags.IsComponentsV2 
          });
        }

        const currentJob = onlineChar.job ? onlineChar.job.trim() : 'Unemployed';
        const isUnemployed = currentJob.toLowerCase() === 'unemployed' || currentJob === 'مواطن' || currentJob === '';

        const jobContainer = new ContainerBuilder()
          .setAccentColor(0x3A0008)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:Logo:1497624868827693096> | Job Management`))
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> <:people:1497627159341174814> | الاسم: **${onlineChar.firstname} ${onlineChar.lastname}**\n> الوظيفة الحالية: **${currentJob}**\n\nيرجى اختيار الإجراء المطلوب من الأسفل بناءً على وضعك المهني الحالي.`)
          );

        const buttonsRow = new ActionRowBuilder();

        if (isUnemployed) {
          buttonsRow.addComponents(
            new ButtonBuilder()
              .setCustomId('jobs_search_work')
              .setLabel('Search for Work')
              .setEmoji('<:choose:1497627026708762764>')
              .setStyle(ButtonStyle.Secondary)
          );
        } else {
          if (ALLOWED_JOBS.includes(currentJob)) {
            buttonsRow.addComponents(
              new ButtonBuilder()
                .setCustomId('jobs_start_work')
                .setLabel('Start Work')
                .setEmoji('<:arrow:1499868235380555827>')
                .setStyle(ButtonStyle.Success)
            );

            if (currentJob === 'Miner') {
              buttonsRow.addComponents(
                new ButtonBuilder()
                  .setCustomId('jobs_miner_sell')
                  .setLabel('Sell Minerals')
                  .setEmoji('<:give:1499868298341515344>')
                  .setStyle(ButtonStyle.Secondary)
              );
            }
          }

          buttonsRow.addComponents(
            new ButtonBuilder()
              .setCustomId(`jobs_resign_${onlineChar.character_number}`)
              .setLabel('Resign from Job')
              .setEmoji('<:No:1497627141465178132>')
              .setStyle(ButtonStyle.Danger)
          );
        }

        await interaction.editReply({
          components: buttonsRow.components.length > 0 ? [jobContainer.addActionRowComponents(buttonsRow)] : [jobContainer],
          flags: MessageFlags.IsComponentsV2
        });
      }

      // =========================================================================
      // 2. التفاعل مع زر "تقديم الاستقالة"
      // =========================================================================
      if (interaction.isButton() && customId.startsWith('jobs_resign_')) {
        await interaction.deferUpdate();

        const charNum = customId.split('_').pop();
        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ? AND character_number = ?`, [interaction.user.id, charNum]);
        const onlineChar = chars[0];

        if (!onlineChar || onlineChar.status !== 'ONLINE') {
          return interaction.editReply({
            components: [
              new ContainerBuilder()
                .setAccentColor(0x3A0008)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent('<:Warn:1497627240177991780> | عذراً، شخصيتك الحالية غير متصلة بالمدينة الآن.'))
            ],
            flags: MessageFlags.IsComponentsV2
          });
        }

        const oldJobName = onlineChar.job || 'Unknown';

        await pool.query(
          `UPDATE characters SET job = 'Unemployed' WHERE user_id = ? AND character_number = ?`,
          [interaction.user.id, onlineChar.character_number]
        );

        const resignContainer = new ContainerBuilder()
          .setAccentColor(0x3A0008)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:Yes:1497627245873991750> | Resignation Accepted`))
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> تم معالجة طلبك وقبول استقالتك رسمياً من السجلات الجنائية والمهنية للمدينة.\n\n<:tag:1497627214374768700> المواطن: **${onlineChar.firstname} ${onlineChar.lastname}**\n<:tag:1497627214374768700> الوظيفة السابقة: **${oldJobName}**\n<:tag:1497627214374768700> الحالة المهنية الحالية: **عاطل عن العمل (Unemployed)**`)
          );

        await interaction.editReply({
          components: [resignContainer],
          flags: MessageFlags.IsComponentsV2
        });

        const logChannel = interaction.client.channels.cache.get(JOBS_LOG_CHANNEL_ID);
        if (logChannel) {
          const resignLogEmbed = new EmbedBuilder()
            .setTitle('Job System Log | Resignation')
            .setDescription(`**Citizen Info:**\nUser: <@${interaction.user.id}> (${interaction.user.id})\nUsername: ${interaction.user.username}\nTime: ${DateTime.now().setZone('Asia/Amman').toISO()}\n\nCharacter Number: #${onlineChar.character_number}\nFull Name: ${onlineChar.firstname} ${onlineChar.lastname}\n\n----------------------------\n\n**Resignation Action:**\nResigned From: **${oldJobName}**\nNew Status: Unemployed ❌`)
            .setColor('#3A0008')
            .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
            .setFooter({ text: `${Name} | Resign Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

          await logChannel.send({ embeds: [resignLogEmbed] }).catch(() => {});
        }
      }

      // =========================================================================
      // 3. التفاعل مع زر "البحث عن وظيفة" (عرض المنيو)
      // =========================================================================
      if (interaction.isButton() && customId === 'jobs_search_work') {
        await interaction.deferUpdate();

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const onlineChar = chars.find(c => c.status === 'ONLINE');
        if (!onlineChar) return interaction.editReply({ content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا', components: [] });

        const menuOptions = ALLOWED_JOBS.map(jobName => ({
          label: jobName,
          description: `التقديم على وظيفة ${jobName}`,
          value: `apply_${jobName}`
        }));

        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId('jobs_select_apply')
          .setPlaceholder('Choose a job to apply for...')
          .addOptions(menuOptions);

        const menuContainer = new ContainerBuilder()
          .setAccentColor(0x3A0008)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:choose:1497627026708762764> | Available Vacancies`))
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> مرحبًا بك يا **${onlineChar.firstname}** في قائمة الوظائف الشاغرة.\n\nالرجاء اختيار الوظيفة المناسبة لك من القائمة المنسدلة أدناه للتوظيف الفوري بدقة واحترافية.`)
          )
          .addActionRowComponents(new ActionRowBuilder().addComponents(selectMenu));

        await interaction.editReply({
          components: [menuContainer],
          flags: MessageFlags.IsComponentsV2
        });
      }

      // =========================================================================
      // 4. التفاعل مع قائمة اختيار الوظيفة وتعديل الداتا وإرسال اللوغ
      // =========================================================================
      if (interaction.isStringSelectMenu() && customId === 'jobs_select_apply') {
        await interaction.deferUpdate();

        const chosenValue = interaction.values[0];
        const newJobName = chosenValue.replace('apply_', '');

        if (!ALLOWED_JOBS.includes(newJobName)) {
          return interaction.editReply({ content: '❌ اختيار غير صحيح لمسميات الوظائف.', components: [] });
        }

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const onlineChar = chars.find(c => c.status === 'ONLINE');
        if (!onlineChar) return interaction.editReply({ content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا', components: [] });

        await pool.query(
          `UPDATE characters SET job = ? WHERE user_id = ? AND character_number = ?`,
          [newJobName, interaction.user.id, onlineChar.character_number]
        );

        const successContainer = new ContainerBuilder()
          .setAccentColor(0x3A0008)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:Yes:1497627245873991750> | Employment Successful`))
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> تهانينا! تم قبول طلب توظيفك بنجاح.\n\n<:tag:1497627214374768700> الموظف: **${onlineChar.firstname} ${onlineChar.lastname}**\n<:tag:1497627214374768700> الوظيفة الجديدة: **${newJobName}**\n\nيمكنك الآن إغلاق هذه القائمة والبدء في كسب لقمة العيش بكفاءة.`)
          );

        await interaction.editReply({
          components: [successContainer],
          flags: MessageFlags.IsComponentsV2
        });

        const logChannel = interaction.client.channels.cache.get(JOBS_LOG_CHANNEL_ID);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('Job System Log | Employment')
            .setDescription(`**Citizen Info:**\nUser: <@${interaction.user.id}> (${interaction.user.id})\nUsername: ${interaction.user.username}\nTime: ${DateTime.now().setZone('Asia/Amman').toISO()}\n\nCharacter Number: #${onlineChar.character_number}\nFull Name: ${onlineChar.firstname} ${onlineChar.lastname}\nNational ID: ${onlineChar.national_id}\n\n----------------------------\n\n**Employment Action:**\nOld Job: Unemployed / Citizen\nNew Job: **${newJobName}**\nStatus: Hired Successfully ✅`)
            .setColor('#3A0008')
            .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
            .setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

          await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      }

      // =========================================================================
      // 5. التفاعل مع زر بدأ العمل "Start Work" ونقل الجلسة لخاص البوت
      // =========================================================================
      if (interaction.isButton() && customId === 'jobs_start_work') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const onlineChar = chars.find(c => c.status === 'ONLINE');
        if (!onlineChar) {
          return interaction.editReply({ content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا (يجب أن تكون متصلاً)' });
        }

        const currentJob = onlineChar.job ? onlineChar.job.trim() : 'Unemployed';

        if (currentJob === 'Miner') {
          try {
            const dmContainer = new ContainerBuilder()
              .setAccentColor(0x3A0008)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:Logo:1497624868827693096> | Mining Shift Confirmation`))
              .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`> مرحبًا بك يا **${onlineChar.firstname}** في مركز إدارة المناجم.\n\nهل أنت متأكد من رغبتك في بدء نوبة العمل الحالية وبدء تكسير الصخور للمنجم؟`)
              )
              .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                  new ButtonBuilder()
                    .setCustomId(`miner_confirm_start_${onlineChar.character_number}`)
                    .setLabel('Start Rock Breaking')
                    .setEmoji('<:arrow:1499868235380555827>')
                    .setStyle(ButtonStyle.Success),
                  new ButtonBuilder()
                    .setCustomId('miner_cancel_shift')
                    .setLabel('Cancel')
                    .setStyle(ButtonStyle.Danger)
                )
              );

            await interaction.user.send({
              components: [dmContainer],
              flags: MessageFlags.IsComponentsV2
            });

            return interaction.editReply({
              components: [
                new ContainerBuilder()
                  .setAccentColor(0x3A0008)
                  .addTextDisplayComponents(new TextDisplayBuilder().setContent(`<:Yes:1497627245873991750> | تم بدء نوبة العمل بنجاح! يرجى التوجه فوراً إلى **خاص البوت (DM)** لتأكيد وبدء مهام تكسير الحجر.`))
              ],
              flags: MessageFlags.IsComponentsV2
            });

          } catch (dmError) {
            return interaction.editReply({
              components: [
                new ContainerBuilder()
                  .setAccentColor(0x3A0008)
                  .addTextDisplayComponents(new TextDisplayBuilder().setContent(`<:No:1497627141465178132> | فشل إرسال التعليمات إلى الخاص بك. تأكد من فتح خاص الحساب (DMs) أولاً ثم أعد المحاولة.`))
              ],
              flags: MessageFlags.IsComponentsV2
            });
          }
        } else {
          return interaction.editReply({ content: `> <:Warn:1497627240177991780> | نظام نوبات العمل لوظيفة **${currentJob}** تحت التطوير البرمجي حالياً.` });
        }
      }

    } catch (error) {
      console.error('Error in main job interaction handler:', error);
    }
  }
};