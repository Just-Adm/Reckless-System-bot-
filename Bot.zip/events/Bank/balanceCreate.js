const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require('discord.js');
const { pool } = require('../../utils/database/mysql');

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    if (interaction.isButton() && interaction.customId === 'mazebank-balance') {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
      }

      const char = rows.find(c => c.status === 'ONLINE') || null;

      if (!char) {
        return interaction.editReply(`<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`);
      }

      const cash  = isNaN(char.cash)  ? 0 : char.cash;
      const bank  = isNaN(char.bank)  ? 0 : char.bank;
      const total = cash + bank;

      const container = new ContainerBuilder()
        .setAccentColor(0xd40909)

        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `> Maze Bank — Account Balance`
          )
        )

        .addSeparatorComponents(
          new SeparatorBuilder()
            .setDivider(true)
            .setSpacing(SeparatorSpacingSize.Small)
        )

        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
`**<:Wallet:1497627232682774588> Cash:** $${cash.toLocaleString()}
**<:Bank:1388227015798423613> Bank:** $${bank.toLocaleString()}
              
**<:Money:1497627135920308405> Total:** $${total.toLocaleString()}`
          )
        )

        .addSeparatorComponents(
          new SeparatorBuilder()
            .setDivider(true)
            .setSpacing(SeparatorSpacingSize.Small)
        )

        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `-# ${char.firstname} ${char.lastname} — ${char.iban}`
          )
        );

      return interaction.editReply({
        components: [container],
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
      });
    }
  }
};