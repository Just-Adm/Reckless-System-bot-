const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { pool } = require('../../utils/database/mysql');

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    if (interaction.isButton() && interaction.customId === 'mazebank') {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
      }

      const char = rows.find(c => c.status === 'ONLINE') || rows[0];

      if (!char) {
        return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');
      }

      const bankBalance = char.bank || 0;

      const baseButtons = [
        new ButtonBuilder()
          .setCustomId('mazebank-balance')
          .setLabel('Balance')
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setCustomId('mazebank-withdraw')
          .setLabel('Withdraw')
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setCustomId('mazebank-deposit')
          .setLabel('Deposit')
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setCustomId('mazebank-transfer')
          .setLabel('Transfer')
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setCustomId('mazebank-transactions')
          .setLabel('Transactions')
          .setStyle(ButtonStyle.Secondary),
      ];

      if (bankBalance > 10000) {
        baseButtons.push(
          new ButtonBuilder()
            .setCustomId('mazebank-loans')
            .setLabel('Loans')
            .setDisabled(true)
            .setStyle(ButtonStyle.Success)
        );
      }

      const container = new ContainerBuilder()
        .setAccentColor(0x2f3136)

        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `# Welcome Back **${char.firstname} ${char.lastname}**`
          )
        )

        .addSeparatorComponents(
          new SeparatorBuilder()
            .setDivider(true)
            .setSpacing(SeparatorSpacingSize.Small)
        )

        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**Choose the action you want**\n\n-# <:tag:1497627214374768700> IBAN: **\`${char.iban}\`**`
          )
        )

        .addSeparatorComponents(
          new SeparatorBuilder()
            .setDivider(true)
            .setSpacing(SeparatorSpacingSize.Large)
        )

        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            baseButtons[0],
            baseButtons[1],
            baseButtons[2]
          )
        )

        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            ...baseButtons.slice(3)
          )
        );

      return interaction.editReply({
        components: [container],
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
      });
    }
  }
};