const {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
  ContainerBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  TextDisplayBuilder,
  componentType
} = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');

const ITEMS_PER_PAGE = 3;

function buildTransactionsContainer(char, transactions, page, totalPages) {
  const start = page * ITEMS_PER_PAGE;
  const pageTx = transactions.slice(start, start + ITEMS_PER_PAGE);

  const container = new ContainerBuilder();

  // Header
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `# Maze Bank — Transaction History\n**${char.firstname} ${char.lastname}** • \`${char.iban}\` — Page ${page + 1} of ${totalPages}`
    )
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Large)
  );

  if (!pageTx.length) {
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent('No transactions found.')
    );
    return container;
  }

  pageTx.forEach((tx, i) => {
    const globalIndex = transactions.length - (start + i);
    const amount = Number(tx.amount);
    const tax = Math.ceil(amount * 0.025);
    const net = amount - tax;
    const date = DateTime.fromJSDate(new Date(tx.created_at))
      .setZone('Asia/Amman')
      .toFormat('dd/MM/yyyy HH:mm');

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        [
          `**#${globalIndex}** — \`${tx.type}\``,
          `**Amount:** $${amount.toLocaleString()}  **Tax:** $${tax.toLocaleString()} • **Net:** $${net.toLocaleString()}`,
          `**Reason:** ${tx.reason}`,
          `**Date:** ${date}`
        ].join('\n')
      )
    );

    // فاصل بين كل عملية وعملية ما عدا الأخيرة
    if (i < pageTx.length - 1) {
      container.addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Large)
      );
    }
  });

  return container;
}

function buildButtons(page, totalPages) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('mazebank-tx-prev')
      .setLabel('◀ Previous')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page === 0),

    new ButtonBuilder()
      .setCustomId('mazebank-tx-page')
      .setLabel(`${page + 1} / ${totalPages}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(true),

    new ButtonBuilder()
      .setCustomId('mazebank-tx-next')
      .setLabel('Next ▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page === totalPages - 1)
  );
}

// حفظ sessions مؤقتة في الذاكرة
const sessions = new Map();

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    // ===================== BUTTON - فتح التحويلات =====================
    if (interaction.isButton() && interaction.customId === 'mazebank-transactions') {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
      }

      const char = rows.find(c => c.status === 'ONLINE') || null;
      if (!char) {
        return interaction.editReply(`<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`);
      }

      const [txRows] = await pool.query(
        `SELECT * FROM bank_transactions WHERE iban = ? ORDER BY created_at DESC`,
        [char.iban]
      );

      const totalPages = Math.max(1, Math.ceil(txRows.length / ITEMS_PER_PAGE));
      const page = 0;

      sessions.set(interaction.user.id, {
        char,
        transactions: txRows,
        page,
        totalPages
      });

      const container = buildTransactionsContainer(char, txRows, page, totalPages);
      const buttons   = buildButtons(page, totalPages);

      return interaction.editReply({
        components: txRows.length > ITEMS_PER_PAGE
          ? [container, buttons]
          : [container],
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
      });
    }

    // ===================== PAGINATION =====================
    if (interaction.isButton() && ['mazebank-tx-prev', 'mazebank-tx-next'].includes(interaction.customId)) {

      await interaction.deferUpdate();

      const session = sessions.get(interaction.user.id);
      if (!session) {
        return interaction.editReply(`<:Warn:1497627240177991780> | انتهت الجلسة، أعد فتح التحويلات`);
      }

      if (interaction.customId === 'mazebank-tx-prev' && session.page > 0) {
        session.page--;
      } else if (interaction.customId === 'mazebank-tx-next' && session.page < session.totalPages - 1) {
        session.page++;
      }

      sessions.set(interaction.user.id, session);

      const container = buildTransactionsContainer(session.char, session.transactions, session.page, session.totalPages);
      const buttons   = buildButtons(session.page, session.totalPages);

      return interaction.editReply({
        components: [container, buttons],
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
      });
    }
  }
};