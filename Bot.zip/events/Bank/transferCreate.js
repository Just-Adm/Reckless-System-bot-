const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const { createTransaction, TRANSACTION_TYPE } = require('../../utils/database/transaction_mysql');

const { Name } = require('../../JSON/config.json');
const { BankTransferLog } = require('../../JSON/channels.json');

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    if (interaction.isButton() && interaction.customId === 'mazebank-transfer') {

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.reply({
          content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`,
          flags: MessageFlags.Ephemeral
        });
      }

      const char = rows.find(c => c.status === 'ONLINE') || null;
      if (!char) {
        return interaction.reply({
          content: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`,
          flags: MessageFlags.Ephemeral
        });
      }

      const modal = new ModalBuilder()
        .setCustomId('mazebank-transfer-modal')
        .setTitle('Transfer');

      const ibanInput = new TextInputBuilder()
        .setCustomId('iban')
        .setLabel('Recipient IBAN')
        .setStyle(TextInputStyle.Short)
        .setMinLength(4)
        .setMaxLength(20)
        .setPlaceholder('ادخل رقم الiban')
        .setRequired(true);

      const amountInput = new TextInputBuilder()
        .setCustomId('amount')
        .setLabel('Amount ($5 - $1,000,000)')
        .setStyle(TextInputStyle.Short)
        .setMinLength(1)
        .setMaxLength(7)
        .setPlaceholder('مثل 50$')
        .setRequired(true);

      const reasonInput = new TextInputBuilder()
        .setCustomId('reason')
        .setLabel('Reason')
        .setStyle(TextInputStyle.Short)
        .setMinLength(2)
        .setMaxLength(30)
        .setPlaceholder('مثل: لاني احبه')
        .setRequired(true);

      modal.addComponents(
        new ActionRowBuilder().addComponents(ibanInput),
        new ActionRowBuilder().addComponents(amountInput),
        new ActionRowBuilder().addComponents(reasonInput)
      );

      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'mazebank-transfer-modal') {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
      }

      const char = rows.find(c => c.status === 'ONLINE') || null;
      if (!char) {
        return interaction.editReply(`<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`);
      }

      const recipientIban = interaction.fields.getTextInputValue('iban').trim();
      const rawAmount     = interaction.fields.getTextInputValue('amount').trim();
      const reason        = interaction.fields.getTextInputValue('reason').trim();

      if (!/^\d+$/.test(rawAmount)) {
        return interaction.editReply(`<:No:1497627141465178132> | المبلغ يجب أن يكون أرقاماً فقط`);
      }

      const amount = parseInt(rawAmount);

      if (amount < 5 || amount > 1000000) {
        return interaction.editReply(`<:No:1497627141465178132> | المبلغ يجب أن يكون بين $5 و $1,000,000`);
      }

      if (recipientIban === char.iban) {
        return interaction.editReply(`<:No:1497627141465178132> | لا يمكنك التحويل لنفسك`);
      }

      const [recipientRows] = await pool.query(
        `SELECT * FROM characters WHERE iban = ?`,
        [recipientIban]
      );

      if (!recipientRows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | لا يوجد شخص يحمل هذا الـ IBAN`);
      }

      const recipient = recipientRows[0];

      const bank = char.bank || 0;

      if (bank < amount) {
        return interaction.editReply(`<:No:1497627141465178132> | رصيدك في البنك غير كافٍ — الرصيد الحالي: $${bank.toLocaleString()}`);
      }

      const tax       = Math.ceil(amount * 0.025);
      const netAmount = amount - tax;

      const senderNewBank    = bank - amount;
      const recipientNewBank = (recipient.bank || 0) + netAmount;

      await pool.query(
        `UPDATE characters SET bank = ? WHERE user_id = ? AND status = 'ONLINE'`,
        [senderNewBank, interaction.user.id]
      );

      await pool.query(
        `UPDATE characters SET bank = ? WHERE iban = ?`,
        [recipientNewBank, recipientIban]
      );

      const transactionNumber = await createTransaction({
        userId:     interaction.user.id,
        nationalId: char.national_id,
        iban:       char.iban,
        firstname:  char.firstname,
        lastname:   char.lastname,
        type:       TRANSACTION_TYPE.TRANSFER,
        amount,
        reason,
        cashAfter:  char.cash || 0,
        bankAfter:  senderNewBank
      });

      const successEmbed = new EmbedBuilder()
.setTitle(`Maze Bank — Transfer Successful`)
.setDescription(
`**Recipient:** ${recipient.firstname} ${recipient.lastname}
**IBAN:** ${recipientIban}

**Amount:** $${amount.toLocaleString()}
**Reason:** ${reason}

-# Tax (2.5%): $${tax.toLocaleString()}
-# Net Amount: $${netAmount.toLocaleString()}
-# Transaction: \`${transactionNumber}\``)
.setFooter({ text: `${char.firstname} ${char.lastname} • ${char.iban}` });

      await interaction.editReply({ embeds: [successEmbed], flags: MessageFlags.Ephemeral });

try {
  const recipientUser = await client.users.fetch(recipient.user_id);

  if (recipientUser) {
    const dmEmbed = new EmbedBuilder()
.setTitle(`Maze Bank — Transfer`)
.setDescription(`<:Maze:1497627129956008118> | تم استلام مبلغ التحويل بنجاح
** **
**Sender:** ${char.firstname} ${char.lastname}
**IBAN:** ${char.iban}

**Amount Received:** $${netAmount.toLocaleString()}
**Reason:** ${reason}

**Transaction:** \`${transactionNumber}\``)
.setFooter({ text: `${recipient.firstname} ${recipient.lastname} - ${recipientIban}` })
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate());

    await recipientUser.send({ embeds: [dmEmbed] });
  }
} catch (e) {
  console.error('DM Error:', e.message);
}


      const logChannel   = client.channels.cache.get(BankTransferLog);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
.setTitle(`Bank Log | Transfer`)
.setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Username:** ${interaction.user.username}
**Time:** ${DateTime.now().setZone('Asia/Amman').toISO()}

**Character Number:** #${char.character_number}
**Full Name:** ${char.firstname} ${char.lastname}
**National ID:** ${char.national_id}
**IBAN:** ${char.iban}

**Cash:** $${newCash.toLocaleString()}
**Bank:** $${newBank.toLocaleString()}

─────────────────────

**Tax (2.5%):** $${tax.toLocaleString()}
**Net Amount:** $${netAmount.toLocaleString()}
**Reason:** ${reason}
**Transaction:** \`${transactionNumber}\``)
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
.setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }
    }
  }
};