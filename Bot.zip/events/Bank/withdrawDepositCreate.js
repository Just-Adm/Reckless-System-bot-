const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const { createTransaction, TRANSACTION_TYPE } = require('../../utils/database/transaction_mysql');

const { Name } = require('../../JSON/config.json');
const { BankDepositLog, BankWithdrawLog } = require('../../JSON/channels.json');

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    if (interaction.isButton() && ['mazebank-withdraw', 'mazebank-deposit'].includes(interaction.customId)) {

      const isWithdraw = interaction.customId === 'mazebank-withdraw';

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.reply({
          content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`,
          flags: MessageFlags.Ephemeral
        });
      }

      const char = rows.find(c => c.status === 'ONLINE') || null;
      if (!char) {
        return interaction.reply({
          content: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`,
          flags: MessageFlags.Ephemeral
        });
      }

      const modal = new ModalBuilder()
        .setCustomId(isWithdraw ? 'mazebank-withdraw-modal' : 'mazebank-deposit-modal')
        .setTitle(isWithdraw ? 'Withdraw' : 'Deposit');

      const amountInput = new TextInputBuilder()
        .setCustomId('amount')
        .setLabel('Amount ($10 - $10,000)')
        .setStyle(TextInputStyle.Short)
        .setMinLength(2)
        .setMaxLength(5)
        .setPlaceholder('حدد المبلغ, مثل: 500')
        .setRequired(true);

      const reasonInput = new TextInputBuilder()
        .setCustomId('reason')
        .setLabel('Reason')
        .setStyle(TextInputStyle.Short)
        .setMinLength(2)
        .setMaxLength(30)
        .setPlaceholder('اكتب السبب, مثل: شغل')
        .setRequired(true);

      modal.addComponents(
        new ActionRowBuilder().addComponents(amountInput),
        new ActionRowBuilder().addComponents(reasonInput)
      );

      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && ['mazebank-withdraw-modal', 'mazebank-deposit-modal'].includes(interaction.customId)) {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const isWithdraw = interaction.customId === 'mazebank-withdraw-modal';

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
      }

      const char = rows.find(c => c.status === 'ONLINE') || null;
      if (!char) {
        return interaction.editReply(`<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`);
      }

      const rawAmount = interaction.fields.getTextInputValue('amount').trim();
      const reason    = interaction.fields.getTextInputValue('reason').trim();

      if (!/^\d+$/.test(rawAmount)) {
        return interaction.editReply(`<:No:1497627141465178132> | المبلغ يجب أن يكون أرقاماً فقط`);
      }

      const amount = parseInt(rawAmount);

      if (amount < 10 || amount > 100000) {
        return interaction.editReply(`<:No:1497627141465178132> | المبلغ يجب أن يكون بين $10 و $10,000`);
      }

      const cash = char.cash || 0;
      const bank = char.bank || 0;

      const tax       = Math.ceil(amount * 0.025);
      const netAmount = amount - tax;

      if (isWithdraw && bank < amount) {
        return interaction.editReply(`<:No:1497627141465178132> | رصيدك في البنك غير كافٍ — الرصيد الحالي: $${bank.toLocaleString()}`);
      }

      if (!isWithdraw && cash < amount) {
        return interaction.editReply(`<:No:1497627141465178132> | كاشك غير كافٍ — الكاش الحالي: $${cash.toLocaleString()}`);
      }

      const newCash = isWithdraw ? cash + netAmount : cash - amount;
      const newBank = isWithdraw ? bank - amount    : bank + netAmount;

      await pool.query(
        `UPDATE characters SET cash = ?, bank = ? WHERE user_id = ? AND status = 'ONLINE'`,
        [newCash, newBank, interaction.user.id]
      );

      const transactionNumber = await createTransaction({
        userId:     interaction.user.id,
        nationalId: char.national_id,
        iban:       char.iban,
        firstname:  char.firstname,
        lastname:   char.lastname,
        type:       isWithdraw ? TRANSACTION_TYPE.WITHDRAW : TRANSACTION_TYPE.DEPOSIT,
        amount,
        reason,
        cashAfter:  newCash,
        bankAfter:  newBank
      });

      const successEmbed = new EmbedBuilder()
.setTitle(`Maze Bank — ${isWithdraw ? 'Withdraw' : 'Deposit'} Successful`)
.setDescription(
`**Amount:** $${amount.toLocaleString()}
**Reason:** __${reason}__

-# Tax **2.5%**: $${tax.toLocaleString()}
-# Net Amount: $${netAmount.toLocaleString()}
-# Transaction ID: \`${transactionNumber}\``)
.setFooter({ text: `${char.firstname} ${char.lastname} • ${char.iban}` });

      await interaction.editReply({ embeds: [successEmbed], flags: MessageFlags.Ephemeral });

      

      const logChannelId = isWithdraw ? BankWithdrawLog : BankDepositLog;
      const logChannel   = client.channels.cache.get(logChannelId);

      if (logChannel) {
        const logEmbed = new EmbedBuilder()
.setTitle(`Bank Log | ${isWithdraw ? 'Withdraw' : 'Deposit'}`)
.setDescription(
`**User:** <@${interaction.user.id}> (${interaction.user.id})
**Username:** ${interaction.user.username}
**Time:** ${DateTime.now().setZone('Asia/Amman').toISO()}

**Character Number:** #${char.character_number}
**Full Name:** ${char.firstname} ${char.lastname}
**National ID:** ${char.national_id}
**IBAN:** ${char.iban}

**Cash:** $${newCash.toLocaleString()}
**Bank:** $${newBank.toLocaleString()}
─────────────────────

**Amount ${isWithdraw ? 'Withdrawn' : 'Deposited'}:** $${amount.toLocaleString()}
**Tax (2.5%):** $${tax.toLocaleString()}
**Net Amount:** $${netAmount.toLocaleString()}
**Reason:** ${reason}
**Transaction:** \`${transactionNumber}\``)
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
.setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }
    }
  }
};