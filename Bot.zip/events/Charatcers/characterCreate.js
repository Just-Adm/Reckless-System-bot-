const { Events, MessageFlags, ModalBuilder, LabelBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const { createCharacter, getAllCharacters } = require('../../utils/database/characters_mysql');
const { createDefaultInventory } = require('../../utils/database/inventory_mysql');

const { Name } = require('../../JSON/config.json')
const { CharacterAcceptedLog, CharacterRejectedLog } = require('../../JSON/channels.json');
const { ExtraCharatcers } = require('../../JSON/roles.json')

const VALID_PLACES = ['Los Santos', 'Sandy Shores', 'Paleto'];

const BAD_NAMES = [
  'fuck', 'shit', 'bitch', 'asshole', 'bastard', 'cunt', 'damn', 'hell',
  'dick', 'cock', 'pussy', 'whore', 'slut', 'nigger', 'nigga', 'faggot',
  'retard', 'idiot', 'moron', 'stupid', 'ugly', 'kill', 'die', 'sex',
  'porn', 'nude', 'naked', 'rape', 'drug', 'cocaine', 'weed', 'hitler',
  'nazi', 'satan', 'devil', 'terrorist', 'bomb', 'murder', 'blood',
  'admin', 'staff', 'owner', 'mod', 'moderator', 'developer', 'dev',
  'system', 'bot', 'null', 'undefined', 'root', 'test', 'fake', 'god',
];

module.exports = {
  name: Events.InteractionCreate,

  async execute(interaction, client) {
    if (interaction.isStringSelectMenu() && interaction.customId === 'characterMenu') {

      const choice = interaction.values[0];

      if (choice === 'character-create_character') {

        const chars = await getAllCharacters(interaction.user.id);

        const hasExtraRole = interaction.member.roles.cache.has(ExtraCharatcers);

        const maxChars = hasExtraRole ? 4 : 2;

        if (chars.length >= maxChars) {
          return interaction.reply({
            content: `<:boost:1497627021407289444> | قم بدعم السيرفر بـ بوست للحصول على شخصيات اضافيه`,
            flags: MessageFlags.Ephemeral
          });
        }

        const charNumber = chars.length + 1;

        const modal = new ModalBuilder()
          .setCustomId('createCharacterModal')
          .setTitle(`Create Charatcer #${charNumber}`);

        const firstName = new LabelBuilder()
          .setLabel('First Name')
          .setTextInputComponent(
            new TextInputBuilder()
              .setCustomId('character_firstname')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('أدخل إسم الشخصية الأول')
          );

        const lastName = new LabelBuilder()
          .setLabel('Last Name')
          .setTextInputComponent(
            new TextInputBuilder()
              .setCustomId('character_lastname')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('أدخل إسم الشخصية الأخير')
          );

        const dob = new LabelBuilder()
          .setLabel('Date Of Birth (DD/MM/YYYY)')
          .setTextInputComponent(
            new TextInputBuilder()
              .setCustomId('character_dob')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('ادخل تاريخ ميلاد الشخصية | (05/10/1995)')
          );

        const pob = new LabelBuilder()
          .setLabel('Place Of Birth')
          .setStringSelectMenuComponent(
            new StringSelectMenuBuilder()
              .setCustomId('character_pob')
              .setPlaceholder('قم بإختيار مكان ميلاد الشخصية')
              .addOptions(
                new StringSelectMenuOptionBuilder().setLabel('Los Santos').setValue('Los Santos'),
                new StringSelectMenuOptionBuilder().setLabel('Sandy Shores').setValue('Sandy Shores'),
                new StringSelectMenuOptionBuilder().setLabel('Paleto').setValue('Paleto')
              )
          );

        modal.addLabelComponents(firstName, lastName, dob, pob);

        return interaction.showModal(modal);
      }
    }


    if (interaction.isModalSubmit() && interaction.customId === 'createCharacterModal') {

      const rawFirstname = interaction.fields.getTextInputValue('character_firstname');
      const rawLastname  = interaction.fields.getTextInputValue('character_lastname');
      const rawDob       = interaction.fields.getTextInputValue('character_dob');
      const pob = interaction.fields.getStringSelectValues('character_pob')[0];

      const firstnameCheck = validateName(rawFirstname);
      const lastnameCheck  = validateName(rawLastname);
      const dobCheck       = validateAndNormalizeDOB(rawDob);
      const pobCheck       = VALID_PLACES.includes(pob);

      const rejectReasons = [];
      if (!firstnameCheck.valid) rejectReasons.push(`الإسم الأول: ${firstnameCheck.reason}`);
      if (!lastnameCheck.valid)  rejectReasons.push(`الإسم الأخير: ${lastnameCheck.reason}`);
      if (!dobCheck.valid)       rejectReasons.push(`تاريخ الميلاد: ${dobCheck.reason}`);
      if (!pobCheck)             rejectReasons.push(`مكان الميلاد: غير صحيح`);

      if (rejectReasons.length > 0) {

        const logChannel = interaction.client.channels.cache.get(CharacterRejectedLog);

        if (logChannel) {
          await logChannel.send({
            embeds: [
              new EmbedBuilder()

.setTitle('Character Log | Rejected')
.setDescription(
`User: <@${interaction.user.id}>
Time: ${DateTime.now().setZone('Asia/Amman')}

First Name: ${rawFirstname}
Last Name: ${rawLastname}
DOB: ${rawDob}
POB: ${pob}

Reasons: ${rejectReasons.map(r => `• ${r}`).join('\n')}`)
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
.setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) })
            ]
          }).catch(() => {});
        }

        await interaction.user.send({
          embeds: [
            new EmbedBuilder()
.setTitle('Character Rejected | تم رفض الشخصية')
.setDescription(`<:Important:1497627095767973898> | عزيزي المواطن, لقد تم رفض تقديم شخصيتك, حاول مرى اخرى.
  
اسباب الرفض: ${rejectReasons.map(r => `• ${r}`).join('\n')}`)
.setColor('#cf0808')
          ]
        }).catch(() => {});

        return interaction.reply({
          content: `<:No:1497627141465178132> | تم رفض الشخصية.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const firstname = capitalizeName(rawFirstname);
      const lastname  = capitalizeName(rawLastname);
      const dob       = dobCheck.normalized;

      const chars = await getAllCharacters(interaction.user.id);
      const charNumber = chars.length + 1;

      const result = await createCharacter(interaction.user.id, charNumber, {
        Firstname: firstname,
        Lastname: lastname,
        Dateofbirth: dob,
        Placeofbirth: pob
      });

      await pool.query(
        `UPDATE characters 
         SET status = 'OFFLINE' 
         WHERE user_id = ? AND character_number = ? AND status = 'WAITING'`,
        [interaction.user.id, charNumber]
      );

      await createDefaultInventory(interaction.user.id, charNumber);

      const logChannel = interaction.client.channels.cache.get(CharacterAcceptedLog);

      if (logChannel) {
        await logChannel.send({
          embeds: [
            new EmbedBuilder()

.setTitle('Character Log | Accepted')
.setDescription(
`User: <@${interaction.user.id}>
Time: ${DateTime.now().setZone('Asia/Amman')}

First Name: ${rawFirstname}
Last Name: ${rawLastname}
DOB: ${rawDob}
POB: ${pob}`)
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
.setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) })

          ]
        }).catch(() => {});
      }

      await interaction.user.send({
        embeds: [
          new EmbedBuilder()

.setTitle('Character Accepted | تم قبول الشخصية')
.setDescription(
`<:tag:1497627214374768700> | Full Name: ${firstname} ${lastname}
<:tag:1497627214374768700> | Charatcer Number: ${charNumber}
<:tag:1497627214374768700> | DOP: ${dob}
<:tag:1497627214374768700> | POB: ${pob}

<:tag:1497627214374768700> | National ID: ${result.nationalId}
<:tag:1497627214374768700> | IBAN: ${result.iban}

<:tag:1497627214374768700> | Blood Type: ${result.bloodType}
<:tag:1497627214374768700> | Fingerprint: ${result.fingerprint}
<:tag:1497627214374768700> | Phone: ${result.phoneNumber}`)
.setColor('#0d990d')
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
        ]
      }).catch(() => {});

      return interaction.reply({
        content: `<:Yes:1497627245873991750> | تم إنشاء الشخصية بنجاح`,
        flags: MessageFlags.Ephemeral
      });
    }

  }
};

function capitalizeName(name) {
  return name.trim().charAt(0).toUpperCase() + name.trim().slice(1).toLowerCase();
}

function validateName(name) {
  if (!name || typeof name !== 'string') return { valid: false, reason: 'الإسم فارغ' };
  const trimmed = name.trim();
  if (!/^[A-Za-z]+$/.test(trimmed)) return { valid: false, reason: 'يجب أن يحتوي على أحرف إنجليزية فقط' };
  if (trimmed.length < 2 || trimmed.length > 20) return { valid: false, reason: 'يجب أن يكون بين 2 و 20 حرف' };
  if (BAD_NAMES.includes(trimmed.toLowerCase())) return { valid: false, reason: 'يحتوي على كلمات غير لائقة' };
  return { valid: true };
}

function validateAndNormalizeDOB(dob) {
  if (!dob || typeof dob !== 'string') return { valid: false, reason: 'تاريخ الميلاد فارغ' };

  const trimmed = dob.trim();
  const match = trimmed.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) return { valid: false, reason: 'الصيغة غير صحيحة' };

  const d = parseInt(match[1]);
  const m = parseInt(match[2]);
  const y = parseInt(match[3]);

  const date = new Date(y, m - 1, d);
  if (date.getFullYear() !== y || date.getMonth() !== m - 1 || date.getDate() !== d)
    return { valid: false, reason: 'تاريخ غير صحيح' };

  return { valid: true, normalized: `${String(d).padStart(2,'0')}/${String(m).padStart(2,'0')}/${y}` };
}