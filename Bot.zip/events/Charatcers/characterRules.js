const { Events, AttachmentBuilder, MessageFlags } = require('discord.js');
const path = require('path');


module.exports = {
  name: Events.InteractionCreate,
  once: false,
  async execute(interaction, client) {
    if (!interaction.isStringSelectMenu()) return;
    if (interaction.customId !== 'characterMenu') return;

    const choice = interaction.values[0];

    if (choice === 'character-show_rules') {

      const imagePath = path.join(__dirname, '../../images/server/rules-banner.png');
      const file = new AttachmentBuilder(imagePath, {
        name: 'character_rules.png'
      });

      await interaction.update({
        components: interaction.message.components
      });

      return interaction.followUp({
        files: [file],
        flags: MessageFlags.Ephemeral
      });
    }
  }
};