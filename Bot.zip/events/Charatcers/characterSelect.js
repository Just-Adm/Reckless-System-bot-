const {Events,MessageFlags,ActionRowBuilder,ButtonBuilder,ButtonStyle,AttachmentBuilder,EmbedBuilder} = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const Canvas = require('@napi-rs/canvas');
const path = require('path');
const { getAllCharacters } = require('../../utils/database/characters_mysql');

const { Name } = require('../../JSON/config.json');
const { CharacterLoginLog, CharacterSwitchLog, CharacterLogoutLog } = require('../../JSON/channels.json');


module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction, client) {

    if (interaction.isStringSelectMenu() && interaction.customId === 'characterMenu') {

      const choice = interaction.values[0];
      if (choice !== 'character-select_character') return;

      let chars = await getAllCharacters(interaction.user.id);
      chars = chars.filter(c => c.status !== "WAITING");

      await interaction.update({
        components: interaction.message.components
      });

      if (!chars || chars.length === 0) {
        return interaction.followUp({
          content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`,
          flags: MessageFlags.Ephemeral
        });
      }

      const index = 0;
      const selectedChar = chars[index];

      const image = await generateCharacterCard(selectedChar);
      const row = buildCharacterButtons(interaction.user.id, chars, selectedChar, index);

      return interaction.followUp({
        files: [image],
        components: [row],
        flags: MessageFlags.Ephemeral
      });
    }


     if (interaction.isButton()) {

  try {

    if (interaction.customId.startsWith("characterselect-prev-")) {

      await interaction.deferUpdate().catch(() => {});

      const [, , userId, indexRaw] = interaction.customId.split("-");

      if (interaction.user.id !== userId) {
        return interaction.followUp({
          content: `❌ | هذا ليس لك`,
          flags: MessageFlags.Ephemeral
        });
      }

      let chars = await getAllCharacters(userId);
      chars = chars.filter(c => c.status !== "WAITING");

      if (!chars.length) {
        return interaction.editReply({
          content: `❌ | لا يوجد لديك شخصيات مقبولة`,
          components: [],
          files: [],
          embeds: []
        }).catch(() => {});
      }

      let index = parseInt(indexRaw);
      if (isNaN(index)) index = 0;

      index--;
      if (index < 0) index = 0;

      const selectedChar = chars[index];

      const image = await generateCharacterCard(selectedChar);
      const row = buildCharacterButtons(userId, chars, selectedChar, index);

      return interaction.editReply({
        files: [image],
        components: [row],
        embeds: []
      }).catch(() => {});
    }

    if (interaction.customId.startsWith("characterselect-next-")) {

      await interaction.deferUpdate().catch(() => {});

      const [, , userId, indexRaw] = interaction.customId.split("-");

      if (interaction.user.id !== userId) {
        return interaction.followUp({
          content: `❌ | هذا ليس لك`,
          flags: MessageFlags.Ephemeral
        });
      }

      let chars = await getAllCharacters(userId);
      chars = chars.filter(c => c.status !== "WAITING");

      if (!chars.length) {
        return interaction.editReply({
          content: `❌ | لا يوجد لديك شخصيات مقبولة`,
          components: [],
          files: [],
          embeds: []
        }).catch(() => {});
      }

      let index = parseInt(indexRaw);
      if (isNaN(index)) index = 0;

      index++;
      if (index >= chars.length) index = chars.length - 1;

      const selectedChar = chars[index];

      const image = await generateCharacterCard(selectedChar);
      const row = buildCharacterButtons(userId, chars, selectedChar, index);

      return interaction.editReply({
        files: [image],
        components: [row],
        embeds: []
      }).catch(() => {});
    }

    // =========================
    // LOGIN / SWITCH BUTTON
    // =========================
    if (interaction.customId.startsWith("characterselect-login-")) {

      await interaction.deferUpdate().catch(() => {});

      const [, , userId, charNumber, indexRaw] = interaction.customId.split("-");

      if (interaction.user.id !== userId) {
        return interaction.followUp({
          content: `❌ | هذا ليس لك`,
          flags: MessageFlags.Ephemeral
        });
      }

      let chars = await getAllCharacters(userId);
      chars = chars.filter(c => c.status !== "WAITING");

      const currentOnline = chars.find(c => c.status === "ONLINE");

      await pool.query(`UPDATE characters SET status = 'OFFLINE' WHERE user_id = ?`, [userId]);

      await pool.query(
        `UPDATE characters SET status = 'ONLINE' WHERE user_id = ? AND character_number = ?`,
        [userId, charNumber]
      );

      let updatedChars = await getAllCharacters(userId);
      updatedChars = updatedChars.filter(c => c.status !== "WAITING");

      const index = parseInt(indexRaw) || 0;
      const selectedChar = updatedChars[index];

      const image = await generateCharacterCard(selectedChar);
      const row = buildCharacterButtons(userId, updatedChars, selectedChar, index);

      const logChannelId = currentOnline ? CharacterSwitchLog : CharacterLoginLog;
      const logChannel = interaction.client.channels.cache.get(logChannelId);

      if (logChannel) {

        const logEmbed = new EmbedBuilder()
.setTitle(currentOnline ? "Character Log | Switch" : "Character Log | Login")
.setDescription(
`User: <@${interaction.user.id}> (${interaction.user.id})
Username: ${interaction.user.username}
Time: ${DateTime.now().setZone('Asia/Amman').toISO()}

Character Number: #${selectedChar.character_number}
Full Name: ${selectedChar.firstname} ${selectedChar.lastname}
DOB: ${selectedChar.dateofbirth}
POB: ${selectedChar.placeofbirth}

National ID: ${selectedChar.national_id}
Serial Number: ${selectedChar.serial_number}
IBAN: ${selectedChar.iban}

Job: ${selectedChar.job || "Unemployed"}
Cash: $${selectedChar.cash || 0}
Bank: $${selectedChar.bank || 0}

Status: ONLINE
Issue Date: ${selectedChar.issue_date}
Expiry Date: ${selectedChar.expiry_date}`)
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
.setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        files: [image],
        components: [row]
      }).catch(() => {});
    }


    if (interaction.customId.startsWith("characterselect-logout-")) {

      await interaction.deferUpdate().catch(() => {});

      const [, , userId, charNumber, indexRaw] = interaction.customId.split("-");

      if (interaction.user.id !== userId) {
        return interaction.followUp({
          content: `❌ | هذا ليس لك`,
          flags: MessageFlags.Ephemeral
        });
      }

      await pool.query(
        `UPDATE characters SET status = 'OFFLINE' WHERE user_id = ? AND character_number = ?`,
        [userId, charNumber]
      );

      let updatedChars = await getAllCharacters(userId);
      updatedChars = updatedChars.filter(c => c.status !== "WAITING");

      const index = parseInt(indexRaw) || 0;
      const selectedChar = updatedChars[index];

      const image = await generateCharacterCard(selectedChar);
      const row = buildCharacterButtons(userId, updatedChars, selectedChar, index);

      const logChannel = interaction.client.channels.cache.get(CharacterLogoutLog);

      if (logChannel) {

        const logEmbed = new EmbedBuilder()
.setTitle("Character Log | Logout")
.setDescription(
`User: <@${interaction.user.id}> (${interaction.user.id})
Username: ${interaction.user.username}
Time: ${DateTime.now().setZone('Asia/Amman').toISO()}

Character Number: #${selectedChar.character_number}
Full Name: ${selectedChar.firstname} ${selectedChar.lastname}
DOB: ${selectedChar.dateofbirth}
POB: ${selectedChar.placeofbirth}

National ID: ${selectedChar.national_id}
Serial Number: ${selectedChar.serial_number}
IBAN: ${selectedChar.iban}

Job: ${selectedChar.job || "Unemployed"}
Cash: $${selectedChar.cash || 0}
Bank: $${selectedChar.bank || 0}

Status: OFFLINE
Issue Date: ${selectedChar.issue_date}
Expiry Date: ${selectedChar.expiry_date}`)
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
.setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

        await logChannel.send({ embeds: [logEmbed] });
      }

      return interaction.editReply({
        embeds: [],
        files: [image],
        components: [row]
      }).catch(() => {});
    }

  } catch (err) {
    console.log("Button Error:", err);
    return interaction.followUp({
      content: "❌ | حصل خطأ مؤقت",
      flags: MessageFlags.Ephemeral
    }).catch(() => {});
  }
}
  }
};

function buildCharacterButtons(userId, chars, character, index) {

  const isOnline = character.status === "ONLINE";

  return new ActionRowBuilder().addComponents(

    new ButtonBuilder()
      .setCustomId(`characterselect-prev-${userId}-${index}`)
      .setEmoji('<:Left:1497627103095423006>')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(index === 0),

    new ButtonBuilder()
      .setCustomId(
        isOnline
          ? `characterselect-logout-${userId}-${character.character_number}-${index}`
          : `characterselect-login-${userId}-${character.character_number}-${index}`
      )
      .setLabel(isOnline ? "Logout" : "Login")
      .setStyle(isOnline ? ButtonStyle.Danger : ButtonStyle.Success),

    new ButtonBuilder()
      .setCustomId(`characterselect-next-${userId}-${index}`)
      .setEmoji('<:Right:1497627182803976262>')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(index === chars.length - 1)

  );
}


function getCharacterBackground(character) {

  try {
    const job = (character.job || "").toLowerCase();

    if (job.includes("lspd")) return "../../images/charatcers/charatcer3.png";
    if (job.includes("citizen") || job.includes("مواطن")) return "../../images/charatcers/charatcer1.png";

    return "../../images/charatcers/charatcer1.png";
  } catch {
    return "../../images/charatcers/charatcer2.png";
  }
}

function drawText(ctx, text, x, y, size = 20, color = "#ffffff") {
  ctx.font = `${size}px Arial`;
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
}

async function generateCharacterCard(character) {

  const imagePath = getCharacterBackground(character);
  const bgPath = path.join(__dirname, imagePath);

  const canvas = Canvas.createCanvas(1366, 768);
  const ctx = canvas.getContext('2d');

  const background = await Canvas.loadImage(bgPath);
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

  const fullName = `${character.firstname} ${character.lastname}`;
  const dob = character.dateofbirth;
  const pob = character.placeofbirth;
  const nationalId = character.national_id;
  const job = character.job || "Unemployed";

  const cash = character.cash || 0;
  const bank = character.bank || 0;

  drawText(ctx, `${fullName}`, 1050, 279);
  drawText(ctx, `${dob}`, 1080, 330);
  drawText(ctx, `${pob}`, 1080, 380);

  drawText(ctx, `${nationalId}`, 1080, 433);
  drawText(ctx, `${job}`, 1070, 486);

  drawText(ctx, `$${cash}`, 1080, 535);
  drawText(ctx, `$${bank}`, 1080, 588);

  const buffer = canvas.toBuffer("image/png");
  return new AttachmentBuilder(buffer, { name: "character.png" });
}

