const { pool } = require('../../utils/database/mysql');

const onlineSessions = new Map();
const CHECK_INTERVAL = 30 * 1000;

module.exports = {
  name: "playtime_watcher",

  async execute(interaction, client) {


    setInterval(async () => {
      try {

        const [rows] = await pool.query(
          `SELECT user_id, character_number 
           FROM characters 
           WHERE status = 'ONLINE'`
        );

        const now = Date.now();

        for (const row of rows) {
          const key = `${row.user_id}_${row.character_number}`;

          if (!onlineSessions.has(key)) {
            onlineSessions.set(key, now);
          }
        }

        for (const [key, startTime] of onlineSessions.entries()) {

          const [userId, charNumber] = key.split('_');

          const [check] = await pool.query(
            `SELECT status 
             FROM characters 
             WHERE user_id = ? AND character_number = ?`,
            [userId, charNumber]
          );

          if (!check.length) {
            onlineSessions.delete(key);
            continue;
          }

          if (check[0].status !== 'ONLINE') {

            const diffMs = now - startTime;
            const minutesPlayed = Math.floor(diffMs / 60000);


            if (minutesPlayed > 0) {
              await pool.query(
                `UPDATE characters 
                 SET play_hours = play_hours + ?
                 WHERE user_id = ? AND character_number = ?`,
                [minutesPlayed, userId, charNumber]
              );
            }

            onlineSessions.delete(key);
          }
        }

      } catch (err) {
        console.error("[PLAYTIME WATCHER ERROR]", err);
      }
    }, CHECK_INTERVAL);

    //console.log("✅ Playtime watcher started.");
  }
};