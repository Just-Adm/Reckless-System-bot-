const { Events, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, MessageFlags, EmbedBuilder, TextInputBuilder, TextInputStyle, ModalBuilder } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');
const { getInventory, transferItem, isSerialTracked } = require('../../utils/database/inventory_mysql');

const { Name } = require('../../JSON/config.json');
const { InvGiveLog } = require('../../JSON/channels.json');

module.exports = {
  name: Events.InteractionCreate,

  async execute(interaction, client) {
    try {

      // ===================== STEP 1: فتح الحقيبة =====================
      if (interaction.isButton() && interaction.customId === 'characterinventory-give') {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        if (!chars.length) return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);

        const char = chars.find(c => c.status === 'ONLINE');
        if (!char) return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped = groupByCategory(inventory);
        const categories = Object.keys(grouped);

        if (!categories.length) return interaction.editReply('🔍 | الحقيبة فارغة');

        const menu = new StringSelectMenuBuilder()
          .setCustomId('giveitem-selectcategory')
          .setPlaceholder('Select category')
          .addOptions(categories.map(cat => ({ label: cat, value: cat })));

        return interaction.editReply({ components: [new ActionRowBuilder().addComponents(menu)] });
      }

      // ===================== STEP 2: اختيار الكتيغوري =====================
      if (interaction.isStringSelectMenu() && interaction.customId === 'giveitem-selectcategory') {

        await interaction.deferUpdate();

        const category = interaction.values[0];
        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char = chars.find(c => c.status === 'ONLINE');
        if (!char) return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped = groupByCategory(inventory);
        const items = grouped[category] || [];

        if (!items.length) return interaction.editReply({ content: '❌ لا يوجد عناصر', components: [] });

        const tracked = isSerialTracked(category);

        let options;

        if (tracked) {
          // كل وحدة منفصلة: label = اسم المنتج، value = رقم تسلسلي
          options = [];
          for (const item of items) {
            for (const unit of item.units) {
              const expLabel = unit.expiry_date ? ` | Exp: ${unit.expiry_date}` : '';
              options.push({
                label: `${item.name}${expLabel}`,
                value: unit.serial   // value = serial
              });
            }
          }
        } else {
          // منتجات عادية: label = اسم + كمية، value = اسم
          options = items.map(i => ({
            label: `${i.name} (x${i.quantity})`,
            value: i.name
          }));
        }

        options = options.slice(0, 25);

        const select = new StringSelectMenuBuilder()
          .setCustomId(`giveitem-items-${category}__tracked-${tracked}`)
          .setPlaceholder(category)
          .setMinValues(1)
          .setMaxValues(1)
          .addOptions(options);

        const backBtn = new ButtonBuilder()
          .setCustomId('giveitem-back')
          .setLabel('Back')
          .setStyle(ButtonStyle.Secondary);

        return interaction.editReply({
          content: `Category: **${category}**`,
          components: [
            new ActionRowBuilder().addComponents(select),
            new ActionRowBuilder().addComponents(backBtn)
          ]
        });
      }

      // ===================== BACK =====================
      if (interaction.isButton() && interaction.customId === 'giveitem-back') {

        await interaction.deferUpdate();

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char = chars.find(c => c.status === 'ONLINE');
        if (!char) return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped = groupByCategory(inventory);
        const categories = Object.keys(grouped);

        if (!categories.length) return interaction.editReply('🔍 | الحقيبة فارغة');

        const menu = new StringSelectMenuBuilder()
          .setCustomId('giveitem-selectcategory')
          .setPlaceholder('Select category')
          .addOptions(categories.map(cat => ({ label: cat, value: cat })));

        return interaction.editReply({
          content: 'Select category:',
          components: [new ActionRowBuilder().addComponents(menu)]
        });
      }

      // ===================== STEP 3: اختيار المنتج → مودال =====================
      if (interaction.isStringSelectMenu() && interaction.customId.startsWith('giveitem-items-')) {

        const raw      = interaction.customId.replace('giveitem-items-', '');
        const [catPart, trackedPart] = raw.split('__tracked-');
        const category = catPart;
        const tracked  = trackedPart === 'true';

        const selectedValue = interaction.values[0];  // serial أو itemName

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char = chars.find(c => c.status === 'ONLINE');
        if (!char) return interaction.reply({ content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا', flags: MessageFlags.Ephemeral });

        const inventory = await getInventory(interaction.user.id, char.character_number);

        let itemName, maxQty, isSingle;

        if (tracked) {
          // selectedValue = serial → نبحث عن اسم المنتج
          itemName = findItemNameBySerial(inventory, selectedValue);
          if (!itemName) return interaction.reply({ content: '❌ المنتج غير موجود', flags: MessageFlags.Ephemeral });
          maxQty   = 1;
          isSingle = true;
        } else {
          itemName = selectedValue;
          maxQty   = inventory[itemName]?.quantity || 0;
          isSingle = maxQty === 1;
        }

        if (!maxQty) return interaction.reply({ content: '❌ لا يوجد عناصر', flags: MessageFlags.Ephemeral });

        // customId يحمل: itemName + category + isSingle + serial (لو tracked)
        const serialEncoded = tracked ? selectedValue : 'none';
        const modalId = `giveitem-modal-${itemName}__cat-${category}__single-${isSingle}__serial-${serialEncoded}`;

        const modal = new ModalBuilder()
          .setCustomId(modalId)
          .setTitle('Give Item | اعطاء منتج');

        const nationalInput = new TextInputBuilder()
          .setCustomId('nationalId')
          .setLabel('National ID | الرقم الوطني')
          .setPlaceholder('أدخل الرقم الوطني للمستقبل')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(nationalInput));

        // نطلب الكمية فقط لو مش single ومش tracked
        if (!isSingle && !tracked) {
          const amountInput = new TextInputBuilder()
            .setCustomId('amount')
            .setLabel(`الكمية (${itemName}) — الحد الأقصى: ${maxQty}`)
            .setPlaceholder(`Max: ${maxQty}`)
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(amountInput));
        }

        return interaction.showModal(modal);
      }

      // ===================== STEP 4: تنفيذ النقل =====================
      if (interaction.isModalSubmit() && interaction.customId.startsWith('giveitem-modal-')) {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const raw     = interaction.customId.replace('giveitem-modal-', '');
        const parts   = raw.split('__');
        const itemName        = parts[0];
        const category        = parts[1]?.replace('cat-', '')    || 'misc';
        const isSingle        = parts[2]?.replace('single-', '') === 'true';
        const specificSerial  = parts[3]?.replace('serial-', '') || 'none';
        const tracked         = specificSerial !== 'none';

        const nationalId = interaction.fields.getTextInputValue('nationalId');

        let amount = 1;
        if (!isSingle && !tracked) {
          amount = parseInt(interaction.fields.getTextInputValue('amount'));
          if (!amount || amount < 1) return interaction.editReply('❌ الكمية غير صحيحة');
        }

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        if (!chars.length) return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);

        const char = chars.find(c => c.status === 'ONLINE');
        if (!char) return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');

        const inventory = await getInventory(interaction.user.id, char.character_number);

        if (!inventory[itemName] || inventory[itemName].quantity < amount) {
          return interaction.editReply(`❌ لا تملك الكمية الكافية من ${itemName}`);
        }

        const targetChar = await findCharacterByNationalId(nationalId);
        if (!targetChar) return interaction.editReply('❌ لم يتم العثور على شخصية بهذا الرقم الوطني');

        if (targetChar.user_id === interaction.user.id && targetChar.character_number === char.character_number) {
          return interaction.editReply('❌ لا يمكنك إعطاء نفسك');
        }

        // النقل
        let transferred;

        if (tracked) {
          // ننقل وحدة بعينها بسيريالها
          transferred = await transferItemBySerial(
            interaction.user.id, char.character_number,
            targetChar.user_id, targetChar.character_number,
            specificSerial
          );
        } else {
          transferred = await transferItem(
            interaction.user.id, char.character_number,
            targetChar.user_id, targetChar.character_number,
            itemName, amount
          );
        }

        if (!transferred) return interaction.editReply('❌ فشل نقل المنتج');

        const serialsText = Array.isArray(transferred)
          ? transferred.map(r => `- #${r.item_serial}${r.expiry_date ? ` (Exp: ${r.expiry_date})` : ''}`).join('\n')
          : `- #${transferred.item_serial}`;

        // Log
        const logChannel = interaction.client.channels.cache.get(InvGiveLog);
        if (logChannel) {
          const targetUser = await interaction.client.users.fetch(targetChar.user_id).catch(() => null);

          const logEmbed = new EmbedBuilder()
            .setTitle('Inventory Log | Give')
            .setDescription(
`**Sender Info:**
User: <@${interaction.user.id}> (${interaction.user.id})
Username: ${interaction.user.username}
Time: ${DateTime.now().setZone('Asia/Amman').toISO()}

Character Number: #${char.character_number}
Full Name: ${char.firstname} ${char.lastname}
National ID: ${char.national_id}

----------------------------

**Receiver Info:**
User: <@${targetChar.user_id}> (${targetChar.user_id})
Username: ${targetUser?.username || 'Unknown'}
Time: ${DateTime.now().setZone('Asia/Amman').toISO()}

Character Number: #${targetChar.character_number}
Full Name: ${targetChar.firstname} ${targetChar.lastname}
National ID: ${targetChar.national_id}

----------------------------

**Transferred Item:**
Item: ${itemName}
Category: ${category}
Amount: x${amount}
${serialsText ? `\nSerials:\n${serialsText}` : ''}`)
            .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
            .setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

          await logChannel.send({ embeds: [logEmbed] });
        }

        const embed = new EmbedBuilder()
          .setTitle('Gived Items')
          .setDescription(`${itemName} x${amount}\n\nTo: ${nationalId}`)
          .setColor('Green');

        return interaction.editReply({ embeds: [embed], components: [] });
      }

    } catch (err) {
      console.error(err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Error occurred', flags: MessageFlags.Ephemeral });
      }
    }
  }
};

// ===================== HELPERS =====================

// groupByCategory → يرجع units منفصلة لكل وحدة tracked
function groupByCategory(inventory) {
  const grouped = {};

  for (const [name, data] of Object.entries(inventory)) {
    const cat = data.category || 'misc';
    if (!grouped[cat]) grouped[cat] = [];

    grouped[cat].push({
      name,
      quantity: data.quantity,
      units: data.items || []   // كل وحدة { serial, expiry_date, ... }
    });
  }

  return grouped;
}

function findItemNameBySerial(inventory, serial) {
  for (const [name, data] of Object.entries(inventory)) {
    if (data.items?.some(u => u.serial === serial)) return name;
  }
  return null;
}

async function findCharacterByNationalId(nationalId) {
  const [rows] = await pool.query(`SELECT * FROM characters WHERE national_id = ?`, [nationalId]);
  return rows[0] || null;
}

// نقل وحدة بعينها بسيريالها
async function transferItemBySerial(fromUserId, fromChar, toUserId, toChar, itemSerial) {
  const { pool: db } = require('../../utils/database/mysql');

  const [rows] = await db.query(
    `SELECT item_serial, item_name, category, available, expiry_date
     FROM inventory
     WHERE user_id = ? AND character_number = ? AND item_serial = ?
     LIMIT 1`,
    [fromUserId, fromChar, itemSerial]
  );

  if (!rows.length) return false;
  const row = rows[0];

  await db.query(
    `DELETE FROM inventory WHERE user_id = ? AND character_number = ? AND item_serial = ? LIMIT 1`,
    [fromUserId, fromChar, itemSerial]
  );

  await db.query(
    `INSERT INTO inventory (user_id, character_number, item_name, item_serial, category, available, expiry_date)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [toUserId, toChar, row.item_name, row.item_serial, row.category, row.available, row.expiry_date]
  );

  return row;
}