const { Events, AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { pool } = require('../../utils/database/mysql');

const { getInventory } = require('../../utils/database/inventory_mysql');
const { generateInventoryImage } = require('../Function/invFunction');


module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction, client) {

    if (interaction.isButton() && interaction.customId === 'characterinventory-show_inventory') {

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const [chars] = await pool.query(
      `SELECT * FROM characters WHERE user_id = ?`,
      [interaction.user.id]
    );

    if (!chars.length) {
      return interaction.editReply({ content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا` });
    }

    const onlineChar = chars.find(c => c.status === 'ONLINE');
    if (!onlineChar) {
      return interaction.editReply({ content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا' });
    }

    const inventory = await getInventory(interaction.user.id, onlineChar.character_number);

    const buffer = await generateInventoryImage(inventory);

    const attachment = new AttachmentBuilder(buffer, { name: 'inventory.png' });

    const buttonsRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
      .setCustomId('characterinventory-use')
      .setLabel('Use')
      .setEmoji('<:arrow:1499868235380555827>')
      .setStyle(ButtonStyle.Secondary),

      new ButtonBuilder()
      .setCustomId('characterinventory-give')
      .setLabel('Give')
      .setEmoji('<:give:1499868298341515344>')
      .setStyle(ButtonStyle.Secondary),

      new ButtonBuilder()
      .setCustomId('characterinventory-throw')
      .setLabel('Throw')
      .setEmoji('<:throw:1499868326841679952>')
      .setStyle(ButtonStyle.Secondary),

      new ButtonBuilder()
      .setCustomId('characterinventory-refresh')
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Success)
    );

    return interaction.editReply({
      files: [attachment],
      components: [buttonsRow]
    });
  }

  if (interaction.isButton() && interaction.customId === 'characterinventory-refresh') {

  await interaction.deferUpdate();

  const [chars] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ?`,
    [interaction.user.id]
  );

  if (!chars.length) {
    return interaction.editReply({
      content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`,
      files: [],
      components: []
    });
  }

  const onlineChar = chars.find(c => c.status === 'ONLINE');
  if (!onlineChar) {
    return interaction.editReply({
      content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا',
      files: [],
      components: []
    });
  }

  const inventory = await getInventory(interaction.user.id, onlineChar.character_number);

  const buffer = await generateInventoryImage(inventory);
  const attachment = new AttachmentBuilder(buffer, { name: 'inventory.png' });

  const buttonsRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('characterinventory-use')
      .setLabel('Use')
      .setEmoji('<:arrow:1499868235380555827>')
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId('characterinventory-give')
      .setLabel('Give')
      .setEmoji('<:give:1499868298341515344>')
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId('characterinventory-throw')
      .setLabel('Throw')
      .setEmoji('<:throw:1499868326841679952>')
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId('characterinventory-refresh')
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Success)
  );

  return interaction.editReply({
    content: null,
    files: [attachment],
    components: [buttonsRow]
  });
}
  }
};