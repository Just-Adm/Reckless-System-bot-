const { Events, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, MessageFlags, EmbedBuilder, TextInputBuilder, TextInputStyle, ModalBuilder } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');

const { Name } = require('../../JSON/config.json');
const { InvUseLog } = require('../../JSON/channels.json');
const {
  getInventory,
  removeItem,
  removeItemBySerial,
  isSerialTracked,
  setItemUsed,
  getUsedItem,
} = require('../../utils/database/inventory_mysql');

// كتيغوريات يُحذف منها عند الاستخدام (consumables)
const CONSUMABLE_CATEGORIES = ['FOOD', 'DRINKS', 'DRUGS', 'TOOLS', 'EMS', 'مسروقات', 'STOLEN'];

function isConsumable(category) {
  if (!category) return true; // misc يُحذف بالافتراضي
  return CONSUMABLE_CATEGORIES.includes(category.toUpperCase()) ||
         CONSUMABLE_CATEGORIES.includes(category);
}

module.exports = {
  name: Events.InteractionCreate,

  async execute(interaction, client) {
    try {

      // ===================== STEP 1 =====================
      if (interaction.isButton() && interaction.customId === 'characterinventory-use') {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        if (!chars.length) return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);

        const char = chars.find(c => c.status === 'ONLINE');
        if (!char) return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped   = groupByCategory(inventory);
        const categories = Object.keys(grouped);

        if (!categories.length) return interaction.editReply('🔍 | الحقيبة فارغة');

        const menu = new StringSelectMenuBuilder()
          .setCustomId('useitem-selectcategory')
          .setPlaceholder('Select category')
          .addOptions(categories.map(cat => ({ label: cat, value: cat })));

        return interaction.editReply({ components: [new ActionRowBuilder().addComponents(menu)] });
      }

      // ===================== STEP 2 =====================
      if (interaction.isStringSelectMenu() && interaction.customId === 'useitem-selectcategory') {

        await interaction.deferUpdate();

        const category = interaction.values[0];
        const [chars]  = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char     = chars.find(c => c.status === 'ONLINE');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped   = groupByCategory(inventory);
        const items     = grouped[category] || [];

        if (!items.length) return interaction.editReply({ content: '❌ لا يوجد عناصر', components: [] });

        const tracked = isSerialTracked(category);

        let options;

        if (tracked) {
          // كل وحدة منفردة: label = اسم المنتج، value = serial
          options = [];
          for (const item of items) {
            for (const unit of item.units) {
              const usedLabel  = unit.used ? ' ✅' : '';
              const expLabel   = unit.expiry_date ? ` | Exp: ${unit.expiry_date}` : '';
              options.push({
                label: `${item.name}${usedLabel}${expLabel}`,
                value: unit.serial
              });
            }
          }
        } else {
          options = items.map(i => ({
            label: `${i.name} (x${i.quantity})`,
            value: i.name
          }));
        }

        options = options.slice(0, 25);

        const select = new StringSelectMenuBuilder()
          .setCustomId(`useitem-items-${category}__tracked-${tracked}`)
          .setPlaceholder(category)
          .setMinValues(1)
          .setMaxValues(Math.min(tracked ? 1 : 5, options.length))
          .addOptions(options);

        const backBtn = new ButtonBuilder()
          .setCustomId('useitem-back')
          .setLabel('Back')
          .setStyle(ButtonStyle.Secondary);

        return interaction.editReply({
          content: `Category: **${category}**`,
          components: [
            new ActionRowBuilder().addComponents(select),
            new ActionRowBuilder().addComponents(backBtn)
          ]
        });
      }

      // ===================== BACK =====================
      if (interaction.isButton() && interaction.customId === 'useitem-back') {

        await interaction.deferUpdate();

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char    = chars.find(c => c.status === 'ONLINE');

        const inventory  = await getInventory(interaction.user.id, char.character_number);
        const grouped    = groupByCategory(inventory);
        const categories = Object.keys(grouped);

        const menu = new StringSelectMenuBuilder()
          .setCustomId('useitem-selectcategory')
          .setPlaceholder('Select category')
          .addOptions(categories.map(cat => ({ label: cat, value: cat })));

        return interaction.editReply({
          content: 'Select category:',
          components: [new ActionRowBuilder().addComponents(menu)]
        });
      }

      // ===================== STEP 3: اختيار المنتجات =====================
      if (interaction.isStringSelectMenu() && interaction.customId.startsWith('useitem-items-')) {

        const raw      = interaction.customId.replace('useitem-items-', '');
        const [catPart, trackedPart] = raw.split('__tracked-');
        const category = catPart;
        const tracked  = trackedPart === 'true';

        const selectedValues = interaction.values;

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char    = chars.find(c => c.status === 'ONLINE');
        const inventory = await getInventory(interaction.user.id, char.character_number);

        // ── TRACKED: toggle / swap / activate ──
        if (tracked) {
          await interaction.deferUpdate();

          const results = [];

          for (const serial of selectedValues) {
            const itemName = findItemNameBySerial(inventory, serial);
            if (!itemName) continue;

            const result = await setItemUsed(interaction.user.id, char.character_number, serial);

            if (result === 'TOGGLED_OFF') {
              results.push(`🔴 ${itemName} — تم إلغاء الاستخدام (#${serial})`);
            } else if (result === 'ACTIVATED') {
              results.push(`✅ ${itemName} — تم تفعيل الاستخدام (#${serial})`);
            } else if (result === 'SWAPPED') {
              results.push(`🔄 ${itemName} — تم التبديل إلى (#${serial})`);
            } else {
              results.push(`❌ ${itemName} — فشل`);
            }
          }

          await sendUseLog(interaction, client, char, results, 'activate');

          const embed = new EmbedBuilder()
            .setColor('Green')
            .setTitle('Items Activated')
            .setDescription(results.length ? results.join('\n') : 'No changes');

          return interaction.editReply({ content: null, embeds: [embed], components: [] });
        }

        // ── CONSUMABLE: نفصل single و multi ──
        const singleItems = [];
        const multiItems  = [];

        for (const itemName of selectedValues.slice(0, 5)) {
          const qty = inventory[itemName]?.quantity || 0;
          if (qty === 1) singleItems.push(itemName);
          else multiItems.push({ name: itemName, max: qty });
        }

        if (multiItems.length === 0) {
          await interaction.deferUpdate();

          const used = [];
          for (const itemName of singleItems) {
            if (!inventory[itemName]) continue;
            const result = await removeItem(interaction.user.id, char.character_number, itemName, 1);
            if (result) used.push(`${itemName} x1`);
          }

          await sendUseLog(interaction, client, char, used, 'consume');

          const embed = new EmbedBuilder()
            .setColor('Green')
            .setTitle('Items Used')
            .setDescription(used.length ? used.join('\n') : 'No valid items used');

          return interaction.editReply({ content: null, embeds: [embed], components: [] });
        }

        const singleEncoded = singleItems.join('~') || 'none';
        const multiNames    = multiItems.map(i => i.name);

        const modal = new ModalBuilder()
          .setCustomId(`use-items-${multiNames.join('|')}__single-${singleEncoded}`)
          .setTitle('Use Item | استخدام منتج');

        for (const { name: itemName, max: maxQty } of multiItems.slice(0, 5)) {
          modal.addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId(`qty_${itemName}`)
                .setLabel(`${itemName} (max ${maxQty})`)
                .setPlaceholder(`Max: ${maxQty}`)
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            )
          );
        }

        return interaction.showModal(modal);
      }

      // ===================== STEP 4: modal submit =====================
      if (interaction.isModalSubmit() && interaction.customId.startsWith('use-items-')) {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const raw = interaction.customId.replace('use-items-', '');
        const [itemsPart, singlePart] = raw.split('__single-');
        const multiItems  = itemsPart.split('|');
        const singleItems = singlePart && singlePart !== 'none' ? singlePart.split('~') : [];

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char    = chars.find(c => c.status === 'ONLINE');
        const inventory = await getInventory(interaction.user.id, char.character_number);

        const used = [];

        for (const itemName of singleItems) {
          if (!inventory[itemName]) continue;
          const result = await removeItem(interaction.user.id, char.character_number, itemName, 1);
          if (result) used.push(`${itemName} x1`);
        }

        for (const itemName of multiItems) {
          const value  = interaction.fields.getTextInputValue(`qty_${itemName}`);
          const amount = parseInt(value);
          if (!amount || amount < 1) continue;
          if (!inventory[itemName] || inventory[itemName].quantity < amount) continue;
          const result = await removeItem(interaction.user.id, char.character_number, itemName, amount);
          if (result) used.push(`${itemName} x${amount}`);
        }

        await sendUseLog(interaction, client, char, used, 'consume');

        const embed = new EmbedBuilder()
          .setColor('Green')
          .setTitle('Items Used')
          .setDescription(used.length ? used.join('\n') : 'No valid items used');

        return interaction.editReply({ embeds: [embed], components: [] });
      }

    } catch (err) {
      console.error(err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Error occurred', flags: MessageFlags.Ephemeral });
      }
    }
  }
};

// ===================== HELPERS =====================
function groupByCategory(inventory) {
  const grouped = {};
  for (const [name, data] of Object.entries(inventory)) {
    const cat = data.category || 'misc';
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push({ name, quantity: data.quantity, units: data.items || [] });
  }
  return grouped;
}

function findItemNameBySerial(inventory, serial) {
  for (const [name, data] of Object.entries(inventory)) {
    if (data.items?.some(u => u.serial === serial)) return name;
  }
  return null;
}

async function sendUseLog(interaction, client, char, items, mode = 'consume') {
  const logChannel = client.channels.cache.get(InvUseLog);
  if (!logChannel) return;

  const title = mode === 'activate' ? 'Inventory Log | Activate' : 'Inventory Log | Use';

  const logEmbed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(
`User: <@${interaction.user.id}> (${interaction.user.id})
Username: ${interaction.user.username}
Time: ${DateTime.now().setZone('Asia/Amman').toISO()}

Character Number: #${char.character_number}
Full Name: ${char.firstname} ${char.lastname}
National ID: ${char.national_id}

----------------------------

${mode === 'activate' ? 'Items Activated:' : 'Items Used:'}
${items.length ? items.map(x => `- ${x}`).join('\n') : '- None'}`)
    .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
    .setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

  await logChannel.send({ embeds: [logEmbed] });
}