const { Events, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, MessageFlags, EmbedBuilder, TextInputBuilder, TextInputStyle, ModalBuilder } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { DateTime } = require('luxon');

const { Name } = require('../../JSON/config.json');
const { InvThrowLog } = require('../../JSON/channels.json');
const { getInventory, removeItem, removeItemBySerial, isSerialTracked } = require('../../utils/database/inventory_mysql');

module.exports = {
  name: Events.InteractionCreate,

  async execute(interaction, client) {
    try {

      // ===================== STEP 1 =====================
      if (interaction.isButton() && interaction.customId === 'characterinventory-throw') {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        if (!chars.length) return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);

        const char = chars.find(c => c.status === 'ONLINE');
        if (!char) return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped = groupByCategory(inventory);
        const categories = Object.keys(grouped);

        if (!categories.length) return interaction.editReply('🔍 | الحقيبة فارغة');

        const menu = new StringSelectMenuBuilder()
          .setCustomId('throwitem-selectcategory')
          .setPlaceholder('Select category')
          .addOptions(categories.map(cat => ({ label: cat, value: cat })));

        return interaction.editReply({ components: [new ActionRowBuilder().addComponents(menu)] });
      }

      // ===================== STEP 2 =====================
      if (interaction.isStringSelectMenu() && interaction.customId === 'throwitem-selectcategory') {

        await interaction.deferUpdate();

        const category = interaction.values[0];
        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char = chars.find(c => c.status === 'ONLINE');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped = groupByCategory(inventory);
        const items = grouped[category] || [];

        if (!items.length) return interaction.editReply({ content: '❌ لا يوجد عناصر', components: [] });

        const tracked = isSerialTracked(category);

        let options;

        if (tracked) {
          options = [];
          for (const item of items) {
            for (const unit of item.units) {
              const expLabel = unit.expiry_date ? ` | Exp: ${unit.expiry_date}` : '';
              options.push({
                label: `${item.name}${expLabel}`,
                value: unit.serial
              });
            }
          }
        } else {
          options = items.map(i => ({
            label: `${i.name} (x${i.quantity})`,
            value: i.name
          }));
        }

        options = options.slice(0, 25);

        const select = new StringSelectMenuBuilder()
          .setCustomId(`throwitem-items-${category}__tracked-${tracked}`)
          .setPlaceholder(category)
          .setMinValues(1)
          .setMaxValues(Math.min(tracked ? 1 : 5, options.length))
          .addOptions(options);

        const backBtn = new ButtonBuilder()
          .setCustomId('throwitem-back')
          .setLabel('Back')
          .setStyle(ButtonStyle.Secondary);

        return interaction.editReply({
          content: `Category: **${category}**`,
          components: [
            new ActionRowBuilder().addComponents(select),
            new ActionRowBuilder().addComponents(backBtn)
          ]
        });
      }

      // ===================== BACK =====================
      if (interaction.isButton() && interaction.customId === 'throwitem-back') {

        await interaction.deferUpdate();

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char = chars.find(c => c.status === 'ONLINE');

        const inventory = await getInventory(interaction.user.id, char.character_number);
        const grouped = groupByCategory(inventory);
        const categories = Object.keys(grouped);

        const menu = new StringSelectMenuBuilder()
          .setCustomId('throwitem-selectcategory')
          .setPlaceholder('Select category')
          .addOptions(categories.map(cat => ({ label: cat, value: cat })));

        return interaction.editReply({
          content: 'Select category:',
          components: [new ActionRowBuilder().addComponents(menu)]
        });
      }

      // ===================== STEP 3: اختيار المنتجات =====================
      if (interaction.isStringSelectMenu() && interaction.customId.startsWith('throwitem-items-')) {

        const raw = interaction.customId.replace('throwitem-items-', '');
        const [catPart, trackedPart] = raw.split('__tracked-');
        const category = catPart;
        const tracked  = trackedPart === 'true';

        const selectedValues = interaction.values;

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char = chars.find(c => c.status === 'ONLINE');
        const inventory = await getInventory(interaction.user.id, char.character_number);

        if (tracked) {
          // كل value هو serial → نرمي مباشرة بدون modal
          await interaction.deferUpdate();

          const removed = [];

          for (const serial of selectedValues) {
            const result = await removeItemBySerial(interaction.user.id, char.character_number, serial);
            if (result) removed.push(`${result.item_name} — #${result.item_serial}`);
          }

          await sendThrowLog(interaction, client, char, removed);

          const embed = new EmbedBuilder()
            .setColor('Green')
            .setTitle('Items Removed')
            .setDescription(removed.length ? removed.join('\n') : 'No valid items removed');

          return interaction.editReply({ content: null, embeds: [embed], components: [] });
        }

        // منتجات عادية
        const singleItems = [];
        const multiItems  = [];

        for (const itemName of selectedValues.slice(0, 5)) {
          const qty = inventory[itemName]?.quantity || 0;
          if (qty === 1) singleItems.push(itemName);
          else multiItems.push({ name: itemName, max: qty });
        }

        if (multiItems.length === 0) {
          await interaction.deferUpdate();

          const removed = [];
          for (const itemName of singleItems) {
            const result = await removeItem(interaction.user.id, char.character_number, itemName, 1);
            if (result) removed.push(`${itemName} x1`);
          }

          await sendThrowLog(interaction, client, char, removed);

          const embed = new EmbedBuilder()
            .setColor('Green')
            .setTitle('Items Removed')
            .setDescription(removed.length ? removed.join('\n') : 'No valid items removed');

          return interaction.editReply({ content: null, embeds: [embed], components: [] });
        }

        const singleEncoded = singleItems.join('~') || 'none';
        const multiNames    = multiItems.map(i => i.name);

        const modal = new ModalBuilder()
          .setCustomId(`throw-items-${multiNames.join('|')}__single-${singleEncoded}`)
          .setTitle('Throw Item | رمي منتج');

        for (const { name: itemName, max: maxQty } of multiItems.slice(0, 5)) {
          modal.addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId(`qty_${itemName}`)
                .setLabel(`${itemName} (max ${maxQty})`)
                .setPlaceholder(`Max: ${maxQty}`)
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            )
          );
        }

        return interaction.showModal(modal);
      }

      // ===================== STEP 4: modal submit =====================
      if (interaction.isModalSubmit() && interaction.customId.startsWith('throw-items-')) {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const raw = interaction.customId.replace('throw-items-', '');
        const [itemsPart, singlePart] = raw.split('__single-');
        const multiItems  = itemsPart.split('|');
        const singleItems = singlePart && singlePart !== 'none' ? singlePart.split('~') : [];

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
        const char = chars.find(c => c.status === 'ONLINE');
        const inventory = await getInventory(interaction.user.id, char.character_number);

        const removed = [];

        for (const itemName of singleItems) {
          if (!inventory[itemName]) continue;
          const result = await removeItem(interaction.user.id, char.character_number, itemName, 1);
          if (result) removed.push(`${itemName} x1`);
        }

        for (const itemName of multiItems) {
          const value  = interaction.fields.getTextInputValue(`qty_${itemName}`);
          const amount = parseInt(value);
          if (!amount || amount < 1) continue;
          if (!inventory[itemName] || inventory[itemName].quantity < amount) continue;
          const result = await removeItem(interaction.user.id, char.character_number, itemName, amount);
          if (result) removed.push(`${itemName} x${amount}`);
        }

        await sendThrowLog(interaction, client, char, removed);

        const embed = new EmbedBuilder()
          .setColor('Green')
          .setTitle('Items Removed')
          .setDescription(removed.length ? removed.join('\n') : 'No valid items removed');

        return interaction.editReply({ embeds: [embed], components: [] });
      }

    } catch (err) {
      console.error(err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Error occurred', flags: MessageFlags.Ephemeral });
      }
    }
  }
};

// ===================== HELPERS =====================
function groupByCategory(inventory) {
  const grouped = {};
  for (const [name, data] of Object.entries(inventory)) {
    const cat = data.category || 'misc';
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push({ name, quantity: data.quantity, units: data.items || [] });
  }
  return grouped;
}

async function sendThrowLog(interaction, client, char, removed) {
  const logChannel = client.channels.cache.get(InvThrowLog);
  if (!logChannel) return;

  const logEmbed = new EmbedBuilder()
    .setTitle('Inventory Log | Throw')
    .setDescription(
`User: <@${interaction.user.id}> (${interaction.user.id})
Username: ${interaction.user.username}
Time: ${DateTime.now().setZone('Asia/Amman').toISO()}

Character Number: #${char.character_number}
Full Name: ${char.firstname} ${char.lastname}
National ID: ${char.national_id}

----------------------------

Items Removed:
${removed.length ? removed.map(x => `- ${x}`).join('\n') : '- None'}`)
    .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
    .setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

  await logChannel.send({ embeds: [logEmbed] });
}