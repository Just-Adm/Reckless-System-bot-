const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { pool } = require('../../utils/database/mysql');


module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {


    if (interaction.isButton() && interaction.customId === 'charactercontrol-manage_properties') {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
      }

      const char = rows.find(c => c.status === 'ONLINE') || rows[0];

      if (!char) {
        return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');
      }

      const container = new ContainerBuilder()
        .setAccentColor(0x2f3136)

        // Description
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            '> <:property:1497627170183446731> | Propertys Control'
          )
        )

        .addSeparatorComponents(
          new SeparatorBuilder()
            .setDivider(true)
            .setSpacing(SeparatorSpacingSize.Small)
        )

        // Buttons
        .addActionRowComponents(
          new ActionRowBuilder().addComponents(

            new ButtonBuilder()
              .setCustomId('properties-garage')
              .setLabel('Garages')
              .setEmoji('<:Car:1497627023055786118>')
              .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
              .setCustomId('properties-house')
              .setLabel('Houses')
              .setEmoji('<:House:1497627093846986833>')
              .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
              .setCustomId('properties-storage')
              .setLabel('Ware Houses')
              .setEmoji('<:WareHouses:1497627236021309540>')
              .setStyle(ButtonStyle.Secondary)

          )
        );

      return interaction.editReply({
  components: [container],
  flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
});
    }

  }
};