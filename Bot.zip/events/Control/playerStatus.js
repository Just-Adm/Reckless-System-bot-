 const { Events, AttachmentBuilder, MessageFlags } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const { pool } = require('../../utils/database/mysql');
const path = require('path');

module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction, client) {

    if (interaction.isButton() && interaction.customId === 'charactercontrol-status') {

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const userId = interaction.user.id;
    const characters = await getCharacters(userId);

    if (!characters || characters.length === 0) {
      return interaction.editReply({
        content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`
      });
    }

    const onlineChar = characters.find(c => c.status === 'ONLINE');

    if (!onlineChar) {
      return interaction.editReply({
        content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا'
      });
    }

    const buffer = await buildStatusCanvas(onlineChar);
    const attachment = new AttachmentBuilder(buffer, { name: 'status.png' });

    return interaction.editReply({
      files: [attachment]
    });
  }
  },
};

async function buildStatusCanvas(char) {
  const W = 1160;
  const H = 1284;

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  try {
    const bg = await loadImage(path.join(__dirname, '../../images/player/status.png'));
    ctx.drawImage(bg, 0, 0, W, H);
  } catch {
    ctx.fillStyle = '#141417';
    ctx.fillRect(0, 0, W, H);
  }

  const PADDING_X  = 70;
  const BAR_H      = 38;
  const BAR_RADIUS = 19;
  const BAR_W      = W - PADDING_X * 2;
  const PCT_FONT   = 'bold 46px Arial';

  const bars = [
    { value: char.hunger ?? 100,     color: '#f5c518', trackColor: '#2e2a10', barY: 410,  pctY: 398 },
    { value: char.thirst ?? 100,     color: '#4ab3f5', trackColor: '#0f2030', barY: 688,  pctY: 676 },
    { value: char.job_level ?? 70,   color: '#e84040', trackColor: '#2a0f0f', barY: 934,  pctY: 922 },
    { value: char.crime_level ?? 50, color: '#e84040', trackColor: '#2a0f0f', barY: 1168, pctY: 1156 },
  ];

  for (const bar of bars) {
    const pct = Math.min(Math.max(bar.value, 0), 100);
    const fillW = (pct / 100) * BAR_W;

    roundRect(ctx, PADDING_X, bar.barY, BAR_W, BAR_H, BAR_RADIUS);
    ctx.fillStyle = bar.trackColor;
    ctx.fill();

    if (fillW > 0) {
      ctx.shadowColor = bar.color;
      ctx.shadowBlur = 28;

      roundRect(ctx, PADDING_X, bar.barY, fillW, BAR_H, BAR_RADIUS);
      ctx.fillStyle = bar.color;
      ctx.fill();

      ctx.shadowBlur = 0;
    }

    ctx.font = PCT_FONT;
    ctx.fillStyle = bar.color;
    ctx.textAlign = 'right';
    ctx.fillText(`${pct}%`, W - PADDING_X, bar.pctY);
  }

  return canvas.toBuffer('image/png');
}

function roundRect(ctx, x, y, w, h, r) {
  if (w < 2 * r) r = w / 2;
  if (h < 2 * r) r = h / 2;

  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y,     x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x,     y + h, r);
  ctx.arcTo(x,     y + h, x,     y,     r);
  ctx.arcTo(x,     y,     x + w, y,     r);
  ctx.closePath();
}

async function getCharacters(userId) {
  const [rows] = await pool.query(
    `SELECT 
        character_number,
        status,
        hunger,
        thirst,
        job_level,
        crime_level
     FROM characters
     WHERE user_id = ?
     ORDER BY character_number ASC`,
    [userId]
  );

  return rows;
}