const { EmbedBuilder, MessageFlags } = require('discord.js');
const { pool } = require('../../utils/database/mysql');

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {

    if (interaction.isButton() && interaction.customId === 'charactercontrol-show_info') {

      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const [rows] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ?`,
        [interaction.user.id]
      );

      if (!rows.length) {
        return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
      }

      const char = rows.find(c => c.status === 'ONLINE') || rows[0];

      const embed = new EmbedBuilder()
.setTitle('Character Information')
.setDescription(
`**Character Number:** #${char.character_number}
**Full Name:** ${char.firstname} ${char.lastname}
**DOB:** ${formatDate(char.dateofbirth)}
**POB:** ${char.placeofbirth}

**National ID:** ${char.national_id}
**Serial Number:** ${char.serial_number}
**IBAN:** ${char.iban}

**Job:** ${char.job || 'Unemployed'}
**Cash:** $${char.cash || 0}
**Bank:** $${char.bank || 0}

**Status:** ${char.status || 'OFFLINE'}

**Issue Date:** ${formatDate(char.issue_date)}
**Expiry Date:** ${formatDate(char.expiry_date)}`)

      return interaction.editReply({
        embeds: [embed]
      });
    }
  }
};


function formatDate(dateString) {
  const date = new Date(dateString);

  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();

  return `${day}/${month}/${year}`;
}