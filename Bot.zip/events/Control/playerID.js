const { Events, ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder, MessageFlags } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const path = require('path');
const { pool } = require('../../utils/database/mysql');

module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction, client) {

    try {

      if (interaction.isButton() && interaction.customId === 'charactercontrol-show_id') {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const [rows] = await pool.query(
          `SELECT * FROM characters WHERE user_id = ?`,
          [interaction.user.id]
        );

        if (!rows.length) {
          return interaction.editReply(`<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`);
        }

        const char = rows.find(c => c.status === 'ONLINE');

        if (!char) {
          return interaction.editReply('<:Warn:1497627240177991780> | قم بإختيار شخصية أولا');
        }

        const canvas = await generateIdCard(char);
        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'IdCard.png' });

        const button = new ButtonBuilder()
          .setCustomId('charactercontrol_ShareID')
          .setLabel('Share')
          .setEmoji('<:arrow:1499868235380555827>')
          .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder().addComponents(button);

        return interaction.editReply({
          files: [attachment],
          components: [row]
        });
      }

      if (interaction.isButton() && interaction.customId === 'charactercontrol_ShareID') {

        const modal = new ModalBuilder()
          .setCustomId('share_identity_modal')
          .setTitle('Share Identity | مشاركة الهوية');

        const nationalInput = new TextInputBuilder()
          .setCustomId('share_nationalId')
          .setLabel('National ID')
          .setPlaceholder('قم بإدخال الرقم الوطني كامل')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        modal.addComponents(
          new ActionRowBuilder().addComponents(nationalInput)
        );

        return interaction.showModal(modal);
      }

      if (interaction.isModalSubmit() && interaction.customId === 'share_identity_modal') {

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const nationalId = interaction.fields.getTextInputValue('share_nationalId')?.trim();

        if (!nationalId) {
          return interaction.editReply('<:Warn:1497627240177991780> | قم بإدخال رقم الوطني كامل');
        }

        const [rows] = await pool.query(`SELECT * FROM characters`);

        const char = rows.find(r => r.national_id === nationalId);

        if (char.user_id === interaction.user.id) {
          return interaction.editReply('<:No:1497627141465178132> | لا يمكنك إرسال الهوية لنفسك');
        }

        if (!char) {
          return interaction.editReply('<:No:1497627141465178132> | رقم الوطني غير صحيح');
        }

        const canvas = await generateIdCard(char);
        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'IdCard.png' });

        try {
          const user = await interaction.client.users.fetch(char.user_id);

          await user.send({
            files: [attachment]
          });

        } catch (err) {
          return interaction.editReply('❌ DM مغلق عند اللاعب');
        }

        return interaction.editReply('<:Yes:1497627245873991750> | تم إظهار الهوية بنجاح');
      }

    } catch (err) {
      console.error('Interaction Error:', err);

      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: '❌ حدث خطأ غير متوقع',
          flags: MessageFlags.Ephemeral
        });
      } else {
        await interaction.editReply('❌ حدث خطأ غير متوقع');
      }
    }
  }
};


async function generateIdCard(char) {

  const canvas = createCanvas(1536, 1024);
  const ctx = canvas.getContext('2d');

  const bgPath = char.image_url && char.image_url.startsWith('http')
    ? path.join(__dirname, '../../images/player/idcard.png')
    : path.join(__dirname, '../../images/player/idcard2.png');

  const bg = await loadImage(bgPath);
  ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

  if (char.image_url) {
    try {
      const img = await loadImage(char.image_url);

      const x = 35;
      const y = 210;

      const width = 448;
      const height = 580;

      ctx.save();
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';

      ctx.drawImage(img, x, y, width, height);

      const stamp = await loadImage(
        path.join(__dirname, '../../images/server/flag.png')
      );

      ctx.drawImage(stamp, x + width - 110, y + height - 180, 200, 200);

      ctx.restore();

    } catch (err) {
      console.log('Image load failed', err);
    }
  }

  ctx.fillStyle = '#1f2f4a';

  ctx.font = 'bold 58px "Times New Roman", serif';
  ctx.fillText(`${char.firstname} ${char.lastname}`, 550, 302);

  ctx.font = 'bold 45px "Times New Roman", serif';
  ctx.fillText(formatDate(char.dateofbirth), 555, 403);
  ctx.fillText(char.placeofbirth, 550, 512);
  ctx.fillText(char.national_id, 550, 635);

  ctx.fillText(formatDate(char.issue_date), 315, 858);

  ctx.font = 'bold 40px "Times New Roman", serif';
  ctx.fillText(formatDate(char.expiry_date), 1315, 858);

  ctx.fillText(char.serial_number, 600, 953);

  return canvas;
}


function formatDate(dateString) {
  const date = new Date(dateString);

  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();

  return `${day}/${month}/${year}`;
}