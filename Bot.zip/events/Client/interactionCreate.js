const { Events, EmbedBuilder, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { DateTime } = require('luxon');

const interactionCooldowns = new Map();
const COOLDOWN_TIME = 5000;

module.exports = {
  name: Events.InteractionCreate,

  async execute(interaction, client) {
    try {
      if (!interaction.isChatInputCommand()) return;

      const userId = interaction.user.id;

      const lastUsed = interactionCooldowns.get(userId) || 0;
      const now = Date.now();
      if (now - lastUsed < COOLDOWN_TIME) {
        const remaining = ((COOLDOWN_TIME - (now - lastUsed)) / 1000).toFixed(1);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: `⏳ يرجى إنتظار **${remaining}** ثانية لإستخدام التفاعل مرة أخرى`, flags: MessageFlags.Ephemeral });
        } else {
          await interaction.reply({ content: `⏳ يرجى إنتظار **${remaining}** ثانية لإستخدام التفاعل مرة أخرى`, flags: MessageFlags.Ephemeral });
        }
        return;
      }

      interactionCooldowns.set(userId, now);
      setTimeout(() => interactionCooldowns.delete(userId), COOLDOWN_TIME);

      const command = interaction.client.slashCommands.get(interaction.commandName);
      if (!command) return;

      await command.execute(interaction);

    } catch (error) {
      console.error('Interaction Error:', error);

      const errorEmbed = new EmbedBuilder()
.setTitle('❌ Error Logger')
.setDescription(`\`\`\`يوجد ايرور يرجى تواصل مع فريق الدعم الفني\`\`\``)
.setColor('Red')
.setFooter({ text: 'يرجى التواصل مع الدعم الفني' })
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate());

      try {
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
        } else {
          await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
        }
      } catch (innerError) {
        console.error('Failed to reply to interaction:', innerError);
      }
    }
  }
};

process.on('uncaughtException', error => {
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});