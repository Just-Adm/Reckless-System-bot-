require('dotenv').config({ quiet: true });
const { joinVoiceChannel } = require('@discordjs/voice');
const figlet = require('figlet');

const playtimeWatcher = require('../Charatcers/charatcerTracker');

const { Status1, VoiceChannel } = require('../../JSON/config.json');


module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {

    client.user.setPresence({
      status: 'dnd',
      activities: [{ type: 4, name: Status1, state: Status1 }]
    });


    setInterval(() => {
      client.channels.fetch(VoiceChannel)
      .then(channel => joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        })).catch(() => {});
        }, 1000);

    setTimeout(() => {
      figlet.text('SAHM', { font: 'Slant' }, (err, data) => {
        if (err) return;
        console.log(data);
        });
      }, 2000);

      playtimeWatcher.execute(client);

  }
};