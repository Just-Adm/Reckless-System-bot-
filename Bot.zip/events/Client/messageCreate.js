const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { DateTime } = require('luxon');

const cooldowns = new Map();
const COOLDOWN_TIME = 5000;

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    try {
      if (message.author.bot) return;

      const args = message.content.trim().split(/ +/);
      const commandName = args.shift().toLowerCase();

      const commandFile = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases?.includes(commandName));
      if (!commandFile) return;

      const lastUsed = cooldowns.get(message.author.id) || 0;
      const now = Date.now();

      if (now - lastUsed < COOLDOWN_TIME) {
        const remaining = ((COOLDOWN_TIME - (now - lastUsed)) / 1000).toFixed(1);
        const reply = await message.reply(`⏳ يرجى إنتظار **${remaining}** ثانية لإستخدام الامر مره اخرى`);
        setTimeout(() => reply.delete().catch(() => {}), 3000);
        return;
      }

      cooldowns.set(message.author.id, now);
      setTimeout(() => cooldowns.delete(message.author.id), COOLDOWN_TIME);

      await commandFile.execute(client, message, args);

    } catch (error) {
      console.error('Message Command Error:', error);


      try {
        const errorEmbed = new EmbedBuilder()
.setTitle('❌ Error Logger')
.setDescription(`\`\`\`يوجد ايرور يرجى تواصل مع فريق الدعم الفني\`\`\``)
.setColor('Red')
.setFooter({ text: 'يرجى التواصل مع الدعم الفني' })
.setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate());

        await message.reply({ embeds: [errorEmbed] });
      } catch (innerError) {
        console.error('Failed to send error embed:', innerError);
      }
    }
  }
};

process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});