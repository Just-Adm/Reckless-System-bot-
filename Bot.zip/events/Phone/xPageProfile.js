const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ModalBuilder, LabelBuilder, TextInputBuilder, TextInputStyle, MessageFlags } = require('discord.js');
const xDB = require('../../utils/database/twitter_mysql');
const { drawUserProfile } = require('./xCanvasRenderer');

async function renderMyProfilePage(interaction, account, lang, isViewingOthers = false) {
  const customId = interaction.customId;
  let currentAccount = account;

  // التحقق من تفعيل خيار الضغط على زر المتابعة
  if (interaction.isButton() && customId && customId.startsWith('x-profile-follow-toggle_')) {
    const targetId = parseInt(customId.split('_')[1]);
    
    const [chars] = await xDB.pool.query(`SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`, [interaction.user.id]);
    const myAccount = await xDB.getAccountByPhone(chars[0]?.item_serial);
    
    if (myAccount && myAccount.id !== targetId) {
      await xDB.toggleFollow(myAccount.id, targetId);
    }
    currentAccount = await xDB.getAccountById(targetId);
    isViewingOthers = true;
  }

  // معالجة اختيار تبديل الثيم من القائمة المنسدلة
  if (interaction.isStringSelectMenu() && customId && customId.startsWith('x-profile-menu-options_')) {
    const selection = interaction.values[0];
    if (selection === 'toggle_theme') {
      const nextTheme = currentAccount.theme === 'dark' ? 'light' : 'dark';
      await xDB.updateTheme(currentAccount.id, nextTheme);
      currentAccount.theme = nextTheme;
    }

    if (selection === 'edit_info') {
      const modal = new ModalBuilder()
        .setCustomId(`x-profile-edit-submit_${lang}`)
        .setTitle(lang === 'ar' ? 'تعديل معلومات الملف الشخصي' : 'Update Profile Info')
        .setLabelComponents(
          new LabelBuilder().setLabel('Display Name (1-8 chars)').setTextInputComponent(new TextInputBuilder().setCustomId('d').setValue(currentAccount.display_name).setStyle(TextInputStyle.Short).setMaxLength(8).setRequired(true)),
          new LabelBuilder().setLabel('Bio (0-40 chars)').setTextInputComponent(new TextInputBuilder().setCustomId('b').setValue(currentAccount.bio || '').setStyle(TextInputStyle.Paragraph).setMaxLength(40).setRequired(false))
        );
      return interaction.showModal(modal);
    }
  }

  // معالجة تسليم مودال تحديث البيانات الشخصية
  if (interaction.isModalSubmit() && customId && customId.startsWith('x-profile-edit-submit_')) {
    const newDisp = interaction.fields.getTextInputValue('d').trim();
    const newBio = interaction.fields.getTextInputValue('b').trim() || null;
    
    if (newDisp.length >= 1 && newDisp.length <= 8) {
      await xDB.updateProfileData(currentAccount.id, newDisp, newBio);
      currentAccount = await xDB.getAccountById(currentAccount.id);
    }
  }

  const theme = currentAccount?.theme || 'light';
  const imageBuffer = await drawUserProfile(currentAccount, theme);
  const attachment = new AttachmentBuilder(imageBuffer, { name: `x_profile_${currentAccount.id}_${Date.now()}.png` });

  const rows = [];

  if (!isViewingOthers) {
    const menuRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`x-profile-menu-options_${lang}`)
        .setPlaceholder(lang === 'ar' ? '⚙️ خيارات الحساب والمظهر...' : '⚙️ Account Options & Theme...')
        .addOptions([
          { label: lang === 'ar' ? 'تعديل المعلومات (الاسم والبيو)' : 'Edit Profile Info', value: 'edit_info', emoji: '📝' },
          { label: lang === 'ar' ? `تحويل الوضع إلى: ${theme === 'dark' ? 'الأبيض ☀️' : 'الداكن 🌙'}` : `Switch Theme to: ${theme === 'dark' ? 'Light ☀️' : 'Dark 🌙'}`, value: 'toggle_theme', emoji: '🎨' }
        ])
    );
    rows.push(menuRow);
  } else {
    const followRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`x-profile-follow-toggle_${currentAccount.id}_${lang}`).setLabel(lang === 'ar' ? 'متابعة / إلغاء المتابعة ➕' : 'Follow / Unfollow ➕').setStyle(ButtonStyle.Primary)
    );
    rows.push(followRow);
  }

  const controlRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`x-back-to-hub_${lang}`).setLabel(lang === 'ar' ? 'رجوع للرئيسية 🏠' : 'Back to Hub 🏠').setStyle(ButtonStyle.Danger)
  );
  rows.push(controlRow);

  // إرسال كملف مباشر بدون مصفوفة إمبيدز لمنع الكراش
  return interaction.editReply({
    components: rows,
    files: [attachment],
    embeds: [], // تفريغ الإمبيدز تماماً للامتثال لقواعد Components V2
    flags: MessageFlags.IsComponentsV2
  });
}

module.exports = { renderMyProfilePage };