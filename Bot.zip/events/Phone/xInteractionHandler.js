const { Events, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, LabelBuilder, MessageFlags } = require('discord.js');
const xDB = require('../../utils/database/twitter_mysql');
const { renderHomePage } = require('./xPageHome');
const { renderSearchPage } = require('./xPageSearch');
const { renderMyProfilePage } = require('./xPageProfile');

module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction) {
    try {
      const customId = interaction.customId;

      // ─────────────────────────────────────────────
      // تفاعلات أزرار التنقل والـ Home Page
      // ─────────────────────────────────────────────
      if (interaction.isButton() && customId?.startsWith('x-home-page_')) {
        await interaction.deferUpdate();
        const [_, pageStr, lang] = customId.split('_');
        return renderHomePage(interaction, lang, parseInt(pageStr));
      }

      // تفاعل زر اللايك والريبوسيت تحت كل صورة تغريدة
      if (interaction.isButton() && (customId?.startsWith('x-action-like_') || customId?.startsWith('x-action-repost_'))) {
        await interaction.deferUpdate();
        const [type, postId, curPage, lang] = customId.split('_');
        
        // جلب بيانات الحساب
        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`, [interaction.user.id]);
        const account = await xDB.getAccountByPhone(chars[0]?.item_serial);

        if (type.includes('like')) {
          await xDB.toggleLike(account.id, parseInt(postId));
        } else {
          // دالة ريبوست اختيارية بقاعدة البيانات الخاصة بك
          await pool.query(`UPDATE x_posts SET reposts = reposts + 1 WHERE id = ?`, [postId]);
        }
        // إعادة تحديث الصفحة الحالية لرؤية الأرقام المحدثة
        return renderHomePage(interaction, lang, parseInt(curPage));
      }

      // ─────────────────────────────────────────────
      // تفاعلات الـ Search
      // ─────────────────────────────────────────────
      if (interaction.isButton() && customId?.startsWith('x-trigger-search-modal_')) {
        const lang = customId.split('_')[1];
        const modal = new ModalBuilder()
          .setCustomId(`x-search-submit-modal_${lang}`)
          .setTitle('البحث في تويتر')
          .setLabelComponents(
            new LabelBuilder().setLabel('ادخل الكلمة المراد البحث عنها').setTextInputComponent(
              new TextInputBuilder().setCustomId('search_query').setStyle(TextInputStyle.Short).setRequired(true)
            )
          );
        return interaction.showModal(modal);
      }

      if (interaction.isModalSubmit() && customId?.startsWith('x-search-submit-modal_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const query = interaction.fields.getTextInputValue('search_query');
        const results = await xDB.searchAccounts(query);
        return renderSearchPage(interaction, lang, results);
      }

      // عرض بروفايل شخص أخر تم إيجاده بالبحث
      if (interaction.isButton() && customId?.startsWith('x-view-profile_')) {
        await interaction.deferUpdate();
        const [_, targetId, lang] = customId.split('_');
        const targetAccount = await xDB.getAccountById(parseInt(targetId));
        return renderMyProfilePage(interaction, targetAccount, lang);
      }

      // ─────────────────────────────────────────────
      // تفاعلات الـ My Profile وقائمة الخيارات المنسدلة
      // ─────────────────────────────────────────────
      if (interaction.isStringSelectMenu() && customId?.startsWith('x-profile-options_')) {
        const lang = customId.split('_')[1];
        const selectedValue = interaction.values[0];

        // استخراج الحساب الشخصي أولاً
        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`, [interaction.user.id]);
        const account = await xDB.getAccountByPhone(chars[0]?.item_serial);

        // 1. قلب خيار الثيم (Dark / Light)
        if (selectedValue === 'toggle_theme') {
          await interaction.deferUpdate();
          const newTheme = account.theme === 'dark' ? 'light' : 'dark';
          await xDB.updateTheme(account.id, newTheme);
          account.theme = newTheme; // تحديث الكائن محلياً لإعادة الرسم فورا
          return renderMyProfilePage(interaction, account, lang);
        }

        // 2. إطلاق مودال تغيير المعلومات الشخصية
        if (selectedValue === 'edit_info') {
          const modal = new ModalBuilder()
            .setCustomId(`x-edit-profile-modal_${lang}`)
            .setTitle('تحديث بيانات الحساب')
            .setLabelComponents(
              new LabelBuilder().setLabel('الاسم المعروض الجديد').setTextInputComponent(
                new TextInputBuilder().setCustomId('new_display').setStyle(TextInputStyle.Short).setValue(account.display_name).setMaxLength(8)
              ),
              new LabelBuilder().setLabel('النبذة التعريفية (Bio)').setTextInputComponent(
                new TextInputBuilder().setCustomId('new_bio').setStyle(TextInputStyle.Paragraph).setValue(account.bio || '').setMaxLength(40)
              )
            );
          return interaction.showModal(modal);
        }
      }

      // استقبال بيانات مودال تحديث الملف الشخصي وتحديث الصورة فوراً
      if (interaction.isModalSubmit() && customId?.startsWith('x-edit-profile-modal_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const newDisplay = interaction.fields.getTextInputValue('new_display');
        const newBio = interaction.fields.getTextInputValue('new_bio');

        const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`, [interaction.user.id]);
        let account = await xDB.getAccountByPhone(chars[0]?.item_serial);

        await xDB.updateProfileData(account.id, newDisplay, newBio);
        
        // جلب البيانات المحدثة مجدداً لإعادة رسم الـ Canvas بالشكل الجديد
        account = await xDB.getAccountById(account.id);
        return renderMyProfilePage(interaction, account, lang);
      }

      // ─────────────────────────────────────────────
      // زِر العودة الشامل لجميع الصفحات (Back to Main)
      // ─────────────────────────────────────────────
      if (interaction.isButton() && customId?.startsWith('x-back-main_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[2] || 'en';
        // استدعاء دالة بناء الصفحة الرئيسية العادية الخاصة بالبوت (buildMainPage) دون أي صور ملحقة
        return interaction.editReply({
          components: [buildMainPage(lang)],
          files: [], // تصفير الملفات والصور المرفوعة سابقاً لضمان واجهة نظيفة
          flags: MessageFlags.IsComponentsV2,
        });
      }

    } catch (err) {
      console.error('[X Interaction Router Error]', err);
    }
  }
};