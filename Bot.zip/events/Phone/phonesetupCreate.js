const { ContainerBuilder, Events, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags, MediaGalleryBuilder, MediaGalleryItemBuilder } = require('discord.js');
const { pool } = require('../../utils/database/mysql');
const { getUsedItem } = require('../../utils/database/inventory_mysql');
const phoneDB = require('../../utils/database/phone_mysql');

const { WelcomeIphone, PhoneLanguage, PhonePasscode, PhoneFaceid, PhoneHello } = require('../../JSON/images.json');


const T = {
  en: {
    next: 'Next', back: 'Back', getStarted: 'Get Started',
    chooseLanguage: '# Choose Your Language', languageSub: '-# Select a language to continue',
    createPasscode: 'Create Passcode', passcodePage: '# Create a Passcode', passcodeSub: '-# Set a 4–8 digit PIN to protect your phone',
    faceIdPage: '# Face ID', faceIdInfo: '-# Face ID will be used to unlock your phone automatically.', faceIdReady: 'Continue',
    hello: '# Hello', settings: 'Settings', welcome: '# Hello',
    contacts: 'Contacts', bank: 'Apple Pay', x: 'X', news: 'Wazel News', messages: 'Messages', notes: 'Notes',
    locked: '# 🔒 Phone Locked', enterPasscode: '-# Enter passcode to continue', inputPasscode: 'Enter Passcode',
    wrongPasscode: '❌ Incorrect passcode. Try Again.', tryAgain: 'Try Again',
    phoneLimitReached: '> ❌ | You have reached the maximum limit of **3 phones** per character.\n-# Delete an old phone from your inventory to get a new one.',
  },
  ar: {
    next: 'التالي', back: 'السابق', getStarted: 'ابدأ الآن',
    chooseLanguage: '# اختر لغتك', languageSub: '-# اختر لغة للمتابعة',
    createPasscode: 'تحديد الباسكود', passcodePage: '# تحديد الباسكود', passcodeSub: '-# حدد رقم سري من 4–8 أرقام لحماية هاتفك',
    faceIdPage: '# Face ID & بصمة الوجه', faceIdInfo: '-# سيُستخدم Face ID لفتح هاتفك تلقائياً.', faceIdReady: 'متابعة',
    hello: '# أهلاً', settings: 'الإعدادات', welcome: '# مرحباً بك',
    contacts: 'جهات الإتصال', bank: 'البنك', x: 'X', news: 'أعلام ريكليس', messages: 'الرسائل', notes: 'ملاحظات',
    locked: '# 🔒 الهاتف مقفل', enterPasscode: '-# أدخل الباسكود للمتابعة', inputPasscode: 'إدخال الباسكود',
    wrongPasscode: '❌ الباسكود الذي أدخلته غير صحيح.', tryAgain: 'إعادة المحاولة',
    phoneLimitReached: '> ❌ | وصلت للحد الأقصى وهو **3 هواتف** لكل شخصية.\n-# احذف هاتفاً قديماً من حقيبتك للحصول على هاتف جديد.',
  },
};


const Pages = {

  welcomeStart(lang = 'en') {
    const t = tr(lang);
    return new ContainerBuilder()
      .setAccentColor(0x2c2c2e)
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(WelcomeIphone))
      )
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('playerphone-setup_lang')
            .setLabel(t.getStarted)
            .setStyle(ButtonStyle.Secondary)
        )
      );
  },

  chooseLanguage() {
    return new ContainerBuilder()
      .setAccentColor(0x2c2c2e)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent('# Choose Language | اختر اللغة'))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent('-# Pick a language to continue | اختر لغة للمتابعة'))
      .addSeparatorComponents(sep())
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(PhoneLanguage))
      )
      .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('playerphone-setup_lang_en').setLabel('English 🇺🇸').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('playerphone-setup_lang_ar').setLabel('العربية 🇸🇦').setStyle(ButtonStyle.Secondary)
        )
      );
  },

  passcode(lang) {
    const t = tr(lang);
    return new ContainerBuilder()
      .setAccentColor(0x2c2c2e)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.passcodePage))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.passcodeSub))
      .addSeparatorComponents(sep())
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(PhonePasscode))
      )
      .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`playerphone-setup_passcode_modal_${lang}`)
            .setLabel(t.createPasscode)
            .setEmoji('<:password:1505184087315320862>')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('playerphone-setup_back_lang')
            .setLabel(t.back)
            .setStyle(ButtonStyle.Secondary)
        )
      );
  },

  faceId(lang) {
    const t = tr(lang);
    return new ContainerBuilder()
      .setAccentColor(0x2c2c2e)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.faceIdPage))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.faceIdInfo))
      .addSeparatorComponents(sep())
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(PhoneFaceid))
      )
      .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`playerphone-setup_finish_${lang}`)
            .setLabel(t.faceIdReady)
            .setEmoji('<:faceid:1505185150324179016>')
            .setStyle(ButtonStyle.Secondary)
        )
      );
  },

  hello(lang, charName) {
    const t = tr(lang);
    return new ContainerBuilder()
      .setAccentColor(0x2c2c2e)
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(PhoneHello))
      )
      .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('playerphone-app_contacts').setLabel(t.contacts).setEmoji('<:Contacts:1497627035097370794>').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('playerphone-app_notes').setLabel(t.notes).setEmoji('<:notes:1505200105081536704>').setStyle(ButtonStyle.Secondary)
        )
      )
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('playerphone-app_x').setLabel(t.x).setEmoji('<:twitter:1497627221756743700>').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('playerphone-app_news').setLabel(t.news).setEmoji('<:wazelnews:1497627242614751435>').setStyle(ButtonStyle.Secondary)
        )
      )
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          
          new ButtonBuilder().setCustomId('playerphone-app_bank').setLabel(t.bank).setEmoji('<:applepay:1505185909732278363>').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('playerphone-app_settings').setLabel(t.settings).setEmoji('<:applesettings:1505186208945406022>').setStyle(ButtonStyle.Secondary)
        )
      );
  },

  noPhone(lang = 'en') {
    const msg = lang === 'ar'
      ? '> <:Warn:1497627240177991780> | لم يتم تفعيل أي هاتف\n-# استخدم هاتفاً من حقيبتك أولاً'
      : '> <:Warn:1497627240177991780> | No active phone found\n-# Use a phone from your inventory first';

    return new ContainerBuilder()
      .setAccentColor(0xff3b30)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(msg));
  },

  phoneLimitReached(lang = 'en') {
    const t = tr(lang);
    return new ContainerBuilder()
      .setAccentColor(0xff3b30)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.phoneLimitReached));
  },

  locked(lang, serial) {
    const t = tr(lang);
    return new ContainerBuilder()
      .setAccentColor(0x2c2c2e)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.locked))
      .addSeparatorComponents(sep())
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.enterPasscode))
      .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`playerphone-unlock_modal_${serial}_${lang}`)
            .setLabel(t.inputPasscode)
            .setEmoji('<:password:1505184087315320862>')
            .setStyle(ButtonStyle.Secondary)
        )
      );
  },

  wrongPasscode(lang, serial) {
    const t = tr(lang);
    return new ContainerBuilder()
      .setAccentColor(0xff3b30)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.wrongPasscode))
      .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`playerphone-unlock_modal_${serial}_${lang}`)
            .setLabel(t.tryAgain)
            .setStyle(ButtonStyle.Danger)
        )
      );
  },
};



module.exports = {
  name: Events.InteractionCreate,

  async execute(interaction, client) {

    if (interaction.isButton() && interaction.customId === 'playerphone-use_phone') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      purgeInactivePhones();

      const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
      if (!chars.length) return interaction.editReply({ content: `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا` });

      const char = chars.find(c => c.status === 'ONLINE');
      if (!char) return interaction.editReply({ content: '<:Warn:1497627240177991780> | قم بإختيار شخصية أولا' });

      const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');

      if (!usedItem) {
        return interaction.editReply({
          components: [Pages.noPhone('en')],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      const phoneSerial = usedItem.item_serial;
      let phoneData     = await phoneDB.getPhone(phoneSerial);

      if (!phoneData) {
        const phoneCount = await getCharPhoneCount(interaction.user.id, char.character_number);
        if (phoneCount >= 3) {
          return interaction.editReply({
            components: [Pages.phoneLimitReached('en')],
            flags: MessageFlags.IsComponentsV2,
          });
        }

        const uniqueNumber = await phoneDB.generateUniqueUSPhoneNumber();

        phoneData = await phoneDB.createPhone({
          serial:          phoneSerial,
          ownerUserId:     interaction.user.id,
          ownerNationalId: char.national_id,
          charNumber:      char.character_number,
          phoneNumber:     uniqueNumber,
        });

        await pool.query(
          `UPDATE characters SET phone_number = ?, phone_serial = ?
           WHERE user_id = ? AND character_number = ?`,
          [uniqueNumber, phoneSerial, interaction.user.id, char.character_number]
        );

        return interaction.editReply({
          components: [Pages.welcomeStart('en')],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      await touchPhone(phoneSerial);

      if (!phoneData.setup_done) {
        return interaction.editReply({
          components: [Pages.welcomeStart('en')],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      const lang    = phoneData.language || 'en';
      const isOwner = phoneData.owner_national_id === char.national_id;

      if (isOwner) {
        return interaction.editReply({
          components: [Pages.hello(lang, `${char.firstname} ${char.lastname}`)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      return interaction.editReply({
        components: [Pages.locked(lang, phoneSerial)],
        flags: MessageFlags.IsComponentsV2,
      });
    }

    if (interaction.isButton() && interaction.customId === 'playerphone-setup_lang') {
      await interaction.deferUpdate();
      return interaction.editReply({ components: [Pages.chooseLanguage()], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'playerphone-setup_back_welcome') {
      await interaction.deferUpdate();
      return interaction.editReply({ components: [Pages.welcomeStart('en')], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && (interaction.customId === 'playerphone-setup_lang_en' || interaction.customId === 'playerphone-setup_lang_ar')) {
      await interaction.deferUpdate();
      const selectedLang = interaction.customId.endsWith('ar') ? 'ar' : 'en';
      return interaction.editReply({ components: [Pages.passcode(selectedLang)], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'playerphone-setup_back_lang') {
      await interaction.deferUpdate();
      return interaction.editReply({ components: [Pages.chooseLanguage()], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId.startsWith('playerphone-setup_passcode_modal_')) {
      const lang = interaction.customId.split('_').pop();

      const modal = new ModalBuilder()
        .setCustomId(`playerphone-setup_passcode_submit_${lang}`)
        .setTitle(lang === 'ar' ? 'إنشاء رمز الدخول' : 'Create Passcode')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('passcode_input')
              .setLabel(lang === 'ar' ? 'أدخل من 4 إلى 8 أرقام فقط' : 'Enter 4–8 digits')
              .setStyle(TextInputStyle.Short)
              .setMinLength(4)
              .setMaxLength(8)
              .setRequired(true)
          )
        );

      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('playerphone-setup_passcode_submit_')) {
      await interaction.deferUpdate();

      const lang     = interaction.customId.split('_').pop();
      const passcode = interaction.fields.getTextInputValue('passcode_input').trim();

      if (!/^\d+$/.test(passcode)) {
        return interaction.editReply({
          content: lang === 'ar' ? '❌ يجب أن يحتوي رمز الدخول على أرقام فقط.' : '❌ Passcode must contain digits only.'
        });
      }

      await phoneDB.saveTempSetup(interaction.user.id, { lang, passcode });

      return interaction.editReply({ components: [Pages.faceId(lang)], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId.startsWith('playerphone-setup_finish_')) {
      await interaction.deferUpdate();

      const lang = interaction.customId.split('_').pop();
      const temp = await phoneDB.getTempSetup(interaction.user.id);
      if (!temp) return interaction.editReply({ content: 'Error restarting configuration.' });

      const [chars] = await pool.query(
        `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
        [interaction.user.id]
      );
      const char = chars[0];

      const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');
      if (!usedItem) {
        return interaction.editReply({
          components: [Pages.noPhone(lang)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      const phoneSerial = usedItem.item_serial;

      await phoneDB.finalizeSetup(phoneSerial, {
        language: temp.lang,
        passcode: temp.passcode,
      });

      await touchPhone(phoneSerial);
      await phoneDB.clearTempSetup(interaction.user.id);

      return interaction.editReply({
        components: [Pages.hello(temp.lang, `${char.firstname} ${char.lastname}`)],
        flags: MessageFlags.IsComponentsV2,
      });
    }

    if (interaction.isButton() && interaction.customId.startsWith('playerphone-unlock_modal_')) {
      const parts  = interaction.customId.split('_');
      const lang   = parts.pop();
      const serial = parts.slice(2).join('_');

      const modal = new ModalBuilder()
        .setCustomId(`playerphone-unlock_submit_${serial}_${lang}`)
        .setTitle(lang === 'ar' ? 'رمز حماية الهاتف' : 'Phone Passcode')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('unlock_input')
              .setLabel(lang === 'ar' ? 'أدخل رمز الدخول' : 'Enter Passcode')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
          )
        );

      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('playerphone-unlock_submit_')) {
      await interaction.deferUpdate();

      const rest    = interaction.customId.replace('playerphone-unlock_submit_', '');
      const lastIdx = rest.lastIndexOf('_');
      const serial  = rest.substring(0, lastIdx);
      const lang    = rest.substring(lastIdx + 1);

      const inputPasscode = interaction.fields.getTextInputValue('unlock_input').trim();
      const phoneData     = await phoneDB.getPhone(serial);

      if (!phoneData || phoneData.passcode !== inputPasscode) {
        return interaction.editReply({
          components: [Pages.wrongPasscode(lang, serial)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      await touchPhone(serial);

      const [ownerChar] = await pool.query(
        `SELECT firstname, lastname FROM characters WHERE national_id = ?`,
        [phoneData.owner_national_id]
      );

      const name = ownerChar[0] ? `${ownerChar[0].firstname} ${ownerChar[0].lastname}` : 'User';

      return interaction.editReply({
        components: [Pages.hello(lang, name)],
        flags: MessageFlags.IsComponentsV2,
      });
    }
  },
};

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function tr(lang = 'en') {
  return T[lang] || T.en;
}

function sep(size = SeparatorSpacingSize.Small) {
  return new SeparatorBuilder().setDivider(true).setSpacing(size);
}

async function getCharPhoneCount(userId, charNumber) {
  const [rows] = await pool.query(
    `SELECT COUNT(*) AS cnt FROM phone_data WHERE owner_user_id = ? AND char_number = ?`,
    [userId, charNumber]
  );
  return rows[0]?.cnt || 0;
}


async function purgeInactivePhones() {
  try {
    const [result] = await pool.query(`
      DELETE FROM phone_data
      WHERE COALESCE(last_used_at, created_at) < DATE_SUB(NOW(), INTERVAL 3 MONTH)
    `);
    if (result.affectedRows > 0) {
      console.log(`[phoneSetup] Purged ${result.affectedRows} inactive phone(s) older than 3 months`);
    }
  } catch (err) {
    console.error('[phoneSetup] purgeInactivePhones error:', err);
  }
}

async function touchPhone(serial) {
  try {
    await pool.query(
      `UPDATE phone_data SET last_used_at = NOW() WHERE serial = ?`,
      [serial]
    );
  } catch (err) {
    console.error('[phoneSetup] touchPhone error:', err);
  }
}