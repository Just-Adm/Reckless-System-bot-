const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder,
  TextInputBuilder, TextInputStyle, MessageFlags,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder
} = require('discord.js');

const { pool }        = require('../../utils/database/mysql');
const { getUsedItem } = require('../../utils/database/inventory_mysql');
const phoneDB         = require('../../utils/database/phone_mysql');

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function sep(size = SeparatorSpacingSize.Small) {
  return new SeparatorBuilder().setDivider(true).setSpacing(size);
}

function tr(lang = 'en') {
  return T[lang] || T.en;
}

async function resolveContext(interaction) {
  // شخصية
  const [chars] = await pool.query(
    `SELECT * FROM characters WHERE user_id = ?`,
    [interaction.user.id]
  );
  if (!chars.length) return { error: 'NO_CHAR' };

  const char = chars.find(c => c.status === 'ONLINE');
  if (!char) return { error: 'NO_ONLINE' };

  // هاتف used=true في الحقيبة
  const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');
  if (!usedItem) return { error: 'NO_PHONE' };

  // بيانات الهاتف
  const phoneData = await phoneDB.getPhone(usedItem.item_serial);
  if (!phoneData) return { error: 'NO_PHONE' };

  // التحقق أن المستخدم هو المالك
  if (phoneData.owner_national_id !== char.national_id) return { error: 'NOT_OWNER' };

  return { char, usedItem, phoneData, lang: phoneData.language || 'en' };
}

// ─────────────────────────────────────────────
// PAGES
// ─────────────────────────────────────────────
function buildSettingsMenu(lang) {
  const t = tr(lang);

  const menu = new StringSelectMenuBuilder()
    .setCustomId(`phonesettings-menu_${lang}`)
    .setPlaceholder(t.chooseSetting)
    .addOptions([
      new StringSelectMenuOptionBuilder()
        .setLabel(t.changePasscode)
        .setEmoji('<:password:1505184087315320862>')
        .setValue('change_passcode'),
      new StringSelectMenuOptionBuilder()
        .setLabel(t.changeFaceId)
        .setEmoji('<:faceid:1505185150324179016>')
        .setValue('change_faceid'),
      new StringSelectMenuOptionBuilder()
        .setLabel(t.changeLanguage)
        .setEmoji('🌐')
        .setValue('change_language'),
      new StringSelectMenuOptionBuilder()
        .setLabel(t.factoryReset)
        .setEmoji('⚠️')
        .setValue('factory_reset'),
    ]);

  return new ContainerBuilder()
    .setAccentColor(0x2c2c2e)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# <:applesettings:1505186208945406022> | ${t.settingsTitle}`)
    )
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${t.settingsSub}`)
    )
    .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(menu)
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('playerphone-app_back_home')
          .setLabel(t.back)
          .setStyle(ButtonStyle.Secondary)
      )
    );
}

function buildLanguagePage(lang) {
  const t = tr(lang);

  return new ContainerBuilder()
    .setAccentColor(0x2c2c2e)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# 🌐 | ${t.changeLanguage}`)
    )
    .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('phonesettings-setlang_en')
          .setLabel('English 🇺🇸')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('phonesettings-setlang_ar')
          .setLabel('العربية 🇸🇦')
          .setStyle(ButtonStyle.Secondary)
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('playerphone-app_settings')
          .setLabel(t.back)
          .setStyle(ButtonStyle.Secondary)
      )
    );
}

function buildFactoryConfirmPage(lang) {
  const t = tr(lang);

  return new ContainerBuilder()
    .setAccentColor(0xff3b30)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# ⚠️ | ${t.factoryReset}`)
    )
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(t.factoryWarning)
    )
    .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('phonesettings-factory_confirm')
          .setLabel(t.confirmReset)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('playerphone-app_settings')
          .setLabel(t.cancel)
          .setStyle(ButtonStyle.Secondary)
      )
    );
}

// ─────────────────────────────────────────────
// MAIN EVENT
// ─────────────────────────────────────────────
module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction) {

    // ───── Settings Button ─────
    if (interaction.isButton() && interaction.customId === 'playerphone-app_settings') {
      await interaction.deferUpdate();

      const ctx = await resolveContext(interaction);
      if (ctx.error) return sendError(interaction, ctx.error);

      return interaction.editReply({
        components: [buildSettingsMenu(ctx.lang)],
        flags: MessageFlags.IsComponentsV2,
      });
    }

    // ───── Settings Menu Select ─────
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('phonesettings-menu_')) {
      const lang   = interaction.customId.replace('phonesettings-menu_', '');
      const choice = interaction.values[0];
      const t      = tr(lang);

      // ── Change Passcode ──
      if (choice === 'change_passcode') {
        const modal = new ModalBuilder()
          .setCustomId(`phonesettings-passcode_modal_${lang}`)
          .setTitle(t.changePasscode)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('new_passcode')
                .setLabel(lang === 'ar' ? 'الباسكود الجديد (4–8 أرقام)' : 'New Passcode (4–8 digits)')
                .setStyle(TextInputStyle.Short)
                .setMinLength(4)
                .setMaxLength(8)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      // ── Change Face ID (تأكيد فقط) ──
      if (choice === 'change_faceid') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        return interaction.editReply({
          components: [
            new ContainerBuilder()
              .setAccentColor(0x2c2c2e)
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# <:faceid:1505185150324179016> | ${t.changeFaceId}`)
              )
              .addSeparatorComponents(sep())
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(t.faceIdUpdated)
              )
              .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
              .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                  new ButtonBuilder()
                    .setCustomId('playerphone-app_settings')
                    .setLabel(t.back)
                    .setStyle(ButtonStyle.Secondary)
                )
              )
          ],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ── Change Language ──
      if (choice === 'change_language') {
        await interaction.deferUpdate();
        return interaction.editReply({
          components: [buildLanguagePage(lang)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ── Factory Reset ──
      if (choice === 'factory_reset') {
        await interaction.deferUpdate();
        return interaction.editReply({
          components: [buildFactoryConfirmPage(lang)],
          flags: MessageFlags.IsComponentsV2,
        });
      }
    }

    // ───── Passcode Modal Submit ─────
    if (interaction.isModalSubmit() && interaction.customId.startsWith('phonesettings-passcode_modal_')) {
      await interaction.deferUpdate();

      const lang       = interaction.customId.replace('phonesettings-passcode_modal_', '');
      const t          = tr(lang);
      const newPasscode = interaction.fields.getTextInputValue('new_passcode').trim();

      if (!/^\d+$/.test(newPasscode)) {
        return interaction.editReply({
          content: lang === 'ar' ? '❌ يجب أن يحتوي الباسكود على أرقام فقط.' : '❌ Passcode must contain digits only.',
        });
      }

      const ctx = await resolveContext(interaction);
      if (ctx.error) return sendError(interaction, ctx.error);

      await pool.query(
        `UPDATE phone_data SET passcode = ? WHERE serial = ?`,
        [newPasscode, ctx.phoneData.serial]
      );

      return interaction.editReply({
        components: [
          new ContainerBuilder()
            .setAccentColor(0x30d158)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`# <:password:1505184087315320862> | ${t.changePasscode}`)
            )
            .addSeparatorComponents(sep())
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(t.passcodeUpdated)
            )
            .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
            .addActionRowComponents(
              new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                  .setCustomId('playerphone-app_settings')
                  .setLabel(t.back)
                  .setStyle(ButtonStyle.Secondary)
              )
            )
        ],
        flags: MessageFlags.IsComponentsV2,
      });
    }

    // ───── Set Language ─────
    if (interaction.isButton() && interaction.customId.startsWith('phonesettings-setlang_')) {
      await interaction.deferUpdate();

      const newLang = interaction.customId.replace('phonesettings-setlang_', '');
      const t       = tr(newLang);

      const ctx = await resolveContext(interaction);
      if (ctx.error) return sendError(interaction, ctx.error);

      await pool.query(
        `UPDATE phone_data SET language = ? WHERE serial = ?`,
        [newLang, ctx.phoneData.serial]
      );

      return interaction.editReply({
        components: [
          new ContainerBuilder()
            .setAccentColor(0x30d158)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`# 🌐 | ${t.changeLanguage}`)
            )
            .addSeparatorComponents(sep())
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(t.languageUpdated)
            )
            .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
            .addActionRowComponents(
              new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                  .setCustomId('playerphone-app_settings')
                  .setLabel(t.back)
                  .setStyle(ButtonStyle.Secondary)
              )
            )
        ],
        flags: MessageFlags.IsComponentsV2,
      });
    }

    // ───── Factory Reset Confirm ─────
    if (interaction.isButton() && interaction.customId === 'phonesettings-factory_confirm') {
      await interaction.deferUpdate();

      const ctx = await resolveContext(interaction);
      if (ctx.error) return sendError(interaction, ctx.error);

      const t = tr(ctx.lang);

      // إعادة ضبط: نحذف سجل phone_data ونصفّر characters
      await pool.query(
        `DELETE FROM phone_data WHERE serial = ?`,
        [ctx.phoneData.serial]
      );

      await pool.query(
        `DELETE FROM phone_setup_temp WHERE user_id = ?`,
        [interaction.user.id]
      );

      await pool.query(
        `UPDATE characters SET phone_number = NULL, phone_serial = NULL
         WHERE user_id = ? AND character_number = ?`,
        [interaction.user.id, ctx.char.character_number]
      );

      return interaction.editReply({
        components: [
          new ContainerBuilder()
            .setAccentColor(0xff3b30)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(t.factoryDone)
            )
        ],
        flags: MessageFlags.IsComponentsV2,
      });
    }

  },
};

// ─────────────────────────────────────────────
// ERROR HELPER
// ─────────────────────────────────────────────
async function sendError(interaction, code) {
  const messages = {
    NO_CHAR:    `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`,
    NO_ONLINE:  `<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`,
    NO_PHONE:   `<:Warn:1497627240177991780> | لم يتم العثور على هاتف نشط`,
    NOT_OWNER:  `<:No:1497627141465178132> | هذا الهاتف ليس ملكك`,
  };

  const content = messages[code] || '❌ Error occurred';

  if (interaction.deferred || interaction.replied) {
    return interaction.editReply({ content, components: [], embeds: [] });
  }
  return interaction.reply({ content, flags: MessageFlags.Ephemeral });
}

// ─────────────────────────────────────────────
// TRANSLATIONS
// ─────────────────────────────────────────────
const T = {
  en: {
    back:           'Back',
    cancel:         'Cancel',
    settingsTitle:  'Settings',
    settingsSub:    'Manage your phone preferences',
    chooseSetting:  'Choose a setting',
    changePasscode: 'Change Passcode',
    changeFaceId:   'Change Face ID',
    changeLanguage: 'Change Language',
    factoryReset:   'Factory Reset',
    factoryWarning: '-# ⚠️ This will delete all phone data including your passcode and settings. This action cannot be undone.',
    confirmReset:   'Confirm Reset',
    passcodeUpdated:'> ✅ Passcode updated successfully.',
    faceIdUpdated:  '> ✅ Face ID has been refreshed.',
    languageUpdated:'> ✅ Language updated successfully.',
    factoryDone:    '> ✅ Factory reset complete. Your phone has been wiped.\n-# Use your phone again to set it up.',
  },
  ar: {
    back:           'رجوع',
    cancel:         'إلغاء',
    settingsTitle:  'الإعدادات',
    settingsSub:    'إدارة إعدادات هاتفك',
    chooseSetting:  'اختر إعداداً',
    changePasscode: 'تغيير الباسكود',
    changeFaceId:   'تغيير بصمة الوجه',
    changeLanguage: 'تغيير اللغة',
    factoryReset:   'إعادة ضبط المصنع',
    factoryWarning: '-# ⚠️ سيتم حذف جميع بيانات الهاتف بما فيها الباسكود والإعدادات. لا يمكن التراجع عن هذا الإجراء.',
    confirmReset:   'تأكيد إعادة الضبط',
    passcodeUpdated:'> ✅ تم تحديث الباسكود بنجاح.',
    faceIdUpdated:  '> ✅ تم تحديث بصمة الوجه.',
    languageUpdated:'> ✅ تم تحديث اللغة بنجاح.',
    factoryDone:    '> ✅ تمت إعادة ضبط المصنع. تم مسح بيانات الهاتف.\n-# استخدم هاتفك مجدداً لإعادة الإعداد.',
  },
};