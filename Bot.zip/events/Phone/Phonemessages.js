const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder,
  TextInputBuilder, TextInputStyle, MessageFlags,
  Client, GatewayIntentBits, Events, EmbedBuilder
} = require('discord.js');

const { pool }        = require('../../utils/database/mysql');
const { getUsedItem } = require('../../utils/database/inventory_mysql');
const phoneDB         = require('../../utils/database/phone_mysql');
const contactsDB      = require('../../utils/database/contacts_mysql');

// ─────────────────────────────────────────────
// TRANSLATIONS
// ─────────────────────────────────────────────
const T = {
  en: {
    msgFrom:        (name)  => `📩 Message from ${name}`,
    replyFrom:      (name)  => `📨 Reply from ${name}`,
    originalMsg:    'Your original message:',
    footer:         (phone) => `From: ${phone}`,
    replyBtn:       'Reply',
    replyUsed:      'Replied ✓',
    writeReply:     'Write your reply',
    replyLabel:     'Type your reply',
    imageLabel:     'Image URL (optional)',
    modalTitle:     (name)  => `Message to ${name}`,
    msgLabel:       'Write message',
    sent:           (phone) => `> ✅ | Message sent to **${phone}**`,
    failed:         '> ❌ | Failed to send message, check the number',
    replySent:      '✅ Reply sent',
    replyFailed:    '❌ Failed to send reply',
    alreadyReplied: '⚠️ You have already replied to this message.',
    noChar:         '❌ Character not found',
    noPhone:        '❌ No active phone found',
    noSender:       '❌ Sender not found',
    noUser:         '❌ User not found with this number',
    back:           'Back',
    error:          '❌ An error occurred',
  },
  ar: {
    msgFrom:        (name)  => `📩 رسالة من ${name}`,
    replyFrom:      (name)  => `📨 رد من ${name}`,
    originalMsg:    'رسالتك الأصلية:',
    footer:         (phone) => `من: ${phone}`,
    replyBtn:       'رد',
    replyUsed:      'تم الرد ✓',
    writeReply:     'اكتب ردك',
    replyLabel:     'اكتب ردك',
    imageLabel:     'رابط صورة (اختياري)',
    modalTitle:     (name)  => `رسالة إلى ${name}`,
    msgLabel:       'اكتب الرسالة',
    sent:           (phone) => `> ✅ | تم إرسال الرسالة إلى **${phone}**`,
    failed:         '> ❌ | تعذّر إرسال الرسالة، تأكد من الرقم',
    replySent:      '✅ تم إرسال الرد',
    replyFailed:    '❌ تعذّر إرسال الرد',
    alreadyReplied: '⚠️ لقد قمت بالرد على هذه الرسالة مسبقاً.',
    noChar:         '❌ لم يتم العثور على شخصيتك',
    noPhone:        '❌ لم يتم العثور على هاتف نشط',
    noSender:       '❌ لم يتم العثور على المرسل',
    noUser:         '❌ لم يتم العثور على مستخدم بهذا الرقم',
    back:           'رجوع',
    error:          '❌ حدث خطأ',
  },
};

function tr(lang = 'en') {
  return T[lang] || T.en;
}

// ─────────────────────────────────────────────
// REPLY TOKEN — رد مرة واحدة فقط
// ─────────────────────────────────────────────
// نخزن في الذاكرة Set من tokens نشطة.
// كل token = customId الزر (phonemsg-reply_PHONE_B64).
// عند أول ضغط → نحذف من Set ونسمح.
// عند أي ضغط بعدها → Token مش موجود → نرفض.
//
// لمّا نرسل رسالة جديدة → نضيف token للـ Set.
// الـ Set تتنظّف تلقائياً كل ساعة (tokens قديمة تُحذف).
//
// ملاحظة: هذا الأسلوب يعمل على شرط إن البوت بـ instance واحدة.
// إذا عندك multi-instance استبدل الـ Set بجدول في MySQL.
// ─────────────────────────────────────────────

// Map<replyToken, expiresAt (timestamp)>
const replyTokens = new Map();
const TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 أيام

/**
 * يسجّل token جديد (عند إرسال رسالة أو رد جديد).
 */
function registerReplyToken(token) {
  replyTokens.set(token, Date.now() + TOKEN_TTL_MS);
}

/**
 * يتحقق إذا كان Token نشطاً ثم يحذفه (استخدام مرة واحدة).
 * يرجع true إذا كان مسموحاً، false إذا انتهى أو استُخدم.
 */
function consumeReplyToken(token) {
  const expiresAt = replyTokens.get(token);
  if (!expiresAt || Date.now() > expiresAt) return false;
  replyTokens.delete(token);
  return true;
}

// تنظيف tokens المنتهية كل ساعة
setInterval(() => {
  const now = Date.now();
  for (const [token, exp] of replyTokens) {
    if (now > exp) replyTokens.delete(token);
  }
}, 60 * 60_000);

// ─────────────────────────────────────────────
// SPAM PROTECTION
// ─────────────────────────────────────────────
const WINDOW_MS = 60_000;
const MAX_MSGS  = 5;
const spamMap   = new Map();

function isSpam(userId) {
  const now   = Date.now();
  const entry = spamMap.get(userId);
  if (!entry || now > entry.resetAt) {
    spamMap.set(userId, { count: 1, resetAt: now + WINDOW_MS });
    return false;
  }
  entry.count++;
  return entry.count > MAX_MSGS;
}

function spamMessage(lang = 'en') {
  return lang === 'ar'
    ? `> ⚠️ | أنت ترسل رسائل بسرعة كبيرة، انتظر لحظة قبل المتابعة.`
    : `> ⚠️ | You're sending messages too fast. Please wait a moment.`;
}

setInterval(() => {
  const now = Date.now();
  for (const [uid, e] of spamMap) { if (now > e.resetAt) spamMap.delete(uid); }
}, 5 * 60_000);

// ─────────────────────────────────────────────
// البوت الثاني
// ─────────────────────────────────────────────
let messageBot = null;

function initMessageBot() {
  if (messageBot) return messageBot;

  messageBot = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.DirectMessages],
    partials: ['CHANNEL', 'MESSAGE'],
  });

  messageBot.on(Events.InteractionCreate, async (interaction) => {
    try {

      // ── زر "رد" في DM ──
      if (interaction.isButton() && interaction.customId.startsWith('phonemsg-reply_')) {
        const token = interaction.customId; // الـ customId نفسه هو الـ token

        const replierLang = await getReplierPhoneLang(interaction.user.id);
        const t           = tr(replierLang);

        // ── تحقق: هل سبق الرد؟ ──
        // consumeReplyToken يحذف التوكن إذا موجود ويرجع true
        // إذا false = تم الرد مسبقاً أو Token منتهي
        if (!consumeReplyToken(token)) {
          return interaction.reply({
            content: t.alreadyReplied,
            flags: MessageFlags.Ephemeral,
          });
        }

        // Token استُهلك — الآن نفتح الـ modal
        const raw         = interaction.customId.replace('phonemsg-reply_', '');
        const firstUndIdx = raw.indexOf('_');
        const senderPhone = raw.substring(0, firstUndIdx);
        const origB64     = raw.substring(firstUndIdx + 1);

        let originalText = '';
        try { originalText = Buffer.from(origB64, 'base64').toString('utf8'); } catch {}

        // نحفظ التوكن مؤقتاً في الـ modal customId حتى نعرفه عند submit
        // لكن بما إننا حذفناه، نمرر الـ senderPhone و origB64 فقط
        const modal = new ModalBuilder()
          .setCustomId(`phonemsg-reply_modal_${senderPhone}_${origB64}`)
          .setTitle(t.writeReply)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('reply_text')
                .setLabel(t.replyLabel)
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('image_url')
                .setLabel(t.imageLabel)
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
            )
          );

        // نعدّل الرسالة الأصلية: نجعل الزر disabled بعد الضغط
        try {
          const disabledRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(token)
              .setLabel(t.replyUsed)
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(true)
          );
          await interaction.message.edit({ components: [disabledRow] });
        } catch (editErr) {
          // قد يفشل التعديل — غير حرج، نكمل
          console.error('[messageBot] Failed to disable reply button:', editErr);
        }

        return interaction.showModal(modal);
      }

      // ── Modal submit للرد ──
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonemsg-reply_modal_')) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const replierLang = await getReplierPhoneLang(interaction.user.id);
        const t           = tr(replierLang);

        // فحص السبام
        if (isSpam(interaction.user.id)) {
          return interaction.editReply({ content: spamMessage(replierLang) });
        }

        const raw         = interaction.customId.replace('phonemsg-reply_modal_', '');
        const firstUndIdx = raw.indexOf('_');
        const senderPhone = raw.substring(0, firstUndIdx);
        const origB64     = raw.substring(firstUndIdx + 1);

        let originalText = '';
        try { originalText = Buffer.from(origB64, 'base64').toString('utf8'); } catch {}

        const replyText = interaction.fields.getTextInputValue('reply_text').trim();
        const imageUrl  = interaction.fields.getTextInputValue('image_url').trim() || null;

        // بيانات الرادّ
        const [replierRows] = await pool.query(
          `SELECT * FROM characters WHERE user_id = ? AND status = 'ONLINE'`,
          [interaction.user.id]
        );
        const replierChar = replierRows[0];
        if (!replierChar) return interaction.editReply({ content: t.noChar });

        const replierUsedPhone = await getUsedItem(interaction.user.id, replierChar.character_number, 'Phone');
        if (!replierUsedPhone) return interaction.editReply({ content: t.noPhone });

        const replierPhoneData = await phoneDB.getPhone(replierUsedPhone.item_serial);
        if (!replierPhoneData) return interaction.editReply({ content: t.noPhone });

        const replierPhoneNumber = replierPhoneData.phone_number;

        const originalSender = await contactsDB.getCharByPhone(senderPhone);
        if (!originalSender) return interaction.editReply({ content: t.noSender });

        const receiverLang = await getPhoneLangByUserId(originalSender.user_id, originalSender.character_number);

        const savedInSender = await contactsDB.findContactByPhone(
          originalSender.user_id,
          originalSender.character_number,
          replierPhoneNumber
        );
        const replierDisplay = savedInSender?.contact_name || replierPhoneNumber;

        // customId للرد المتداخل + تسجيل token جديد
        const replyB64   = Buffer.from(replyText).toString('base64').slice(0, 80);
        const newReplyId = `phonemsg-reply_${replierPhoneNumber}_${replyB64}`;
        registerReplyToken(newReplyId); // ← token جديد للرد المتداخل

        const payload = buildDMPayload({
          senderPhone:         replierPhoneNumber,
          senderDisplayName:   replierDisplay,
          messageText:         replyText,
          imageUrl,
          replyCustomId:       newReplyId,
          isForward:           true,
          forwardOriginalText: originalText,
          lang:                receiverLang,
        });

        const sent = await sendDMviaBot(originalSender.user_id, payload);

        return interaction.editReply({
          content: sent ? t.replySent : t.replyFailed,
        });
      }

    } catch (err) {
      console.error('[messageBot interaction]', err);
      if (!interaction.replied && !interaction.deferred) {
        interaction.reply({ content: '❌ Error', flags: MessageFlags.Ephemeral }).catch(() => {});
      }
    }
  });

  messageBot.once(Events.ClientReady, () => {
    console.log(`[messageBot] Ready as ${messageBot.user.tag}`);
  });

  messageBot.login(process.env.MESSAGEBOT).catch(err => {
    console.error('[messageBot] Login failed:', err);
  });

  return messageBot;
}

initMessageBot();

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function sep(size = SeparatorSpacingSize.Small) {
  return new SeparatorBuilder().setDivider(true).setSpacing(size);
}

async function resolveContext(interaction) {
  const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
  if (!chars.length) return { error: 'NO_CHAR' };

  const char = chars.find(c => c.status === 'ONLINE');
  if (!char) return { error: 'NO_ONLINE' };

  const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');
  if (!usedItem) return { error: 'NO_PHONE' };

  const phoneData = await phoneDB.getPhone(usedItem.item_serial);
  if (!phoneData || !phoneData.setup_done) return { error: 'NO_PHONE' };

  return { char, usedItem, phoneData };
}

async function sendError(interaction, code, lang = 'en') {
  const t = tr(lang);
  const messages = {
    NO_CHAR:   `<:No:1497627141465178132> | ${lang === 'ar' ? 'يجب عليك إنشاء شخصية أولا' : 'You need to create a character first'}`,
    NO_ONLINE: `<:Warn:1497627240177991780> | ${lang === 'ar' ? 'قم بإختيار شخصية أولا' : 'Please select a character first'}`,
    NO_PHONE:  `<:Warn:1497627240177991780> | ${t.noPhone}`,
  };
  const content = messages[code] || t.error;
  if (interaction.deferred || interaction.replied) return interaction.editReply({ content, components: [], embeds: [] });
  return interaction.reply({ content, flags: MessageFlags.Ephemeral });
}

async function getReplierPhoneLang(userId) {
  try {
    const [chars] = await pool.query(
      `SELECT character_number FROM characters WHERE user_id = ? AND status = 'ONLINE' LIMIT 1`,
      [userId]
    );
    if (!chars.length) return 'en';
    return await getPhoneLangByUserId(userId, chars[0].character_number);
  } catch { return 'en'; }
}

async function getPhoneLangByUserId(userId, charNumber) {
  try {
    const [items] = await pool.query(
      `SELECT item_serial FROM inventory WHERE user_id = ? AND character_number = ? AND item_type = 'Phone' AND used = 1 LIMIT 1`,
      [userId, charNumber]
    );
    if (!items.length) return 'en';
    const phoneData = await phoneDB.getPhone(items[0].item_serial);
    return phoneData?.language || 'en';
  } catch { return 'en'; }
}

async function sendDMviaBot(targetUserId, payload) {
  if (!messageBot) return false;
  try {
    const user = await messageBot.users.fetch(targetUserId);
    await user.send(payload);
    return true;
  } catch (err) {
    console.error('[messageBot] Failed to send DM:', err);
    return false;
  }
}

// ── بناء رسالة DM بلغة المستقبل ───────────────────────────────────────────
function buildDMPayload({ senderPhone, senderDisplayName, messageText, imageUrl, replyCustomId, isForward, forwardOriginalText, lang = 'en' }) {
  const t = tr(lang);

  const embed = new EmbedBuilder()
    .setColor(0x2c2c2e)
    .setTitle(isForward ? t.replyFrom(senderDisplayName) : t.msgFrom(senderDisplayName));

  let desc = '';
  if (isForward && forwardOriginalText) {
    desc += `**${t.originalMsg}**\n> ${forwardOriginalText}\n\n`;
  }
  desc += messageText;
  embed.setDescription(desc);

  if (imageUrl) embed.setImage(imageUrl);
  embed.setFooter({ text: t.footer(senderPhone) });
  embed.setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(replyCustomId)
      .setLabel(t.replyBtn)
      .setEmoji('💬')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

// ─────────────────────────────────────────────
// MAIN EVENT (البوت الأساسي)
// ─────────────────────────────────────────────
module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {
    try {

      // ───── زر مراسلة من صفحة جهة اتصال ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonecontacts-msg_')) {
        const contactId = parseInt(interaction.customId.replace('phonecontacts-msg_', ''));
        const contact   = await contactsDB.getContactById(contactId);
        if (!contact) return interaction.reply({ content: '❌ Contact not found', flags: MessageFlags.Ephemeral });

        const ctx  = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData?.language || 'en');
        const t    = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId(`phonemsg-send_${contact.contact_phone}`)
          .setTitle(t.modalTitle(contact.contact_name || contact.contact_phone))
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('message_text')
                .setLabel(t.msgLabel)
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('image_url')
                .setLabel(t.imageLabel)
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
            )
          );

        return interaction.showModal(modal);
      }

      // ───── إرسال رسالة Modal Submit ─────
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonemsg-send_')) {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const senderLang = ctx.phoneData.language || 'en';
        const t          = tr(senderLang);

        if (isSpam(interaction.user.id)) {
          return interaction.editReply({ content: spamMessage(senderLang), components: [], embeds: [] });
        }

        const targetPhone = interaction.customId.replace('phonemsg-send_', '');
        const msgText     = interaction.fields.getTextInputValue('message_text').trim();
        const imageUrl    = interaction.fields.getTextInputValue('image_url').trim() || null;

        const targetChar = await contactsDB.getCharByPhone(targetPhone);
        if (!targetChar) {
          return interaction.editReply({ content: t.noUser, components: [], embeds: [] });
        }

        const receiverLang = await getPhoneLangByUserId(targetChar.user_id, targetChar.character_number);

        const savedContact = await contactsDB.findContactByPhone(
          targetChar.user_id,
          targetChar.character_number,
          ctx.phoneData.phone_number
        );
        const senderDisplay = savedContact?.contact_name || ctx.phoneData.phone_number;

        // إنشاء token للرد وتسجيله
        const origB64 = Buffer.from(msgText).toString('base64').slice(0, 80);
        const replyId = `phonemsg-reply_${ctx.phoneData.phone_number}_${origB64}`;
        registerReplyToken(replyId); // ← يُسجَّل هنا أول مرة

        const payload = buildDMPayload({
          senderPhone:       ctx.phoneData.phone_number,
          senderDisplayName: senderDisplay,
          messageText:       msgText,
          imageUrl,
          replyCustomId:     replyId,
          lang:              receiverLang,
        });

        const sent = await sendDMviaBot(targetChar.user_id, payload);

        return interaction.editReply({
          components: [
            new ContainerBuilder()
              .setAccentColor(sent ? 0x30d158 : 0xff3b30)
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(sent ? t.sent(targetPhone) : t.failed)
              )
              .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                  new ButtonBuilder()
                    .setCustomId('playerphone-app_contacts')
                    .setLabel(t.back)
                    .setStyle(ButtonStyle.Secondary)
                )
              )
          ],
          flags: MessageFlags.IsComponentsV2,
        });
      }

    } catch (err) {
      console.error('[phoneMessages]', err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Error occurred', flags: MessageFlags.Ephemeral });
      }
    }
  },
};