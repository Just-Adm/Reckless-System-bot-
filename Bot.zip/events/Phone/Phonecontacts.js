const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder,
  TextInputBuilder, TextInputStyle, MessageFlags,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  MediaGalleryBuilder, MediaGalleryItemBuilder
} = require('discord.js');

const { pool }        = require('../../utils/database/mysql');
const { getUsedItem } = require('../../utils/database/inventory_mysql');
const phoneDB         = require('../../utils/database/phone_mysql');
const contactsDB      = require('../../utils/database/contacts_mysql');
const { generateShareCode, redeemShareCode } = require('../../utils/database/contacts_mysql');
const { DateTime }    = require('luxon');

// ── Log channels لكل جهة اتصال افتراضية ──────────────────────────────────────
const EMERGENCY_CHANNELS = {
  police: '1498054239174398108',
  ems:    '1498054239174398108',
  taxi:   '1498054239174398108',
};

const CONTACTS_PER_MENU = 8;

// ─────────────────────────────────────────────
// TRANSLATIONS
// ─────────────────────────────────────────────
const T = {
  en: {
    title: '# <:Contacts:1497627035097370794> | Contacts',
    defaultContacts: 'Default Contacts',
    myContacts: 'My Contacts',
    myContactsPage: 'Contacts (%d)',
    addContact: 'Add Contact',
    scanCode: 'Scan Code',
    myInfo: 'My Info',
    back: 'Back',
    message: 'Message',
    edit: 'Edit',
    delete: 'Delete',
    share: 'Share',
    cancel: 'Cancel',
    addedOn: 'Added: %s',
    myInfoTitle: '# ℹ️ | My Info',
    name: 'Name',
    phone: 'Phone',
    nationalId: 'National ID',
    shareMyInfo: 'Share',
    shareContactTitle: '# 🔗 | Share Contact',
    shareMyInfoTitle: '# 🔗 | Share My Number',
    shareCode: '> Share Code:\n# %s\n-# Valid for 10 minutes only',
    scanTitle: 'Scan Share Code',
    scanLabel: 'Enter share code (4 digits)',
    scanInvalid: '> ❌ | Invalid or expired code',
    scanResult: '# 📞 | Phone Number',
    addNumber: 'Add Number',
    addContactTitle: 'Add Contact',
    nameLabel: 'Name (optional)',
    phoneLabel: 'Phone Number',
    editContactTitle: 'Edit Contact',
    contactNotFound: '❌ Contact not found',
    police: 'Police',
    ems: 'EMS',
    taxi: 'Taxi',
    doj: 'DOJ — Unavailable',
    dojMsg: '> ⚖️ | DOJ service is currently unavailable',
    policeModal: '🚔 Call Police',
    emsModal: '🚑 Call EMS',
    taxiModal: '🚕 Request Taxi',
    locationLabel: 'Location',
    reportLabel: 'Report',
    detailsLabel: 'Other Details (optional)',
    noteLabel: 'Note (optional)',
    destinationLabel: 'Destination',
    notesLabel: 'Notes (optional)',
    policeSent: '🚔 Police report sent',
    emsSent: '🚑 EMS report sent',
    taxiSent: '🚕 Taxi request sent',
  },
  ar: {
    title: '# <:Contacts:1497627035097370794> | جهات الاتصال',
    defaultContacts: 'جهات الاتصال الافتراضية',
    myContacts: 'جهات اتصالك',
    myContactsPage: 'جهات اتصال (%d)',
    addContact: 'إضافة جهة اتصال',
    scanCode: 'قراءة رمز',
    myInfo: 'معلوماتي',
    back: 'رجوع',
    message: 'مراسلة',
    edit: 'تعديل',
    delete: 'حذف',
    share: 'مشاركة',
    cancel: 'إلغاء',
    addedOn: 'أضيف: %s',
    myInfoTitle: '# ℹ️ | معلوماتي',
    name: 'الاسم',
    phone: 'رقم الهاتف',
    nationalId: 'الرقم الوطني',
    shareMyInfo: 'مشاركة',
    shareContactTitle: '# 🔗 | مشاركة جهة اتصال',
    shareMyInfoTitle: '# 🔗 | مشاركة رقمي',
    shareCode: '> رمز المشاركة:\n# %s\n-# صالح لمدة 10 دقائق فقط',
    scanTitle: 'قراءة رمز المشاركة',
    scanLabel: 'أدخل رمز المشاركة (4 أرقام)',
    scanInvalid: '> ❌ | الرمز غير صحيح أو منتهي الصلاحية',
    scanResult: '# 📞 | رقم الهاتف',
    addNumber: 'إضافة رقم',
    addContactTitle: 'إضافة جهة اتصال',
    nameLabel: 'الاسم (اختياري)',
    phoneLabel: 'رقم الهاتف',
    editContactTitle: 'تعديل جهة اتصال',
    contactNotFound: '❌ جهة الاتصال غير موجودة',
    police: 'الشرطة',
    ems: 'الإسعاف',
    taxi: 'تاكسي',
    doj: 'DOJ — غير متوفر',
    dojMsg: '> ⚖️ | خدمة DOJ غير متوفرة حالياً',
    policeModal: '🚔 الاتصال بالشرطة',
    emsModal: '🚑 الاتصال بالإسعاف',
    taxiModal: '🚕 طلب تاكسي',
    locationLabel: 'الموقع',
    reportLabel: 'البلاغ',
    detailsLabel: 'تفاصيل أخرى (اختياري)',
    noteLabel: 'ملاحظة (اختياري)',
    destinationLabel: 'الوجهة',
    notesLabel: 'ملاحظات (اختياري)',
    policeSent: '🚔 تم إرسال البلاغ للشرطة',
    emsSent: '🚑 تم إرسال البلاغ للإسعاف',
    taxiSent: '🚕 تم إرسال طلب التاكسي',
  },
};

function tr(lang = 'en') {
  return T[lang] || T.en;
}

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function sep(size = SeparatorSpacingSize.Small) {
  return new SeparatorBuilder().setDivider(true).setSpacing(size);
}

function formatDate(d) {
  return DateTime.fromJSDate(new Date(d)).setZone('Asia/Amman').toFormat('dd/MM/yyyy');
}

async function resolveContext(interaction) {
  const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
  if (!chars.length) return { error: 'NO_CHAR' };

  const char = chars.find(c => c.status === 'ONLINE');
  if (!char) return { error: 'NO_ONLINE' };

  const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');
  if (!usedItem) return { error: 'NO_PHONE' };

  const phoneData = await phoneDB.getPhone(usedItem.item_serial);
  if (!phoneData || !phoneData.setup_done) return { error: 'NO_PHONE' };

  return { char, usedItem, phoneData };
}

async function sendError(interaction, code, lang = 'en') {
  const messages = {
    NO_CHAR:   `<:No:1497627141465178132> | ${lang === 'ar' ? 'يجب عليك إنشاء شخصية أولا' : 'You need to create a character first'}`,
    NO_ONLINE: `<:Warn:1497627240177991780> | ${lang === 'ar' ? 'قم بإختيار شخصية أولا' : 'Please select a character first'}`,
    NO_PHONE:  `<:Warn:1497627240177991780> | ${lang === 'ar' ? 'لم يتم العثور على هاتف نشط' : 'No active phone found'}`,
  };
  const content = messages[code] || '❌ Error occurred';
  if (interaction.deferred || interaction.replied) return interaction.editReply({ content, components: [], embeds: [] });
  return interaction.reply({ content, flags: MessageFlags.Ephemeral });
}

// ─────────────────────────────────────────────
// BUILD CONTACTS PAGE
// ─────────────────────────────────────────────
async function buildContactsPage(interaction, ctx) {
  const lang     = ctx.phoneData.language || 'en';
  const t        = tr(lang);
  const contacts = await contactsDB.getContacts(interaction.user.id, ctx.char.character_number);

  const container = new ContainerBuilder()
    .setAccentColor(0x2c2c2e)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(t.title)
    )
    .addSeparatorComponents(sep());

  const rows = [];

  // ── مينيو افتراضيات ──
  rows.push(
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('phonecontacts-default')
        .setPlaceholder(t.defaultContacts)
        .addOptions([
          new StringSelectMenuOptionBuilder().setLabel(t.police).setEmoji('🚔').setValue('police'),
          new StringSelectMenuOptionBuilder().setLabel(t.ems).setEmoji('🚑').setValue('ems'),
          new StringSelectMenuOptionBuilder().setLabel(t.taxi).setEmoji('🚕').setValue('taxi'),
          new StringSelectMenuOptionBuilder().setLabel(t.doj).setEmoji('⚖️').setValue('doj').setDefault(false),
        ])
    )
  );

  // ── مينيو جهات شخصية (8 لكل مينيو) ──
  if (contacts.length > 0) {
    const chunks = [];
    for (let i = 0; i < contacts.length; i += CONTACTS_PER_MENU) {
      chunks.push(contacts.slice(i, i + CONTACTS_PER_MENU));
    }

    for (let ci = 0; ci < Math.min(chunks.length, 3); ci++) {
      const chunk = chunks[ci];
      rows.push(
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`phonecontacts-personal_${ci}`)
            .setPlaceholder(ci === 0 ? t.myContacts : t.myContactsPage.replace('%d', ci + 1))
            .addOptions(
              chunk.map(c =>
                new StringSelectMenuOptionBuilder()
                  .setLabel(c.contact_name || c.contact_phone)
                  .setDescription(c.contact_name ? c.contact_phone : formatDate(c.added_at))
                  .setValue(String(c.id))
              )
            )
        )
      );
    }
  }

  // ── أزرار ──
  rows.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('phonecontacts-add')
        .setLabel(t.addContact)
        .setEmoji('➕')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('phonecontacts-scan')
        .setLabel(t.scanCode)
        .setEmoji('🔢')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('phonecontacts-myinfo')
        .setLabel(t.myInfo)
        .setEmoji('ℹ️')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('playerphone-app_back_home')
        .setLabel(t.back)
        .setStyle(ButtonStyle.Secondary),
    )
  );

  for (const row of rows) container.addActionRowComponents(row);

  return container;
}

// ─────────────────────────────────────────────
// MAIN EVENT
// ─────────────────────────────────────────────
module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {
    try {

      // ───── فتح تطبيق جهات الاتصال ─────
      if (interaction.isButton() && interaction.customId === 'playerphone-app_contacts') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const page = await buildContactsPage(interaction, ctx);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── اختيار جهة افتراضية ─────
      if (interaction.isStringSelectMenu() && interaction.customId === 'phonecontacts-default') {
        const type = interaction.values[0];

        const ctx  = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData.language || 'en');
        const t    = tr(lang);

        if (type === 'doj') {
          await interaction.deferUpdate();
          return interaction.editReply({
            components: [
              new ContainerBuilder()
                .setAccentColor(0xff3b30)
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent(t.dojMsg)
                )
                .addActionRowComponents(
                  new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('playerphone-app_contacts').setLabel(t.back).setStyle(ButtonStyle.Secondary)
                  )
                )
            ],
            flags: MessageFlags.IsComponentsV2,
          });
        }

        // Police modal
        if (type === 'police') {
          const modal = new ModalBuilder()
            .setCustomId(`phonecontacts-emergency_police_${lang}`)
            .setTitle(t.policeModal)
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('location')
                  .setLabel(t.locationLabel)
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('report')
                  .setLabel(t.reportLabel)
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('details')
                  .setLabel(t.detailsLabel)
                  .setStyle(TextInputStyle.Paragraph)
                  .setRequired(false)
              )
            );
          return interaction.showModal(modal);
        }

        // EMS modal
        if (type === 'ems') {
          const modal = new ModalBuilder()
            .setCustomId(`phonecontacts-emergency_ems_${lang}`)
            .setTitle(t.emsModal)
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('location')
                  .setLabel(t.locationLabel)
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('note')
                  .setLabel(t.noteLabel)
                  .setStyle(TextInputStyle.Paragraph)
                  .setRequired(false)
              )
            );
          return interaction.showModal(modal);
        }

        // Taxi modal
        if (type === 'taxi') {
          const modal = new ModalBuilder()
            .setCustomId(`phonecontacts-emergency_taxi_${lang}`)
            .setTitle(t.taxiModal)
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('location')
                  .setLabel(t.locationLabel)
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('destination')
                  .setLabel(t.destinationLabel)
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('notes')
                  .setLabel(t.notesLabel)
                  .setStyle(TextInputStyle.Paragraph)
                  .setRequired(false)
              )
            );
          return interaction.showModal(modal);
        }
      }

      // ───── Police Modal Submit ─────
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonecontacts-emergency_police_')) {
        await interaction.deferUpdate();

        const lang = interaction.customId.split('_').pop();
        const t    = tr(lang);

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error, lang);

        const location = interaction.fields.getTextInputValue('location');
        const report   = interaction.fields.getTextInputValue('report');
        const details  = interaction.fields.getTextInputValue('details') || null;

        const logChannel = client.channels.cache.get(EMERGENCY_CHANNELS.police);
        if (logChannel) {
          const embed = buildEmergencyEmbed({
            type: '🚔 Police Report',
            color: 0x0a84ff,
            char: ctx.char,
            phone: ctx.phoneData.phone_number,
            fields: [
              { name: '📍 Location', value: location },
              { name: '📋 Report', value: report },
              ...(details ? [{ name: '📝 Details', value: details }] : []),
            ],
          });
          await logChannel.send({ embeds: [embed] });
        }

        return interaction.editReply({
          components: [buildCallSentPage(t.policeSent, t.back)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ───── EMS Modal Submit ─────
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonecontacts-emergency_ems_')) {
        await interaction.deferUpdate();

        const lang = interaction.customId.split('_').pop();
        const t    = tr(lang);

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error, lang);

        const location = interaction.fields.getTextInputValue('location');
        const note     = interaction.fields.getTextInputValue('note') || null;

        const logChannel = client.channels.cache.get(EMERGENCY_CHANNELS.ems);
        if (logChannel) {
          const embed = buildEmergencyEmbed({
            type: '🚑 EMS Report',
            color: 0x30d158,
            char: ctx.char,
            phone: ctx.phoneData.phone_number,
            fields: [
              { name: '📍 Location', value: location },
              ...(note ? [{ name: '📝 Note', value: note }] : []),
            ],
          });
          await logChannel.send({ embeds: [embed] });
        }

        return interaction.editReply({
          components: [buildCallSentPage(t.emsSent, t.back)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ───── Taxi Modal Submit ─────
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonecontacts-emergency_taxi_')) {
        await interaction.deferUpdate();

        const lang = interaction.customId.split('_').pop();
        const t    = tr(lang);

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error, lang);

        const location    = interaction.fields.getTextInputValue('location');
        const destination = interaction.fields.getTextInputValue('destination');
        const notes       = interaction.fields.getTextInputValue('notes') || null;

        const logChannel = client.channels.cache.get(EMERGENCY_CHANNELS.taxi);
        if (logChannel) {
          const embed = buildEmergencyEmbed({
            type: '🚕 Taxi Request',
            color: 0xffd60a,
            char: ctx.char,
            phone: ctx.phoneData.phone_number,
            fields: [
              { name: '📍 Location', value: location },
              { name: '🏁 Destination', value: destination },
              ...(notes ? [{ name: '📝 Notes', value: notes }] : []),
            ],
          });
          await logChannel.send({ embeds: [embed] });
        }

        return interaction.editReply({
          components: [buildCallSentPage(t.taxiSent, t.back)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ───── اختيار جهة شخصية ─────
      if (interaction.isStringSelectMenu() && interaction.customId.startsWith('phonecontacts-personal_')) {
        await interaction.deferUpdate();

        const ctx  = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData?.language || 'en');
        const t    = tr(lang);

        const contactId = parseInt(interaction.values[0]);
        const contact   = await contactsDB.getContactById(contactId);

        if (!contact) {
          return interaction.editReply({ content: t.contactNotFound, components: [] });
        }

        const hasName   = !!contact.contact_name;
        const titleText = hasName ? contact.contact_name : contact.contact_phone;
        const subText   = hasName ? contact.contact_phone : null;

        const container = new ContainerBuilder()
          .setAccentColor(0x2c2c2e)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ${titleText}`)
          );

        if (subText) {
          container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> 📞 ${subText}`)
          );
        }

        container
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`-# ${t.addedOn.replace('%s', formatDate(contact.added_at))}`)
          )
          .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId(`phonecontacts-msg_${contactId}`)
                .setLabel(t.message)
                .setEmoji('<:messages:1505199591241420920>')
                .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
                .setCustomId(`phonecontacts-edit_${contactId}`)
                .setLabel(t.edit)
                .setEmoji('✏️')
                .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
                .setCustomId(`phonecontacts-delete_${contactId}`)
                .setLabel(t.delete)
                .setEmoji('🗑️')
                .setStyle(ButtonStyle.Danger),
            )
          )
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId(`phonecontacts-share_${contactId}`)
                .setLabel(t.share)
                .setEmoji('🔗')
                .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
                .setCustomId('playerphone-app_contacts')
                .setLabel(t.back)
                .setStyle(ButtonStyle.Secondary),
            )
          );

        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── إضافة جهة اتصال ─────
      if (interaction.isButton() && interaction.customId === 'phonecontacts-add') {
        const ctx  = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData?.language || 'en');
        const t    = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId('phonecontacts-add_modal')
          .setTitle(t.addContactTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('contact_name')
                .setLabel(t.nameLabel)
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('contact_phone')
                .setLabel(t.phoneLabel)
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      // ───── Add Contact Submit ─────
      if (interaction.isModalSubmit() && interaction.customId === 'phonecontacts-add_modal') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const name  = interaction.fields.getTextInputValue('contact_name').trim() || null;
        const phone = interaction.fields.getTextInputValue('contact_phone').trim();

        await contactsDB.addContact(interaction.user.id, ctx.char.character_number, phone, name);

        const page = await buildContactsPage(interaction, ctx);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── تعديل جهة اتصال ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonecontacts-edit_')) {
        const contactId = interaction.customId.replace('phonecontacts-edit_', '');
        const contact   = await contactsDB.getContactById(parseInt(contactId));

        const ctx  = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData?.language || 'en');
        const t    = tr(lang);

        if (!contact) return interaction.reply({ content: t.contactNotFound, flags: MessageFlags.Ephemeral });

        const modal = new ModalBuilder()
          .setCustomId(`phonecontacts-edit_modal_${contactId}`)
          .setTitle(t.editContactTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('contact_name')
                .setLabel(t.nameLabel)
                .setStyle(TextInputStyle.Short)
                .setValue(contact.contact_name || '')
                .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('contact_phone')
                .setLabel(t.phoneLabel)
                .setStyle(TextInputStyle.Short)
                .setValue(contact.contact_phone)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      // ───── Edit Submit ─────
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonecontacts-edit_modal_')) {
        await interaction.deferUpdate();

        const contactId = parseInt(interaction.customId.replace('phonecontacts-edit_modal_', ''));
        const name      = interaction.fields.getTextInputValue('contact_name').trim() || null;
        const phone     = interaction.fields.getTextInputValue('contact_phone').trim();

        await contactsDB.updateContact(contactId, phone, name);

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const page = await buildContactsPage(interaction, ctx);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── حذف جهة اتصال ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonecontacts-delete_')) {
        await interaction.deferUpdate();

        const contactId = parseInt(interaction.customId.replace('phonecontacts-delete_', ''));
        await contactsDB.deleteContact(contactId);

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const page = await buildContactsPage(interaction, ctx);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── معلوماتي ─────
      if (interaction.isButton() && interaction.customId === 'phonecontacts-myinfo') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const lang = ctx.phoneData.language || 'en';
        const t    = tr(lang);

        const container = new ContainerBuilder()
          .setAccentColor(0x2c2c2e)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(t.myInfoTitle)
          )
          .addSeparatorComponents(sep())
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**${t.name}:** ${ctx.char.firstname} ${ctx.char.lastname}\n` +
              `**${t.phone}:** ${ctx.phoneData.phone_number}\n` +
              `**${t.nationalId}:** ${ctx.char.national_id}`
            )
          )
          .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId('phonecontacts-share_myinfo')
                .setLabel(t.shareMyInfo)
                .setEmoji('🔗')
                .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
                .setCustomId('playerphone-app_contacts')
                .setLabel(t.back)
                .setStyle(ButtonStyle.Secondary),
            )
          );

        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── مشاركة رقم (جهة اتصال) ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonecontacts-share_') && !interaction.customId.includes('myinfo')) {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData?.language || 'en');
        const t    = tr(lang);

        const contactId = parseInt(interaction.customId.replace('phonecontacts-share_', ''));
        const contact   = await contactsDB.getContactById(contactId);
        if (!contact) return interaction.editReply({ content: t.contactNotFound, components: [] });

        const { code } = await generateShareCode(contact.contact_phone);

        const container = new ContainerBuilder()
          .setAccentColor(0x2c2c2e)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(t.shareContactTitle)
          )
          .addSeparatorComponents(sep())
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(t.shareCode.replace('%s', code))
          )
          .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId('playerphone-app_contacts')
                .setLabel(t.back)
                .setStyle(ButtonStyle.Secondary)
            )
          );

        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── مشاركة معلوماتي ─────
      if (interaction.isButton() && interaction.customId === 'phonecontacts-share_myinfo') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const lang = ctx.phoneData.language || 'en';
        const t    = tr(lang);

        const { code } = await generateShareCode(ctx.phoneData.phone_number);

        const container = new ContainerBuilder()
          .setAccentColor(0x2c2c2e)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(t.shareMyInfoTitle)
          )
          .addSeparatorComponents(sep())
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(t.shareCode.replace('%s', code))
          )
          .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId('playerphone-app_contacts')
                .setLabel(t.back)
                .setStyle(ButtonStyle.Secondary)
            )
          );

        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── قراءة رمز ─────
      if (interaction.isButton() && interaction.customId === 'phonecontacts-scan') {
        const ctx  = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData?.language || 'en');
        const t    = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId('phonecontacts-scan_modal')
          .setTitle(t.scanTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('share_code')
                .setLabel(t.scanLabel)
                .setStyle(TextInputStyle.Short)
                .setMinLength(4)
                .setMaxLength(4)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      // ───── Scan Modal Submit ─────
      if (interaction.isModalSubmit() && interaction.customId === 'phonecontacts-scan_modal') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const lang = ctx.phoneData.language || 'en';
        const t    = tr(lang);

        const code  = interaction.fields.getTextInputValue('share_code').trim();
        const phone = await redeemShareCode(code);

        if (!phone) {
          return interaction.editReply({
            components: [
              new ContainerBuilder()
                .setAccentColor(0xff3b30)
                .addTextDisplayComponents(
                  new TextDisplayBuilder().setContent(t.scanInvalid)
                )
                .addActionRowComponents(
                  new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                      .setCustomId('playerphone-app_contacts')
                      .setLabel(t.back)
                      .setStyle(ButtonStyle.Secondary)
                  )
                )
            ],
            flags: MessageFlags.IsComponentsV2,
          });
        }

        const container = new ContainerBuilder()
          .setAccentColor(0x30d158)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(t.scanResult)
          )
          .addSeparatorComponents(sep())
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`> **${phone}**`)
          )
          .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId(`phonecontacts-scan_add_${phone}`)
                .setLabel(t.addNumber)
                .setEmoji('➕')
                .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
                .setCustomId('playerphone-app_contacts')
                .setLabel(t.cancel)
                .setStyle(ButtonStyle.Danger),
            )
          );

        return interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── إضافة رقم من الرمز ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonecontacts-scan_add_')) {
        const phone = interaction.customId.replace('phonecontacts-scan_add_', '');

        const ctx  = await resolveContext(interaction);
        const lang = ctx.error ? 'en' : (ctx.phoneData?.language || 'en');
        const t    = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId(`phonecontacts-scan_save_${phone}`)
          .setTitle(t.addContactTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('contact_name')
                .setLabel(t.nameLabel)
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
            )
          );

        return interaction.showModal(modal);
      }

      // ───── حفظ جهة الاتصال من الرمز ─────
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonecontacts-scan_save_')) {
        await interaction.deferUpdate();

        const phone = interaction.customId.replace('phonecontacts-scan_save_', '');
        const name  = interaction.fields.getTextInputValue('contact_name').trim() || null;

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        await contactsDB.addContact(interaction.user.id, ctx.char.character_number, phone, name);

        const page = await buildContactsPage(interaction, ctx);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

    } catch (err) {
      console.error('[phoneContacts]', err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Error occurred', flags: MessageFlags.Ephemeral });
      }
    }
  },
};

// ─────────────────────────────────────────────
// EMBED BUILDERS
// ─────────────────────────────────────────────
function buildEmergencyEmbed({ type, color, char, phone, fields }) {
  const { EmbedBuilder } = require('discord.js');

  return new EmbedBuilder()
    .setTitle(type)
    .setColor(color)
    .setDescription(
      `**Name:** ${char.firstname} ${char.lastname}\n` +
      `**National ID:** ${char.national_id}\n` +
      `**Phone:** ${phone}`
    )
    .addFields(fields)
    .setTimestamp();
}

function buildCallSentPage(message, backLabel = 'Back') {
  return new ContainerBuilder()
    .setAccentColor(0x30d158)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`> ✅ | ${message}`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Large))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('playerphone-app_contacts')
          .setLabel(backLabel)
          .setStyle(ButtonStyle.Secondary)
      )
    );
}