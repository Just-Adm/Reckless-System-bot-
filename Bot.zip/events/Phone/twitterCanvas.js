const { createCanvas, loadImage } = require('canvas');
const { DateTime } = require('luxon');

// ─────────────────────────────────────────────
// COLORS
// ─────────────────────────────────────────────
const THEMES = {
  dark: {
    bg:          '#000000',
    card:        '#16181c',
    border:      '#2f3336',
    text:        '#e7e9ea',
    subtext:     '#71767b',
    accent:      '#1d9bf0',
    like:        '#f91880',
    retweet:     '#00ba7c',
    avatarBg:    '#2f3336',
  },
  light: {
    bg:          '#ffffff',
    card:        '#f7f9f9',
    border:      '#cfd9de',
    text:        '#0f1419',
    subtext:     '#536471',
    accent:      '#1d9bf0',
    like:        '#f91880',
    retweet:     '#00ba7c',
    avatarBg:    '#cfd9de',
  },
};

function hex(color) { return color; }

// ─────────────────────────────────────────────
// DRAW ROUNDED RECT
// ─────────────────────────────────────────────
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

// ─────────────────────────────────────────────
// DRAW CIRCLE CLIP (avatar)
// ─────────────────────────────────────────────
function clipCircle(ctx, x, y, r) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();
}

// ─────────────────────────────────────────────
// GENERATE PROFILE IMAGE
// ─────────────────────────────────────────────
async function generateProfileImage(account, tweetsCount) {
  const theme  = THEMES[account.theme] || THEMES.dark;
  const W      = 600;
  const H      = 280;
  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext('2d');

  // Background
  ctx.fillStyle = theme.bg;
  ctx.fillRect(0, 0, W, H);

  // Header banner
  ctx.fillStyle = theme.card;
  ctx.fillRect(0, 0, W, 100);

  // Avatar circle background
  const avX = 50;
  const avY = 65;
  const avR = 45;

  ctx.fillStyle = theme.avatarBg;
  ctx.beginPath();
  ctx.arc(avX, avY, avR + 3, 0, Math.PI * 2);
  ctx.fill();

  // Avatar image
  if (account.avatar_url) {
    try {
      const img = await loadImage(account.avatar_url);
      ctx.save();
      clipCircle(ctx, avX, avY, avR);
      ctx.drawImage(img, avX - avR, avY - avR, avR * 2, avR * 2);
      ctx.restore();
    } catch {
      // fallback: letter
      ctx.save();
      clipCircle(ctx, avX, avY, avR);
      ctx.fillStyle = theme.accent;
      ctx.fillRect(avX - avR, avY - avR, avR * 2, avR * 2);
      ctx.fillStyle = '#ffffff';
      ctx.font      = 'bold 32px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(account.display_name[0].toUpperCase(), avX, avY);
      ctx.restore();
    }
  } else {
    ctx.save();
    clipCircle(ctx, avX, avY, avR);
    ctx.fillStyle = theme.accent;
    ctx.fillRect(avX - avR, avY - avR, avR * 2, avR * 2);
    ctx.fillStyle = '#ffffff';
    ctx.font      = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(account.display_name[0].toUpperCase(), avX, avY);
    ctx.restore();
  }

  // X logo (top right)
  ctx.fillStyle = theme.text;
  ctx.font      = 'bold 28px Arial';
  ctx.textAlign = 'right';
  ctx.fillText('𝕏', W - 20, 35);

  // Display name
  ctx.fillStyle    = theme.text;
  ctx.font         = 'bold 22px Arial';
  ctx.textAlign    = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillText(account.display_name, 20, 140);

  // Username
  ctx.fillStyle = theme.subtext;
  ctx.font      = '16px Arial';
  ctx.fillText(`@${account.username}`, 20, 163);

  // Bio
  if (account.bio) {
    ctx.fillStyle = theme.text;
    ctx.font      = '15px Arial';
    ctx.fillText(account.bio, 20, 190);
  }

  // Stats row
  const statsY = account.bio ? 220 : 195;

  ctx.fillStyle = theme.text;
  ctx.font      = 'bold 15px Arial';
  ctx.fillText(String(account.following ?? 0), 20, statsY);
  ctx.fillStyle = theme.subtext;
  ctx.font      = '14px Arial';
  ctx.fillText(' Following', 20 + ctx.measureText(String(account.following ?? 0)).width, statsY);

  const followingWidth = 20 + ctx.measureText(`${account.following ?? 0} Following`).width + 16;
  ctx.fillStyle = theme.text;
  ctx.font      = 'bold 15px Arial';
  ctx.fillText(String(account.followers ?? 0), followingWidth, statsY);
  ctx.fillStyle = theme.subtext;
  ctx.font      = '14px Arial';
  ctx.fillText(' Followers', followingWidth + ctx.measureText(String(account.followers ?? 0)).width, statsY);

  // Tweets count
  const tweetsX = followingWidth + ctx.measureText(`${account.followers ?? 0} Followers`).width + 16;
  ctx.fillStyle = theme.text;
  ctx.font      = 'bold 15px Arial';
  ctx.fillText(String(tweetsCount), tweetsX, statsY);
  ctx.fillStyle = theme.subtext;
  ctx.font      = '14px Arial';
  ctx.fillText(' Posts', tweetsX + ctx.measureText(String(tweetsCount)).width, statsY);

  // Bottom border
  ctx.strokeStyle = theme.border;
  ctx.lineWidth   = 1;
  ctx.beginPath();
  ctx.moveTo(0, H - 1);
  ctx.lineTo(W, H - 1);
  ctx.stroke();

  return canvas.toBuffer('image/png');
}

// ─────────────────────────────────────────────
// GENERATE TWEET IMAGE
// ─────────────────────────────────────────────
async function generateTweetImage(tweet, account) {
  const theme  = THEMES[account.theme] || THEMES.dark;
  const W      = 600;

  // تحديد الارتفاع حسب وجود صورة
  const hasImg   = !!tweet.image_url;
  const H        = hasImg ? 340 : 180;
  const canvas   = createCanvas(W, H);
  const ctx      = canvas.getContext('2d');

  // Background
  ctx.fillStyle = theme.bg;
  ctx.fillRect(0, 0, W, H);

  // Card border bottom
  ctx.strokeStyle = theme.border;
  ctx.lineWidth   = 1;
  ctx.beginPath();
  ctx.moveTo(0, H - 1);
  ctx.lineTo(W, H - 1);
  ctx.stroke();

  // Avatar
  const avR = 22;
  const avX = 36;
  const avY = 36;

  if (account.avatar_url) {
    try {
      const img = await loadImage(account.avatar_url);
      ctx.save();
      clipCircle(ctx, avX, avY, avR);
      ctx.drawImage(img, avX - avR, avY - avR, avR * 2, avR * 2);
      ctx.restore();
    } catch {
      ctx.save();
      clipCircle(ctx, avX, avY, avR);
      ctx.fillStyle = theme.accent;
      ctx.fillRect(avX - avR, avY - avR, avR * 2, avR * 2);
      ctx.fillStyle = '#ffffff';
      ctx.font      = 'bold 18px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(account.display_name[0].toUpperCase(), avX, avY);
      ctx.restore();
    }
  } else {
    ctx.save();
    clipCircle(ctx, avX, avY, avR);
    ctx.fillStyle = theme.accent;
    ctx.fillRect(avX - avR, avY - avR, avR * 2, avR * 2);
    ctx.fillStyle = '#ffffff';
    ctx.font      = 'bold 18px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(account.display_name[0].toUpperCase(), avX, avY);
    ctx.restore();
  }

  // Name + username
  ctx.fillStyle    = theme.text;
  ctx.font         = 'bold 16px Arial';
  ctx.textAlign    = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillText(account.display_name, 70, 30);

  ctx.fillStyle = theme.subtext;
  ctx.font      = '14px Arial';
  ctx.fillText(`@${account.username}`, 70, 48);

  // Date
  const dateStr = DateTime.fromJSDate(new Date(tweet.created_at))
    .setZone('Asia/Amman')
    .toFormat('dd/MM/yyyy HH:mm');
  ctx.fillStyle = theme.subtext;
  ctx.font      = '13px Arial';
  ctx.textAlign = 'right';
  ctx.fillText(dateStr, W - 16, 30);

  // Content
  if (tweet.content) {
    ctx.fillStyle    = theme.text;
    ctx.font         = '15px Arial';
    ctx.textAlign    = 'left';
    ctx.textBaseline = 'alphabetic';

    // Word wrap
    const maxW    = W - 80;
    const words   = tweet.content.split(' ');
    let line      = '';
    let lineY     = 75;

    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxW && line) {
        ctx.fillText(line, 70, lineY);
        line  = word;
        lineY += 22;
        if (lineY > 130) break;
      } else {
        line = test;
      }
    }
    if (line) ctx.fillText(line, 70, lineY);
  }

  // Tweet image (banner)
  if (hasImg) {
    try {
      const img    = await loadImage(tweet.image_url);
      const imgY   = 140;
      const imgH   = 160;
      const imgW   = W - 32;

      ctx.save();
      roundRect(ctx, 16, imgY, imgW, imgH, 12);
      ctx.clip();
      ctx.drawImage(img, 16, imgY, imgW, imgH);
      ctx.restore();
    } catch {}
  }

  // Actions row (likes / retweets)
  const actY = H - 28;

  ctx.fillStyle = theme.like;
  ctx.font      = '14px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(`❤ ${tweet.likes ?? 0}`, 70, actY);

  ctx.fillStyle = theme.retweet;
  ctx.fillText(`🔁 ${tweet.retweets ?? 0}`, 160, actY);

  return canvas.toBuffer('image/png');
}

// ─────────────────────────────────────────────
// GENERATE TWEETS PAGE (5 tweets as one image)
// ─────────────────────────────────────────────
async function generateTweetsPageImage(tweets, account) {
  const images = await Promise.all(
    tweets.map(t => generateTweetImage(t, account))
  );

  // نحسب الارتفاع الكلي
  let totalH = 0;
  const loaded = [];
  for (const buf of images) {
    const img = await loadImage(buf);
    loaded.push(img);
    totalH += img.height;
  }

  const W      = 600;
  const canvas = createCanvas(W, totalH);
  const ctx    = canvas.getContext('2d');

  let y = 0;
  for (const img of loaded) {
    ctx.drawImage(img, 0, y);
    y += img.height;
  }

  return canvas.toBuffer('image/png');
}

module.exports = {
  generateProfileImage,
  generateTweetImage,
  generateTweetsPageImage,
};