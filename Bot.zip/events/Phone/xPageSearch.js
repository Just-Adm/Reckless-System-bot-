const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, TextDisplayBuilder, ModalBuilder, LabelBuilder, TextInputBuilder, TextInputStyle, MessageFlags } = require('discord.js');
const xDB = require('../../utils/database/twitter_mysql');
const { renderMyProfilePage } = require('./xPageProfile');

async function renderSearchPage(interaction, lang) {
  const customId = interaction.customId;

  // 1. عند الضغط لفتح نافذة إدخال نص البحث (Modal)
  if (interaction.isButton() && (customId.startsWith('x-nav-search_') || customId.startsWith('x-search-trigger-input_'))) {
    const modal = new ModalBuilder()
      .setCustomId(`x-search-execute_${lang}`)
      .setTitle(lang === 'ar' ? 'البحث عن حساب شخص' : 'Search Account')
      .setLabelComponents(
        new LabelBuilder().setLabel(lang === 'ar' ? 'ادخل الاسم أو اليوزر نيم' : 'Enter Username / Display Name').setTextInputComponent(
          new TextInputBuilder().setCustomId('query').setStyle(TextInputStyle.Short).setRequired(true)
        )
      );
    return interaction.showModal(modal);
  }

  // 2. معالجة ناتج الـ Modal وعرض النتائج كأزرار
  if (interaction.isModalSubmit() && customId.startsWith('x-search-execute_')) {
    const query = interaction.fields.getTextInputValue('query').trim();
    const results = await xDB.searchAccounts(query);

    const container = new ContainerBuilder()
      .setAccentColor(0x1DA1F2)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(lang === 'ar' ? `# 🔍 نتائج البحث عن: **${query}**` : `# 🔍 Search Results for: **${query}**`));

    const row = new ActionRowBuilder();
    if (results.length === 0) {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(lang === 'ar' ? '> ❌ لم يتم العثور على أي بروفايل مطابق.' : '> ❌ No matching accounts found.'));
    } else {
      results.slice(0, 4).forEach(acc => {
        row.addComponents(
          new ButtonBuilder().setCustomId(`x-search-view_${acc.id}_${lang}`).setLabel(`👤 ${acc.display_name} (@${acc.username})`).setStyle(ButtonStyle.Secondary)
        );
      });
    }

    row.addComponents(
      new ButtonBuilder().setCustomId(`x-search-trigger-input_${lang}`).setLabel(lang === 'ar' ? 'بحث جديد 🔍' : 'New Search 🔍').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`x-back-to-hub_${lang}`).setLabel(lang === 'ar' ? 'رجوع' : 'Back').setStyle(ButtonStyle.Danger)
    );

    return interaction.editReply({
      components: [row],
      embeds: [],
      files: [],
      flags: MessageFlags.IsComponentsV2
    });
  }

  // 3. عند الضغط على زر حساب معين من نتائج البحث لعرض بروفايله
  if (interaction.isButton() && customId.startsWith('x-search-view_')) {
    const targetId = parseInt(customId.split('_')[1]);
    const targetAccount = await xDB.getAccountById(targetId);
    
    // إرساله لملف البروفايل مع تفعيل وضع المشاهدة الخارجية الآخرين لتمكينه من المتابعة
    return renderMyProfilePage(interaction, targetAccount, lang, true);
  }
}

module.exports = { renderSearchPage };