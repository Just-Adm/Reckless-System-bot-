const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder,
  TextInputBuilder, TextInputStyle, MessageFlags, Events
} = require('discord.js');

const { pool }    = require('../../utils/database/mysql');
const { getUsedItem } = require('../../utils/database/inventory_mysql');
const phoneDB     = require('../../utils/database/phone_mysql');
const notesDB     = require('../../utils/database/notes_mysql');
const { DateTime } = require('luxon');

// ─────────────────────────────────────────────
// TRANSLATIONS
// ─────────────────────────────────────────────
const T = {
  en: {
    title:          '# 📝 | Notes',
    empty:          '> You have no notes yet.\n-# Tap **Add Note** to create your first note.',
    addNote:        'Add Note',
    back:           'Back',
    prev:           '◀',
    next:           '▶',
    deleteNote:     'Delete Note',
    modalTitle:     'New Note',
    labelTitle:     'Title (optional)',
    labelContent:   'Note',
    noteTitle:      'Title',
    noteContent:    'Content',
    noteDate:       'Added',
    pageOf:         (p, t) => `Page ${p} of ${t}`,
    limitReached:   `> ❌ | You've reached the maximum of ${notesDB.MAX_NOTES} notes.`,
    deleted:        '> ✅ | Note deleted.',
    noPhone:        '❌ | No active phone found.',
    noChar:         '❌ | Create a character first.',
    noOnline:       '❌ | Select a character first.',
  },
  ar: {
    title:          '# 📝 | الملاحظات',
    empty:          '> لا توجد ملاحظات حتى الآن.\n-# اضغط **إضافة ملاحظة** لإنشاء أولى ملاحظاتك.',
    addNote:        'إضافة ملاحظة',
    back:           'رجوع',
    prev:           '◀',
    next:           '▶',
    deleteNote:     'حذف الملاحظة',
    modalTitle:     'ملاحظة جديدة',
    labelTitle:     'العنوان (اختياري)',
    labelContent:   'الملاحظة',
    noteTitle:      'العنوان',
    noteContent:    'المحتوى',
    noteDate:       'أضيفت',
    pageOf:         (p, t) => `صفحة ${p} من ${t}`,
    limitReached:   `> ❌ | وصلت للحد الأقصى وهو ${notesDB.MAX_NOTES} ملاحظات.`,
    deleted:        '> ✅ | تم حذف الملاحظة.',
    noPhone:        '❌ | لم يتم العثور على هاتف نشط.',
    noChar:         '❌ | يجب عليك إنشاء شخصية أولاً.',
    noOnline:       '❌ | قم بإختيار شخصية أولاً.',
  },
};

function tr(lang) { return T[lang] || T.en; }

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function sep(size = SeparatorSpacingSize.Small) {
  return new SeparatorBuilder().setDivider(true).setSpacing(size);
}

function formatDate(d, lang) {
  return DateTime.fromJSDate(new Date(d)).setZone('Asia/Amman').toFormat('dd/MM/yyyy HH:mm');
}

async function resolveContext(interaction) {
  const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
  if (!chars.length) return { error: 'NO_CHAR' };

  const char = chars.find(c => c.status === 'ONLINE');
  if (!char) return { error: 'NO_ONLINE' };

  const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');
  if (!usedItem) return { error: 'NO_PHONE' };

  const phoneData = await phoneDB.getPhone(usedItem.item_serial);
  if (!phoneData || !phoneData.setup_done) return { error: 'NO_PHONE' };

  const lang = phoneData.language || 'en';
  return { char, usedItem, phoneData, lang };
}

async function sendError(interaction, code, lang = 'en') {
  const t = tr(lang);
  const messages = {
    NO_CHAR:   t.noChar,
    NO_ONLINE: t.noOnline,
    NO_PHONE:  t.noPhone,
  };
  const content = messages[code] || '❌ Error occurred';
  if (interaction.deferred || interaction.replied) return interaction.editReply({ content, components: [], embeds: [] });
  return interaction.reply({ content, flags: MessageFlags.Ephemeral });
}

// ─────────────────────────────────────────────
// BUILD NOTES PAGE
// page: 0 = صفحة الترحيب/الفارغة، 1..N = ملاحظة
// ─────────────────────────────────────────────
async function buildNotesPage(userId, charNum, lang, page) {
  const t     = tr(lang);
  const notes = await notesDB.getNotes(userId, charNum);
  const total = notes.length;

  // صفحة فارغة أو ترحيب (page = 0)
  if (total === 0 || page === 0) {
    const container = new ContainerBuilder()
      .setAccentColor(0x2c2c2e)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.title))
      .addSeparatorComponents(sep())
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(
        total === 0 ? t.empty : t.pageOf(0, total)
      ))
      .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('phonenotes-prev_0')
            .setLabel(t.prev)
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
          new ButtonBuilder()
            .setCustomId('phonenotes-add')
            .setLabel(t.addNote)
            .setEmoji('➕')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('phonenotes-next_0')
            .setLabel(t.next)
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(total === 0),
          new ButtonBuilder()
            .setCustomId('playerphone-app_back_home')
            .setLabel(t.back)
            .setStyle(ButtonStyle.Secondary),
        )
      );

    return container;
  }

  // صفحة ملاحظة (page 1..N)
  const clampedPage = Math.max(1, Math.min(page, total));
  const note        = notes[clampedPage - 1];

  const titleLine   = note.title
    ? `**${note.title}**\n`
    : '';

  const container = new ContainerBuilder()
    .setAccentColor(0x2c2c2e)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(t.title))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `${titleLine}${note.content}`
    ))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `-# ${t.pageOf(clampedPage, total)} — ${formatDate(note.created_at, lang)}`
    ))
    .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`phonenotes-prev_${clampedPage}`)
          .setLabel(t.prev)
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(clampedPage <= 1),
        new ButtonBuilder()
          .setCustomId('phonenotes-add')
          .setLabel(t.addNote)
          .setEmoji('➕')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`phonenotes-next_${clampedPage}`)
          .setLabel(t.next)
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(clampedPage >= total),
        new ButtonBuilder()
          .setCustomId('playerphone-app_back_home')
          .setLabel(t.back)
          .setStyle(ButtonStyle.Secondary),
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`phonenotes-delete_${note.id}_${clampedPage}`)
          .setLabel(t.deleteNote)
          .setEmoji('🗑️')
          .setStyle(ButtonStyle.Danger),
      )
    );

  return container;
}

// ─────────────────────────────────────────────
// MAIN EVENT
// ─────────────────────────────────────────────
module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction, client) {
    try {

      // ───── فتح تطبيق الملاحظات ─────
      if (interaction.isButton() && interaction.customId === 'playerphone-app_notes') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const notes = await notesDB.getNotes(interaction.user.id, ctx.char.character_number);
        // نبدأ من آخر ملاحظة لو موجودة، وإلا صفحة 0
        const startPage = notes.length > 0 ? 1 : 0;

        const page = await buildNotesPage(interaction.user.id, ctx.char.character_number, ctx.lang, startPage);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── سابق ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonenotes-prev_')) {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const curPage = parseInt(interaction.customId.replace('phonenotes-prev_', ''));
        const newPage = Math.max(0, curPage - 1);

        const page = await buildNotesPage(interaction.user.id, ctx.char.character_number, ctx.lang, newPage);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── تالي ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonenotes-next_')) {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const curPage = parseInt(interaction.customId.replace('phonenotes-next_', ''));
        const newPage = curPage + 1;

        const page = await buildNotesPage(interaction.user.id, ctx.char.character_number, ctx.lang, newPage);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── إضافة ملاحظة — modal ─────
      if (interaction.isButton() && interaction.customId === 'phonenotes-add') {
        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const count = await notesDB.getNotesCount(interaction.user.id, ctx.char.character_number);
        if (count >= notesDB.MAX_NOTES) {
          const t = tr(ctx.lang);
          return interaction.reply({
            content: t.limitReached,
            flags: MessageFlags.Ephemeral,
          });
        }

        const t = tr(ctx.lang);

        const modal = new ModalBuilder()
          .setCustomId(`phonenotes-add_modal_${ctx.lang}`)
          .setTitle(t.modalTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('note_title')
                .setLabel(t.labelTitle)
                .setStyle(TextInputStyle.Short)
                .setMaxLength(100)
                .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('note_content')
                .setLabel(t.labelContent)
                .setStyle(TextInputStyle.Paragraph)
                .setMaxLength(1000)
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      // ───── Add Note Submit ─────
      if (interaction.isModalSubmit() && interaction.customId.startsWith('phonenotes-add_modal_')) {
        await interaction.deferUpdate();

        const lang = interaction.customId.replace('phonenotes-add_modal_', '');

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error, lang);

        const title   = interaction.fields.getTextInputValue('note_title').trim() || null;
        const content = interaction.fields.getTextInputValue('note_content').trim();

        const result = await notesDB.addNote(interaction.user.id, ctx.char.character_number, content, title);

        if (!result) {
          const t = tr(lang);
          return interaction.editReply({ content: t.limitReached, components: [] });
        }

        // نعرض الملاحظة الجديدة (الصفحة الأولى = الأحدث)
        const page = await buildNotesPage(interaction.user.id, ctx.char.character_number, lang, 1);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

      // ───── حذف ملاحظة ─────
      if (interaction.isButton() && interaction.customId.startsWith('phonenotes-delete_')) {
        await interaction.deferUpdate();

        const parts   = interaction.customId.replace('phonenotes-delete_', '').split('_');
        const noteId  = parseInt(parts[0]);
        const curPage = parseInt(parts[1]);

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        await notesDB.deleteNote(noteId, interaction.user.id, ctx.char.character_number);

        const notes    = await notesDB.getNotes(interaction.user.id, ctx.char.character_number);
        const newPage  = notes.length === 0 ? 0 : Math.min(curPage, notes.length);

        const page = await buildNotesPage(interaction.user.id, ctx.char.character_number, ctx.lang, newPage);
        return interaction.editReply({ components: [page], flags: MessageFlags.IsComponentsV2 });
      }

    } catch (err) {
      console.error('[phoneNotes]', err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Error occurred', flags: MessageFlags.Ephemeral });
      }
    }
  },
};