const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const xDB = require('../../utils/database/twitter_mysql');
const { drawTweetCard } = require('./xCanvasRenderer');

async function renderHomePage(interaction, lang, page = 0, viewerAccount) {
  const customId = interaction.customId;
  const theme = viewerAccount?.theme || 'light';

  if (customId && (customId.startsWith('x-like-post_') || customId.startsWith('x-repost-post_'))) {
    const parts = customId.split('_');
    const postId = parseInt(parts[1]);
    if (customId.startsWith('x-like-post_')) {
      await xDB.toggleLike(viewerAccount.id, postId);
    } else {
      await xDB.pool.query(`UPDATE x_posts SET reposts = reposts + 1 WHERE id = ?`, [postId]);
    }
  }

  const limit = 3; // تقليل الليميت لـ 3 لضمان سرعة تحميل ورسم الصور بالكامل
  const offset = page * limit;
  const posts = await xDB.getPosts(limit, offset);
  const total = (await xDB.getPosts(9999, 0)).length;
  const totalPages = Math.ceil(total / limit) || 1;

  const attachments = [];
  const rows = [];

  // زر علوي سريع لإنشاء تغريدة جديدة من داخل صفحة التايملاين
  const tweetActionRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`x-nav-tweet_${lang}`).setLabel(lang === 'ar' ? 'تغريدة جديدة 📝' : 'New Tweet 📝').setStyle(ButtonStyle.Primary)
  );
  rows.push(tweetActionRow);

  for (let i = 0; i < posts.length; i++) {
    const post = posts[i];
    const imageBuffer = await drawTweetCard(post, theme); 
    const fileName = `tweet_feed_${post.id}_${Date.now()}.png`;
    
    attachments.push(new AttachmentBuilder(imageBuffer, { name: fileName }));

    if (i === 0) {
      const actionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`x-like-post_${post.id}_${page}_${lang}`).setLabel(`❤️ ${post.likes || 0}`).setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`x-repost-post_${post.id}_${page}_${lang}`).setLabel(`🔁 ${post.reposts || 0}`).setStyle(ButtonStyle.Secondary)
      );
      rows.push(actionRow);
    }
  }

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`x-home-page_${page - 1}_${lang}`).setLabel(lang === 'ar' ? '◀ السابق' : '◀ Prev').setStyle(ButtonStyle.Secondary).setDisabled(page <= 0),
    new ButtonBuilder().setCustomId(`x-home-page_${page + 1}_${lang}`).setLabel(lang === 'ar' ? 'التالي ▶' : 'Next ▶').setStyle(ButtonStyle.Secondary).setDisabled(page >= totalPages - 1),
    new ButtonBuilder().setCustomId (nudge = `x-back-to-hub_${lang}`).setLabel(lang === 'ar' ? 'القائمة الرئيسية 🏠' : 'Main Hub 🏠').setStyle(ButtonStyle.Danger)
  );
  rows.push(navRow);

  return interaction.editReply({
    files: attachments,
    components: rows,
    embeds: [],
    flags: MessageFlags.IsComponentsV2
  });
}

module.exports = { renderHomePage };