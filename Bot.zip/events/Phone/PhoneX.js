const {
  Events,
  MessageFlags,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');

const { pool }        = require('../../utils/database/mysql');
const { getUsedItem } = require('../../utils/database/inventory_mysql');
const phoneDB         = require('../../utils/database/phone_mysql');
const xDB             = require('../../utils/database/twitter_mysql');
const { DateTime }    = require('luxon');

const POSTS_PER_PAGE = 3;
const sessions       = new Map(); // لحفظ الصفحة الحالية لكل مستخدم

// ─────────────────────────────────────────────
// TRANSLATIONS
// ─────────────────────────────────────────────
const T = {
  en: {
    appName:         'X',
    noAccount:       '# Welcome to X\n> Join the conversation.',
    signIn:          'Sign In',
    register:        'Register',
    back:            'Back',
    home:            'Home',
    search:          'Search',
    myProfile:       'My Profile',
    post:            'Post',
    like:            'Like',
    liked:           'Liked',
    prev:            '◀ Prev',
    next:            'Next ▶',
    signOut:         'Sign Out',
    usernameTaken:   '> ❌ | Username is already taken.',
    registerSuccess: '> ✅ | Account created successfully!',
    signInTitle:     'Sign In to X',
    registerTitle:   'Create X Account',
    labelDisplay:    'Display Name (1–8 chars)',
    labelUsername:   'Username (3–8 letters/numbers only)',
    labelBio:        'Bio (optional, max 40)',
    labelAvatar:     'Avatar URL (Optional)',
    labelSignIn:     'Your Username',
    searchTitle:     'Search X',
    labelSearch:     'Search username or display name',
    noResults:       '❌ No results found.',
    noPosts:         '📝 No posts yet.',
    invalidDisplay:  '> ❌ | Display Name must be 1–8 characters.',
    invalidUsername: '> ❌ | Username must be 3–8 letters/numbers (English only, no symbols).',
    userNotFound:    '> ❌ | Username not found.',
    newPost:         'New Post 📝',
    postLabel:       'Write your post (max 280)',
    postImage:       'Image URL (optional)',
    followers:       'Followers',
    following:       'Following',
    posts:           'Posts',
    joinedOn:        'Joined',
    signedOut:       '> ✅ | Signed out successfully.',
    alreadySignedIn: '> ⚠️ | This account is already active on another phone.',
  },
  ar: {
    appName:         'X',
    noAccount:       '# أهلاً في X\n> انضم إلى المحادثة الفورية الآن.',
    signIn:          'تسجيل الدخول',
    register:        'إنشاء حساب',
    back:            'رجوع',
    home:            'الرئيسية 🏠',
    search:          'البحث 🔍',
    myProfile:       'ملفي الشخصي 👤',
    post:            'تغريد',
    like:            'إعجاب',
    liked:           'معجب',
    prev:            '◀ السابق',
    next:            'التالي ▶',
    signOut:         'تسجيل الخروج 🚪',
    usernameTaken:   '> ❌ | اسم المستخدم مأخوذ بالفعل.',
    registerSuccess: '> ✅ | تم إنشاء الحساب بنجاح!',
    signInTitle:     'تسجيل الدخول إلى X',
    registerTitle:   'إنشاء حساب X جديد',
    labelDisplay:    'الاسم المعروض (1–8 أحرف)',
    labelUsername:   'اسم المستخدم (3–8 حروف/أرقام إنجليزية فقط)',
    labelBio:        'النبذة (اختياري، 40 حرف كحد أقصى)',
    labelAvatar:     'رابط الصورة الشخصية (اختياري)',
    labelSignIn:     'اسم المستخدم الخاص بك',
    searchTitle:     'البحث في X',
    labelSearch:     'ابحث باسم المستخدم أو الاسم المعروض',
    noResults:       '❌ لا توجد نتائج للبحث.',
    noPosts:         '📝 لا توجد تغريدات بعد في التايملاين.',
    invalidDisplay:  '> ❌ | الاسم المعروض يجب أن يكون 1–8 أحرف.',
    invalidUsername: '> ❌ | اسم المستخدم يجب أن يكون 3–8 حروف/أرقام إنجليزية فقط.',
    userNotFound:    '> ❌ | لم يتم العثور على اسم المستخدم.',
    newPost:         'تغريدة جديدة 📝',
    postLabel:       'اكتب تغريدتك (280 حرف كحد أقصى)',
    postImage:       'رابط صورة مرفقة (اختياري)',
    followers:       'متابعون',
    following:       'متابَعون',
    posts:           'تغريدات',
    joinedOn:        'انضم في',
    signedOut:       '> ✅ | تم تسجيل الخروج بنجاح.',
    alreadySignedIn: '> ⚠️ | هذا الحساب نشط على هاتف آخر.',
  },
};

function tr(lang) { return T[lang] || T.en; }

function formatDate(d) {
  return DateTime.fromJSDate(new Date(d)).setZone('Asia/Amman').toFormat('dd/MM/yyyy hh:mm a');
}

// جلب بيانات الهاتف واللاعب الاونلاين
async function resolveContext(interaction) {
  const [chars] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
  if (!chars.length) return { error: 'NO_CHAR' };
  const char = chars.find(c => c.status === 'ONLINE');
  if (!char) return { error: 'NO_ONLINE' };

  const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');
  if (!usedItem) return { error: 'NO_PHONE' };

  const phoneData = await phoneDB.getPhone(usedItem.item_serial);
  if (!phoneData || !phoneData.setup_done) return { error: 'NO_PHONE' };

  const lang    = phoneData.language || 'en';
  const account = await xDB.getAccountByPhone(usedItem.item_serial);

  return { char, phoneData, phoneSerial: usedItem.item_serial, lang, account };
}

async function sendError(interaction, code) {
  const msgs = {
    NO_CHAR:   `❌ | يجب عليك إنشاء شخصية أولاً`,
    NO_ONLINE: `⚠️ | قم بإختيار شخصيتك المتصلة أولاً`,
    NO_PHONE:  `📱 | لم يتم العثور على هاتف نشط في حقيبتك`,
  };
  const content = msgs[code] || '❌ حدث خطأ غير متوقع';
  if (interaction.deferred || interaction.replied) return interaction.editReply({ content, components: [], embeds: [] });
  return interaction.reply({ content, flags: MessageFlags.Ephemeral });
}

// ─────────────────────────────────────────────
// UI RENDERERS USING EMBEDS (TO FIX IMAGES)
// ─────────────────────────────────────────────

function buildWelcomePage(lang) {
  const t = tr(lang);
  const embed = new EmbedBuilder()
    .setColor(0x1DA1F2)
    .setTitle('X App')
    .setDescription(t.noAccount)
    .setThumbnail('https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png');

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`x-signin_${lang}`).setLabel(t.signIn).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`x-register_${lang}`).setLabel(t.register).setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('playerphone-app_back_home').setLabel(t.back).setStyle(ButtonStyle.Danger)
  );
  return { embeds: [embed], components: [row] };
}

function buildMainPage(lang) {
  const t = tr(lang);
  const embed = new EmbedBuilder()
    .setColor(0x1DA1F2)
    .setTitle('X App')
    .setDescription(`### <:twitter:1497627221756743700> | مرحبا بك في منصة X\nإختر وجهتك من الأزرار بالأسفل تصفح الحسابات أو اقرأ آخر التغريدات.`);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`x-home_${lang}`).setLabel(t.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`x-search_${lang}`).setLabel(t.search).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`x-myprofile_${lang}`).setLabel(t.myProfile).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('playerphone-app_back_home').setLabel(t.back).setStyle(ButtonStyle.Danger)
  );
  return { embeds: [embed], components: [row] };
}

// إعداد التايملاين مع إمبيد منفصل وصور متكاملة وأزرار التفاعل بالأسفل
async function renderFeed(interaction, posts, page, totalPages, account, lang) {
  const t = tr(lang);
  const embeds = [];
  const components = [];

  if (!posts.length) {
    const emptyEmbed = new EmbedBuilder().setColor(0x1DA1F2).setDescription(t.noPosts);
    embeds.push(emptyEmbed);
  }

  // إنشاء إمبيد منفصل لكل بوست مع زر لايك وريبوست أسفل منه مباشرة
  for (const post of posts) {
    const liked = await xDB.hasLiked(account.id, post.id);
    const dateStr = formatDate(post.created_at);
    
    const postEmbed = new EmbedBuilder()
      .setColor(0x1DA1F2)
      .setAuthor({
        name: `${post.display_name} (@${post.username})`,
        iconURL: post.avatar_url || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png'
      })
      .setDescription(post.content)
      .setFooter({ text: `X Client • ${dateStr}` });

    // إذا كانت التغريدة تحتوي على صورة، ستظهر هنا فوراً وبشكل سليم بنسبة 100%
    if (post.image_url && post.image_url.startsWith('http')) {
      postEmbed.setImage(post.image_url);
    }

    embeds.push(postEmbed);

    // إضافة صف أزرار تفاعلي أسفل هذا الإمبيد مباشرة
    const interactRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`x-like_${post.id}_${lang}`)
        .setLabel(`${liked ? '❤️' : '🤍'} ${post.likes || 0}`)
        .setStyle(liked ? ButtonStyle.Primary : ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`x-repost_${post.id}_${lang}`)
        .setLabel(`🔁 ${post.reposts || 0}`)
        .setStyle(ButtonStyle.Secondary)
    );
    components.push(interactRow);
  }

  // إضافة صف أزرار التحكم في أسفل الرسالة (السابق، تغريدة جديدة، التالي، رجوع)
  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`x-feed-prev_${page}_${lang}`).setLabel(t.prev).setStyle(ButtonStyle.Primary).setDisabled(page <= 0),
    new ButtonBuilder().setCustomId(`x-newpost_${lang}`).setLabel(t.newPost).setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`x-feed-next_${page}_${lang}`).setLabel(t.next).setStyle(ButtonStyle.Primary).setDisabled(page >= totalPages - 1),
    new ButtonBuilder().setCustomId(`x-main_${lang}`).setLabel(t.back).setStyle(ButtonStyle.Danger)
  );
  components.push(navRow);

  // لضمان عدم تجاوز الحد الأقصى لمكونات ديسكورد (5 صفوف أزرار، 10 إمبيدز)
  return interaction.editReply({ embeds, components: components.slice(0, 5) });
}

async function renderProfile(interaction, targetAccount, viewerAccount, lang) {
  const t = tr(lang);
  const dateStr = formatDate(targetAccount.created_at);
  const posts = await xDB.getUserPosts(targetAccount.id, 3, 0);
  const isOwner = viewerAccount?.id === targetAccount.id;

  const profileEmbed = new EmbedBuilder()
    .setColor(0x1DA1F2)
    .setTitle(`${targetAccount.display_name} (@${targetAccount.username})`)
    .setDescription(`${targetAccount.bio || '*لا توجد نبذة تعريفية*'}\n\n👥 **${t.followers}:** \`${targetAccount.followers}\` | **${t.following}:** \`${targetAccount.following}\``)
    .setThumbnail(targetAccount.avatar_url || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png')
    .addFields({ name: t.joinedOn, value: dateStr, inline: true });

  const embeds = [profileEmbed];

  // إلحاق تغريدات الشخص الأخيرة بداخل الإمبيد
  if (posts.length > 0) {
    posts.forEach((post, index) => {
      const pEmbed = new EmbedBuilder()
        .setColor(0x333333)
        .setDescription(`📌 **تغريدة ${index + 1}:**\n${post.content}\n🖤 \`${post.likes}\` | 🔁 \`${post.reposts}\``);
      if (post.image_url) pEmbed.setImage(post.image_url);
      embeds.push(pEmbed);
    });
  }

  const btns = [];
  if (isOwner) {
    btns.push(new ButtonBuilder().setCustomId(`x-signout_${lang}`).setLabel(t.signOut).setStyle(ButtonStyle.Danger));
  }
  btns.push(new ButtonBuilder().setCustomId(`x-main_${lang}`).setLabel(t.back).setStyle(ButtonStyle.Secondary));

  const row = new ActionRowBuilder().addComponents(...btns);

  return interaction.editReply({ embeds: embeds.slice(0, 5), components: [row] });
}

// ─────────────────────────────────────────────
// MAIN EVENT HANDLER
// ─────────────────────────────────────────────
module.exports = {
  name: Events.InteractionCreate,
  once: false,

  async execute(interaction) {
    try {
      const customId = interaction.customId;
      if (!customId) return;

      // ───── فتح تطبيق X ─────
      if (interaction.isButton() && customId === 'playerphone-app_x') {
        await interaction.deferUpdate();
        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        if (!ctx.account) {
          const res = buildWelcomePage(ctx.lang);
          return interaction.editReply({ embeds: res.embeds, components: res.components });
        }

        const res = buildMainPage(ctx.lang);
        return interaction.editReply({ embeds: res.embeds, components: res.components });
      }

      // ───── العودة للرئيسية ─────
      if (interaction.isButton() && customId.startsWith('x-main_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const res = buildMainPage(lang);
        return interaction.editReply({ embeds: res.embeds, components: res.components });
      }

      // ───── إنشاء الحساب (Modal) ─────
      if (interaction.isButton() && customId.startsWith('x-register_')) {
        const lang = customId.split('_')[1];
        const t = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId(`x-register-submit_${lang}`)
          .setTitle(t.registerTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('display_name').setLabel(t.labelDisplay).setStyle(TextInputStyle.Short).setMinLength(1).setMaxLength(8).setRequired(true)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('username').setLabel(t.labelUsername).setStyle(TextInputStyle.Short).setMinLength(3).setMaxLength(8).setRequired(true)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('bio').setLabel(t.labelBio).setStyle(TextInputStyle.Paragraph).setMaxLength(40).setRequired(false)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('avatar_url').setLabel(t.labelAvatar).setStyle(TextInputStyle.Short).setRequired(false))
          );

        return interaction.showModal(modal);
      }

      // ───── استقبال بيانات التسجيل وحفظها ─────
      if (interaction.isModalSubmit() && customId.startsWith('x-register-submit_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const t = tr(lang);
        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const displayName = interaction.fields.getTextInputValue('display_name').trim();
        const username    = interaction.fields.getTextInputValue('username').trim();
        const bio         = interaction.fields.getTextInputValue('bio')?.trim() || null;
        const avatarUrl   = interaction.fields.getTextInputValue('avatar_url')?.trim() || null;

        if (!displayName || displayName.length > 8) return interaction.editReply({ content: t.invalidDisplay, components: [], embeds: [] });
        if (!/^[a-zA-Z0-9]{3,8}$/.test(username)) return interaction.editReply({ content: t.invalidUsername, components: [], embeds: [] });

        const result = await xDB.createAccount(interaction.user.id, ctx.char.character_number, ctx.phoneSerial, { display_name: displayName, username, bio, avatar_url: avatarUrl });
        if (result?.error === 'USERNAME_TAKEN') return interaction.editReply({ content: t.usernameTaken, components: [], embeds: [] });

        const res = buildMainPage(lang);
        return interaction.editReply({ content: t.registerSuccess, embeds: res.embeds, components: res.components });
      }

      // ───── تسجيل الدخول (Modal) ─────
      if (interaction.isButton() && customId.startsWith('x-signin_')) {
        const lang = customId.split('_')[1];
        const t = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId(`x-signin-submit_${lang}`)
          .setTitle(t.signInTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('username').setLabel(t.labelSignIn).setStyle(TextInputStyle.Short).setRequired(true))
          );
        return interaction.showModal(modal);
      }

      if (interaction.isModalSubmit() && customId.startsWith('x-signin-submit_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const t = tr(lang);
        const username = interaction.fields.getTextInputValue('username').trim();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const account = await xDB.getAccountByUsername(username);
        if (!account) return interaction.editReply({ content: t.userNotFound, components: [], embeds: [] });

        await xDB.linkAccountToPhone(account.id, ctx.phoneSerial);
        const res = buildMainPage(lang);
        return interaction.editReply({ embeds: res.embeds, components: res.components });
      }

      // ───── فتح التايملاين (Home Feed) ─────
      if (interaction.isButton() && customId.startsWith('x-home_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const ctx = await resolveContext(interaction);
        if (ctx.error || !ctx.account) return sendError(interaction, ctx.error || 'NO_PHONE');

        const total      = (await xDB.getPosts(9999, 0)).length;
        const totalPages = Math.max(1, Math.ceil(total / POSTS_PER_PAGE));
        const posts      = await xDB.getPosts(POSTS_PER_PAGE, 0);

        sessions.set(interaction.user.id, { page: 0, totalPages });
        return renderFeed(interaction, posts, 0, totalPages, ctx.account, lang);
      }

      // ───── تقليب صفحات التايملاين ─────
      if (interaction.isButton() && (customId.startsWith('x-feed-prev_') || customId.startsWith('x-feed-next_'))) {
        await interaction.deferUpdate();
        const isPrev  = customId.startsWith('x-feed-prev_');
        const raw     = customId.replace(isPrev ? 'x-feed-prev_' : 'x-feed-next_', '');
        const parts   = raw.split('_');
        const curPage = parseInt(parts[0]);
        const lang    = parts[1];

        const ctx = await resolveContext(interaction);
        if (ctx.error || !ctx.account) return sendError(interaction, ctx.error || 'NO_PHONE');

        const total      = (await xDB.getPosts(9999, 0)).length;
        const totalPages = Math.max(1, Math.ceil(total / POSTS_PER_PAGE));
        const newPage    = isPrev ? Math.max(0, curPage - 1) : Math.min(totalPages - 1, curPage + 1);
        const posts      = await xDB.getPosts(POSTS_PER_PAGE, newPage * POSTS_PER_PAGE);

        sessions.set(interaction.user.id, { page: newPage, totalPages });
        return renderFeed(interaction, posts, newPage, totalPages, ctx.account, lang);
      }

      // ───── ضغط زر الإعجاب (Like) ─────
      if (interaction.isButton() && customId.startsWith('x-like_')) {
        await interaction.deferUpdate();
        const parts  = customId.replace('x-like_', '').split('_');
        const postId = parseInt(parts[0]);
        const lang   = parts[1];

        const ctx = await resolveContext(interaction);
        if (ctx.error || !ctx.account) return sendError(interaction, ctx.error || 'NO_PHONE');

        await xDB.toggleLike(ctx.account.id, postId);

        const session = sessions.get(interaction.user.id) || { page: 0 };
        const total      = (await xDB.getPosts(9999, 0)).length;
        const totalPages = Math.max(1, Math.ceil(total / POSTS_PER_PAGE));
        const posts      = await xDB.getPosts(POSTS_PER_PAGE, session.page * POSTS_PER_PAGE);

        return renderFeed(interaction, posts, session.page, totalPages, ctx.account, lang);
      }

      // ───── ضغط زر الريبوست (Repost) ─────
      if (interaction.isButton() && customId.startsWith('x-repost_')) {
        await interaction.deferUpdate();
        const parts = customId.replace('x-repost_', '').split('_');
        const postId = parseInt(parts[0]);
        const lang = parts[1];

        const ctx = await resolveContext(interaction);
        if (ctx.error || !ctx.account) return sendError(interaction, ctx.error || 'NO_PHONE');

        // زيادة عداد الريبوست بشكل مباشر في قاعدة البيانات
        await pool.query(`UPDATE x_posts SET reposts = reposts + 1 WHERE id = ?`, [postId]);

        const session = sessions.get(interaction.user.id) || { page: 0 };
        const total      = (await xDB.getPosts(9999, 0)).length;
        const totalPages = Math.max(1, Math.ceil(total / POSTS_PER_PAGE));
        const posts      = await xDB.getPosts(POSTS_PER_PAGE, session.page * POSTS_PER_PAGE);

        return renderFeed(interaction, posts, session.page, totalPages, ctx.account, lang);
      }

      // ───── مودال كتابة تغريدة جديدة ─────
      if (interaction.isButton() && customId.startsWith('x-newpost_')) {
        const lang = customId.split('_')[1];
        const t = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId(`x-newpost-submit_${lang}`)
          .setTitle(t.newPost)
          .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('post_content').setLabel(t.postLabel).setStyle(TextInputStyle.Paragraph).setMaxLength(280).setRequired(true)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('post_image').setLabel(t.postImage).setStyle(TextInputStyle.Short).setRequired(false))
          );

        return interaction.showModal(modal);
      }

      // ───── معالجة ونشر التغريدة الجديدة ─────
      if (interaction.isModalSubmit() && customId.startsWith('x-newpost-submit_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const content = interaction.fields.getTextInputValue('post_content').trim();
        const imageUrl = interaction.fields.getTextInputValue('post_image').trim() || null;

        const ctx = await resolveContext(interaction);
        if (ctx.error || !ctx.account) return sendError(interaction, ctx.error || 'NO_PHONE');

        await xDB.createPost(ctx.account.id, content, imageUrl);

        const total      = (await xDB.getPosts(9999, 0)).length;
        const totalPages = Math.max(1, Math.ceil(total / POSTS_PER_PAGE));
        const posts      = await xDB.getPosts(POSTS_PER_PAGE, 0);

        sessions.set(interaction.user.id, { page: 0, totalPages });
        return renderFeed(interaction, posts, 0, totalPages, ctx.account, lang);
      }

      // ───── البحث عن الحسابات ─────
      if (interaction.isButton() && customId.startsWith('x-search_')) {
        const lang = customId.split('_')[1];
        const t = tr(lang);

        const modal = new ModalBuilder()
          .setCustomId(`x-search-submit_${lang}`)
          .setTitle(t.searchTitle)
          .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('query').setLabel(t.labelSearch).setStyle(TextInputStyle.Short).setRequired(true))
          );
        return interaction.showModal(modal);
      }

      if (interaction.isModalSubmit() && customId.startsWith('x-search-submit_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const t = tr(lang);
        const query = interaction.fields.getTextInputValue('query').trim();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const results = await xDB.searchAccounts(query);
        const embeds = [];
        const rows = [];

        const searchEmbed = new EmbedBuilder().setColor(0x1DA1F2).setTitle(t.searchTitle);
        
        if (!results.length) {
          searchEmbed.setDescription(t.noResults);
          embeds.push(searchEmbed);
        } else {
          searchEmbed.setDescription(`نتائج البحث عن: \`${query}\``);
          embeds.push(searchEmbed);

          const resultRow = new ActionRowBuilder();
          results.slice(0, 4).forEach(acc => {
            resultRow.addComponents(
              new ButtonBuilder().setCustomId(`x-viewprofile_${acc.id}_${lang}`).setLabel(`👤 ${acc.display_name}`).setStyle(ButtonStyle.Secondary)
            );
          });
          rows.push(resultRow);
        }

        rows.push(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`x-main_${lang}`).setLabel(t.back).setStyle(ButtonStyle.Danger)));
        return interaction.editReply({ embeds, components: rows });
      }

      // ───── عرض ملف شخص آخر ─────
      if (interaction.isButton() && customId.startsWith('x-viewprofile_')) {
        await interaction.deferUpdate();
        const parts = customId.replace('x-viewprofile_', '').split('_');
        const accountId = parseInt(parts[0]);
        const lang = parts[1];

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const targetAccount = await xDB.getAccountById(accountId);
        if (!targetAccount) return sendError(interaction, 'NO_PHONE');

        return renderProfile(interaction, targetAccount, ctx.account, lang);
      }

      // ───── عرض ملفي الشخصي ─────
      if (interaction.isButton() && customId.startsWith('x-myprofile_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];

        const ctx = await resolveContext(interaction);
        if (ctx.error || !ctx.account) return sendError(interaction, ctx.error || 'NO_PHONE');

        return renderProfile(interaction, ctx.account, ctx.account, lang);
      }

      // ───── تسجيل الخروج ─────
      if (interaction.isButton() && customId.startsWith('x-signout_')) {
        await interaction.deferUpdate();
        const lang = customId.split('_')[1];
        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        await xDB.signOut(ctx.phoneSerial);
        const res = buildWelcomePage(lang);
        return interaction.editReply({ embeds: res.embeds, components: res.components });
      }

    } catch (err) {
      console.error('[phoneX Hub Error]', err);
    }
  }
};