const { createCanvas, loadImage } = require('canvas');

// دالة رسم كرت التغريدة (صورة الحساب + صورة التغريدة المرفقة)
async function drawTweetCard(post, theme) {
  const canvas = createCanvas(600, 400);
  const ctx = canvas.getContext('2d');

  // تعيين الخلفيات حسب الثيم
  ctx.fillStyle = theme === 'dark' ? '#15202B' : '#FFFFFF';
  ctx.fillRect(0, 0, 600, 400);

  // 1. رسم صورة البروفايل لصاحب التغريدة
  try {
    const avatarUrl = post.avatar_url || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png';
    const avatarImg = await loadImage(avatarUrl);
    ctx.save();
    ctx.beginPath();
    ctx.arc(50, 50, 30, 0, Math.PI * 2, true); // جعل الصورة دائرية تماشيًا مع شكل تويتر
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatarImg, 20, 20, 60, 60);
    ctx.restore();
  } catch (e) {
    // في حال فشل تحميل الرابط يتم رسم دائرة بديلة لمنع توقف السيرفر
    ctx.fillStyle = '#8899A6';
    ctx.beginPath();
    ctx.arc(50, 50, 30, 0, Math.PI * 2, true);
    ctx.fill();
  }

  // كتابة النصوص (الاسم واليوزر والمحتوى)
  ctx.fillStyle = theme === 'dark' ? '#FFFFFF' : '#000000';
  ctx.font = 'bold 18px Arial';
  ctx.fillText(post.display_name || 'User', 95, 45);

  ctx.fillStyle = '#8899A6';
  ctx.font = '14px Arial';
  ctx.fillText(`@${post.username || 'user'}`, 95, 65);

  ctx.fillStyle = theme === 'dark' ? '#FFFFFF' : '#000000';
  ctx.font = '16px Arial';
  ctx.fillText(post.content || '', 30, 120);

  // 2. رسم صورة التغريدة المرفقة إن وجدت
  if (post.image_url) {
    try {
      const tweetImg = await loadImage(post.image_url);
      // رسم الصورة المرفقة أسفل نص التغريدة بأبعاد متناسقة
      ctx.drawImage(tweetImg, 30, 150, 540, 200);
    } catch (e) {
      console.log("Failed to load tweet attachment image.");
    }
  }

  return canvas.toBuffer();
}

// دالة رسم صفحة البروفايل بالكامل
async function drawUserProfile(account, theme) {
  const canvas = createCanvas(600, 350);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = theme === 'dark' ? '#15202B' : '#FFFFFF';
  ctx.fillRect(0, 0, 600, 350);

  // رسم الهيدر (غلاف رمادي الافتراضي لتويتر)
  ctx.fillStyle = '#1DA1F2';
  ctx.fillRect(0, 0, 600, 100);

  // رسم صورة البروفايل الشخصية الكبيرة للبروفايل
  try {
    const avatarUrl = account.avatar_url || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png';
    const avatarImg = await loadImage(avatarUrl);
    ctx.save();
    ctx.beginPath();
    ctx.arc(70, 110, 45, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatarImg, 25, 65, 90, 90);
    ctx.restore();
  } catch (e) {
    ctx.fillStyle = '#8899A6';
    ctx.beginPath();
    ctx.arc(70, 110, 45, 0, Math.PI * 2, true);
    ctx.fill();
  }

  // كتابة تفاصيل الحساب والإحصائيات
  ctx.fillStyle = theme === 'dark' ? '#FFFFFF' : '#000000';
  ctx.font = 'bold 22px Arial';
  ctx.fillText(account.display_name, 30, 185);

  ctx.fillStyle = '#8899A6';
  ctx.font = '15px Arial';
  ctx.fillText(`@${account.username}`, 30, 210);

  ctx.fillStyle = theme === 'dark' ? '#E1E8ED' : '#292F33';
  ctx.font = '16px Arial';
  ctx.fillText(account.bio || 'No bio available.', 30, 245);

  return canvas.toBuffer();
}

module.exports = { drawTweetCard, drawUserProfile };