const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags,
  ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder
} = require('discord.js');
const { pool }      = require('../../utils/database/mysql');
const { DateTime }  = require('luxon');
const { getUsedItem } = require('../../utils/database/inventory_mysql');
const phoneDB       = require('../../utils/database/phone_mysql');
const { createTransaction, TRANSACTION_TYPE } = require('../../utils/database/transaction_mysql');

const { Name }           = require('../../JSON/config.json');
const { BankTransferLog } = require('../../JSON/channels.json');

const ITEMS_PER_PAGE = 3;
const sessions       = new Map();

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function sep(size = SeparatorSpacingSize.Small) {
  return new SeparatorBuilder().setDivider(true).setSpacing(size);
}

async function resolveContext(interaction) {
  const [rows] = await pool.query(`SELECT * FROM characters WHERE user_id = ?`, [interaction.user.id]);
  if (!rows.length) return { error: 'NO_CHAR' };

  const char = rows.find(c => c.status === 'ONLINE') || null;
  if (!char) return { error: 'NO_ONLINE' };

  const usedItem = await getUsedItem(interaction.user.id, char.character_number, 'Phone');
  if (!usedItem) return { error: 'NO_PHONE' };

  const phoneData = await phoneDB.getPhone(usedItem.item_serial);
  if (!phoneData || !phoneData.setup_done) return { error: 'NO_PHONE' };

  return { char, phoneData };
}

function sendError(interaction, code) {
  const messages = {
    NO_CHAR:   `<:No:1497627141465178132> | يجب عليك إنشاء شخصية أولا`,
    NO_ONLINE: `<:Warn:1497627240177991780> | قم بإختيار شخصية أولا`,
    NO_PHONE:  `<:Warn:1497627240177991780> | لم يتم العثور على هاتف نشط`,
  };
  const content = messages[code] || '❌ Error occurred';
  if (interaction.deferred || interaction.replied) return interaction.editReply({ content, components: [], embeds: [] });
  return interaction.reply({ content, flags: MessageFlags.Ephemeral });
}

// ─────────────────────────────────────────────
// PAGE BUILDERS
// ─────────────────────────────────────────────
function buildHomeContainer(char) {
  return new ContainerBuilder()
    .setAccentColor(0x1c1c1e)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# <:applepay:1505185909732278363> | Apple Pay`)
    )
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**${char.firstname} ${char.lastname}**\n-# <:tag:1497627214374768700> IBAN: **\`${char.iban}\`**`
      )
    )
    .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('applepay-balance')
          .setLabel('Balance')
          .setEmoji('<:Bank:1388227015798423613>')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('applepay-transfer')
          .setLabel('Transfer')
          .setEmoji('<:Money:1497627135920308405>')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('applepay-transactions')
          .setLabel('Transactions')
          .setEmoji('<:tag:1497627214374768700>')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('playerphone-app_back_home')
          .setLabel('Back')
          .setStyle(ButtonStyle.Secondary),
      )
    );
}

function buildBalanceContainer(char) {
  const bank = isNaN(char.bank) ? 0 : Number(char.bank);

  return new ContainerBuilder()
    .setAccentColor(0x1c1c1e)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# <:applepay:1505185909732278363> | Account Balance`)
    )
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**<:Bank:1388227015798423613> Bank:** $${bank.toLocaleString()}`
      )
    )
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${char.firstname} ${char.lastname} — ${char.iban}`)
    )
    .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('playerphone-app_bank')
          .setLabel('Back')
          .setStyle(ButtonStyle.Secondary)
      )
    );
}

function buildTransactionsContainer(char, transactions, page, totalPages) {
  const start  = page * ITEMS_PER_PAGE;
  const pageTx = transactions.slice(start, start + ITEMS_PER_PAGE);

  const container = new ContainerBuilder()
    .setAccentColor(0x1c1c1e)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# <:applepay:1505185909732278363> | Transactions\n**${char.firstname} ${char.lastname}** • \`${char.iban}\` — Page ${page + 1} of ${totalPages}`
      )
    )
    .addSeparatorComponents(sep(SeparatorSpacingSize.Large));

  if (!pageTx.length) {
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent('> No transactions found.')
    );
    return container;
  }

  pageTx.forEach((tx, i) => {
    const globalIndex = transactions.length - (start + i);
    const amount = Number(tx.amount);
    const tax    = Math.ceil(amount * 0.025);
    const net    = amount - tax;
    const date   = DateTime.fromJSDate(new Date(tx.created_at))
      .setZone('Asia/Amman')
      .toFormat('dd/MM/yyyy HH:mm');

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**#${globalIndex}** — \`${tx.type}\`\n` +
        `**Amount:** $${amount.toLocaleString()}  **Tax:** $${tax.toLocaleString()} • **Net:** $${net.toLocaleString()}\n` +
        `**Reason:** ${tx.reason}\n` +
        `**Date:** ${date}`
      )
    );

    if (i < pageTx.length - 1) {
      container.addSeparatorComponents(sep(SeparatorSpacingSize.Large));
    }
  });

  return container;
}

function buildTxButtons(page, totalPages) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('applepay-tx-prev')
      .setLabel('◀ Previous')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page === 0),
    new ButtonBuilder()
      .setCustomId('applepay-tx-page')
      .setLabel(`${page + 1} / ${totalPages}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId('applepay-tx-next')
      .setLabel('Next ▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages - 1),
    new ButtonBuilder()
      .setCustomId('playerphone-app_bank')
      .setLabel('Back')
      .setStyle(ButtonStyle.Secondary),
  );
}

// ─────────────────────────────────────────────
// MAIN EVENT
// ─────────────────────────────────────────────
module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(interaction, client) {
    try {

      // ───── فتح Apple Pay ─────
      if (interaction.isButton() && interaction.customId === 'playerphone-app_bank') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        return interaction.editReply({
          components: [buildHomeContainer(ctx.char)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ───── Balance ─────
      if (interaction.isButton() && interaction.customId === 'applepay-balance') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        return interaction.editReply({
          components: [buildBalanceContainer(ctx.char)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ───── Transfer — Modal ─────
      if (interaction.isButton() && interaction.customId === 'applepay-transfer') {
        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const modal = new ModalBuilder()
          .setCustomId('applepay-transfer-modal')
          .setTitle('Apple Pay — Transfer')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('iban')
                .setLabel('Recipient IBAN')
                .setStyle(TextInputStyle.Short)
                .setMinLength(4)
                .setMaxLength(20)
                .setPlaceholder('Enter recipient IBAN')
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('amount')
                .setLabel('Amount ($5 - $1,000,000)')
                .setStyle(TextInputStyle.Short)
                .setMinLength(1)
                .setMaxLength(7)
                .setPlaceholder('e.g. 500')
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('reason')
                .setLabel('Reason')
                .setStyle(TextInputStyle.Short)
                .setMinLength(2)
                .setMaxLength(30)
                .setPlaceholder('e.g. Rent payment')
                .setRequired(true)
            )
          );

        return interaction.showModal(modal);
      }

      // ───── Transfer — Submit ─────
      if (interaction.isModalSubmit() && interaction.customId === 'applepay-transfer-modal') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const { char } = ctx;

        const recipientIban = interaction.fields.getTextInputValue('iban').trim();
        const rawAmount     = interaction.fields.getTextInputValue('amount').trim();
        const reason        = interaction.fields.getTextInputValue('reason').trim();

        if (!/^\d+$/.test(rawAmount)) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | المبلغ يجب أن يكون أرقاماً فقط`,
            components: [], embeds: [],
          });
        }

        const amount = parseInt(rawAmount);

        if (amount < 5 || amount > 1000000) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | المبلغ يجب أن يكون بين $5 و $1,000,000`,
            components: [], embeds: [],
          });
        }

        if (recipientIban === char.iban) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | لا يمكنك التحويل لنفسك`,
            components: [], embeds: [],
          });
        }

        const [recipientRows] = await pool.query(
          `SELECT * FROM characters WHERE iban = ?`,
          [recipientIban]
        );

        if (!recipientRows.length) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | لا يوجد شخص يحمل هذا الـ IBAN`,
            components: [], embeds: [],
          });
        }

        const recipient = recipientRows[0];
        const bank      = Number(char.bank) || 0;

        if (bank < amount) {
          return interaction.editReply({
            content: `<:No:1497627141465178132> | رصيدك في البنك غير كافٍ — الرصيد الحالي: $${bank.toLocaleString()}`,
            components: [], embeds: [],
          });
        }

        const tax           = Math.ceil(amount * 0.025);
        const netAmount     = amount - tax;
        const senderNewBank = bank - amount;
        const recipNewBank  = (Number(recipient.bank) || 0) + netAmount;

        await pool.query(
          `UPDATE characters SET bank = ? WHERE user_id = ? AND status = 'ONLINE'`,
          [senderNewBank, interaction.user.id]
        );

        await pool.query(
          `UPDATE characters SET bank = ? WHERE iban = ?`,
          [recipNewBank, recipientIban]
        );

        const transactionNumber = await createTransaction({
          userId:     interaction.user.id,
          nationalId: char.national_id,
          iban:       char.iban,
          firstname:  char.firstname,
          lastname:   char.lastname,
          type:       TRANSACTION_TYPE.TRANSFER,
          amount,
          reason,
          cashAfter:  Number(char.cash) || 0,
          bankAfter:  senderNewBank,
        });

        // ── نعرض نتيجة التحويل داخل الهاتف ──
        const resultContainer = new ContainerBuilder()
          .setAccentColor(0x30d158)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# <:applepay:1505185909732278363> | Transfer Successful`)
          )
          .addSeparatorComponents(sep())
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `**To:** ${recipient.firstname} ${recipient.lastname}\n` +
              `**IBAN:** \`${recipientIban}\`\n\n` +
              `**Amount:** $${amount.toLocaleString()}\n` +
              `**Reason:** ${reason}\n\n` +
              `-# Tax (2.5%): $${tax.toLocaleString()}\n` +
              `-# Net: $${netAmount.toLocaleString()}\n` +
              `-# Transaction: \`${transactionNumber}\``
            )
          )
          .addSeparatorComponents(sep(SeparatorSpacingSize.Large))
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId('playerphone-app_bank')
                .setLabel('Back')
                .setStyle(ButtonStyle.Secondary)
            )
          );

        await interaction.editReply({
          components: [resultContainer],
          flags: MessageFlags.IsComponentsV2,
        });

        // ── DM للمستقبِل ──
        try {
          const recipientUser = await client.users.fetch(recipient.user_id);
          if (recipientUser) {
            const dmEmbed = new EmbedBuilder()
              .setTitle(`Apple Pay — Transfer Received`)
              .setDescription(
                `<:applepay:1505185909732278363> | تم استلام مبلغ التحويل بنجاح\n\n` +
                `**From:** ${char.firstname} ${char.lastname}\n` +
                `**IBAN:** \`${char.iban}\`\n\n` +
                `**Amount Received:** $${netAmount.toLocaleString()}\n` +
                `**Reason:** ${reason}\n\n` +
                `**Transaction:** \`${transactionNumber}\``
              )
              .setFooter({ text: `${recipient.firstname} ${recipient.lastname} — ${recipientIban}` })
              .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate());

            await recipientUser.send({ embeds: [dmEmbed] });
          }
        } catch (e) {
          console.error('[applePay DM]', e.message);
        }

        // ── Log ──
        const logChannel = client.channels.cache.get(BankTransferLog);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle(`Apple Pay Log | Transfer`)
            .setDescription(
              `**User:** <@${interaction.user.id}> (${interaction.user.id})\n` +
              `**Username:** ${interaction.user.username}\n` +
              `**Time:** ${DateTime.now().setZone('Asia/Amman').toISO()}\n\n` +
              `**Character:** ${char.firstname} ${char.lastname}\n` +
              `**National ID:** ${char.national_id}\n` +
              `**IBAN:** ${char.iban}\n\n` +
              `─────────────────────\n\n` +
              `**Recipient:** ${recipient.firstname} ${recipient.lastname}\n` +
              `**Recipient IBAN:** ${recipientIban}\n\n` +
              `**Amount:** $${amount.toLocaleString()}\n` +
              `**Tax (2.5%):** $${tax.toLocaleString()}\n` +
              `**Net:** $${netAmount.toLocaleString()}\n` +
              `**Reason:** ${reason}\n` +
              `**Transaction:** \`${transactionNumber}\``
            )
            .setTimestamp(DateTime.now().setZone('Asia/Amman').toJSDate())
            .setFooter({ text: `${Name} | Log`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 128 }) });

          await logChannel.send({ embeds: [logEmbed] });
        }
      }

      // ───── Transactions — فتح ─────
      if (interaction.isButton() && interaction.customId === 'applepay-transactions') {
        await interaction.deferUpdate();

        const ctx = await resolveContext(interaction);
        if (ctx.error) return sendError(interaction, ctx.error);

        const { char } = ctx;

        const [txRows] = await pool.query(
          `SELECT * FROM bank_transactions WHERE iban = ? ORDER BY created_at DESC`,
          [char.iban]
        );

        const totalPages = Math.max(1, Math.ceil(txRows.length / ITEMS_PER_PAGE));
        const page       = 0;

        sessions.set(interaction.user.id, { char, transactions: txRows, page, totalPages });

        const container = buildTransactionsContainer(char, txRows, page, totalPages);
        const buttons   = buildTxButtons(page, totalPages);

        return interaction.editReply({
          components: txRows.length > ITEMS_PER_PAGE ? [container, buttons] : [container, buildTxButtons(0, 1)],
          flags: MessageFlags.IsComponentsV2,
        });
      }

      // ───── Transactions — Pagination ─────
      if (interaction.isButton() && ['applepay-tx-prev', 'applepay-tx-next'].includes(interaction.customId)) {
        await interaction.deferUpdate();

        const session = sessions.get(interaction.user.id);
        if (!session) {
          return interaction.editReply({ content: `<:Warn:1497627240177991780> | انتهت الجلسة، أعد فتح التحويلات` });
        }

        if (interaction.customId === 'applepay-tx-prev' && session.page > 0) {
          session.page--;
        } else if (interaction.customId === 'applepay-tx-next' && session.page < session.totalPages - 1) {
          session.page++;
        }

        sessions.set(interaction.user.id, session);

        const container = buildTransactionsContainer(session.char, session.transactions, session.page, session.totalPages);
        const buttons   = buildTxButtons(session.page, session.totalPages);

        return interaction.editReply({
          components: [container, buttons],
          flags: MessageFlags.IsComponentsV2,
        });
      }

    } catch (err) {
      console.error('[applePay]', err);
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Error occurred', flags: MessageFlags.Ephemeral });
      }
    }
  },
};