const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { Vibrant } = require('node-vibrant/node');
const { Banner } = require('../../JSON/images.json');
const { Founders } = require('../../JSON/roles.json');

module.exports = {
  name: '-mazebank',
  async execute(client, message, args) {
    if (!message.member.roles.cache.some(role => Founders.includes(role.id))) return;

    const thumbnail = message.guild.iconURL({ size: 256, extension: 'png' });
    const accentColor = await getAccentColor(thumbnail);

    const container = new ContainerBuilder()
      .setAccentColor(accentColor)

      // Title
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# <:Logo:1497624868827693096> | Maze Bank')
      )

      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )

      // Description
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `> <:Maze:1497627129956008118> | Maze Bank Of Los Santos, خيارك الأفضل و الوحيد`
        )
      )

      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Large)
      )

      // Banner
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(Banner)
        )
      )

      // Buttons Row
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('mazebank')
            .setLabel('Maze Bank')
            .setEmoji('<:Maze:1497627129956008118>')
            .setStyle(ButtonStyle.Secondary)
        )
      );

    await message.channel.send({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });

    await message.delete();
  }
};

async function getAccentColor(thumbnail) {
  try {
    const palette = await Vibrant.from(thumbnail).getPalette();
    const color = palette.Vibrant?.hex || palette.Dominant?.hex;
    if (color) return parseInt(color.replace('#', ''), 16);
  } catch {}
  return 0x2f3136;
}