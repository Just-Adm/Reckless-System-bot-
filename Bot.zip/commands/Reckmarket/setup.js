const { MessageFlags } = require('discord.js');
const { Founders }     = require('../../JSON/roles.json');
const { pool }         = require('../../utils/database/mysql');
const { getStore, initStore } = require('../../utils/database/reckmarket_finance_mysql');

// ─────────────────────────────────────────────────────────────────────────────
//  -reckmarket-setup
//  Prefix command — run once by a Founder to initialize the store
//  Usage: -reckmarket-setup <national_id>
//  Example: -reckmarket-setup RL93497025
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  name: '-reckmarket-setup',

  async execute(client, message, args) {
    if (!message.member.roles.cache.some(role => Founders.includes(role.id))) return;

    const nationalId = args[0]?.trim().toUpperCase();

    if (!nationalId) {
      return message.reply(
        `<:Warn:1497627240177991780> | الاستخدام: \`-reckmarket-setup <الرقم الوطني>\`\nمثال: \`-reckmarket-setup RL93497025\``
      );
    }

    // Check store not already initialized
    const existing = await getStore();
    if (existing) {
      return message.reply(
        `<:No:1497627141465178132> | تم تهيئة المشروع مسبقاً — المالك: \`${existing.owner_national_id}\``
      );
    }

    // Validate national_id exists in characters
    const [charRows] = await pool.query(
      `SELECT * FROM characters WHERE national_id = ?`,
      [nationalId]
    );

    if (!charRows.length) {
      return message.reply(
        `<:No:1497627141465178132> | لم يتم العثور على شخصية بالرقم الوطني: \`${nationalId}\``
      );
    }

    const char = charRows[0];

    // Initialize store
    await initStore(char.user_id, nationalId);

    await message.reply(
      `<:Yes:1497627245873991750> | تم تهيئة Reckmarket بنجاح\n` +
      `**المالك:** ${char.firstname} ${char.lastname}\n` +
      `**الرقم الوطني:** \`${nationalId}\`\n` +
      `**Discord:** <@${char.user_id}>`
    );

    await message.delete().catch(() => {});
  },
};