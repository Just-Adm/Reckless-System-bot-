const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, StringSelectMenuBuilder, MessageFlags } = require('discord.js');
const { Vibrant } = require('node-vibrant/node');
const { Banner, Reckmarket } = require('../../JSON/images.json')
const { Founders } = require('../../JSON/roles.json')


module.exports = {
  name: '-reckmarket-panel',
  async execute(client, message, args) {
    if (!message.member.roles.cache.some(role => Founders.includes(role.id))) return;

    const thumbnail = message.guild.iconURL({ size: 256, extension: 'png' });
    const accentColor = await getAccentColor(thumbnail);

    const container = new ContainerBuilder()
      .setAccentColor(accentColor)

      // Title
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# <:Logo:1497624868827693096> | Control Panel')
      )

      // Separator
      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )

      // Description
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`> <:Control:1497627036653715637> | يمكنك من هنا إدارة مشروعك`)
      )

      // Separator
      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Large)
      )

      // Banner
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(Reckmarket)
        )
      )

      // Menu
      .addActionRowComponents(
        new ActionRowBuilder()
        .addComponents(
          new StringSelectMenuBuilder()
          .setCustomId('reckmarket-panel')
          .setPlaceholder('Select an option')
          .addOptions([
            { 
              label: 'HR Section',
              description: 'قسم الموارد البشرية',
              emoji: '<:people:1497627159341174814>',
              value: 'reckmarket-hr_section'
            },
            {
              label: 'Finance Section',
              description: 'قسم المالية',
              emoji: '<:Finance:1502348311095410849>',
              value: 'reckmarket-finance_section'
            },
            {
              label: 'Market control',
              description: 'تحكم في البقالة',
              emoji: '<:control2:1502348593120415744>',
              value: 'reckmarket-control'
            }
        ])
    )
);

    await message.channel.send({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });
    await message.delete();
  }
};

async function getAccentColor(thumbnail) {
  try {
    const palette = await Vibrant.from(thumbnail).getPalette();
    const color = palette.Vibrant?.hex || palette.DominantColor?.hex;
    if (color) return parseInt(color.replace('#', ''), 16);
  } catch {}
  return 0x2f3136;
}