const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { Vibrant } = require('node-vibrant/node');
const { Banner } = require('../../JSON/images.json');
const { Founders } = require('../../JSON/roles.json');

module.exports = {
  name: '-reckmarket',
  async execute(client, message, args) {
    if (!message.member.roles.cache.some(role => Founders.includes(role.id))) return;

    const thumbnail = message.guild.iconURL({ size: 256, extension: 'png' });
    const accentColor = await getAccentColor(thumbnail);

    const container = new ContainerBuilder()
      .setAccentColor(accentColor)

      // Title
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# <:Logo:1497624868827693096> | Reckmarket')
      )

      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )

      // Description
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `> <:market:1502345111273603234> | ريكماركت, كل منتجات يلي بدك ياها في مكان واحد وبأفضل الأسعار`
        )
      )

      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Large)
      )

      // Banner
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(Banner)
        )
      )

      // Buttons Row
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('reckmarket')
            .setLabel('Reckmarket')
            .setEmoji('<:market:1502345111273603234>')
            .setStyle(ButtonStyle.Secondary)

        ),
        
      );

    await message.channel.send({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });

    await message.delete();
  }
};

async function getAccentColor(thumbnail) {
  try {
    const palette = await Vibrant.from(thumbnail).getPalette();
    const color = palette.Vibrant?.hex || palette.Dominant?.hex;
    if (color) return parseInt(color.replace('#', ''), 16);
  } catch {}
  return 0x2f3136;
}

