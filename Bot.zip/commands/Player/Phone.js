const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { Vibrant } = require('node-vibrant/node');
const { Phone } = require('../../JSON/images.json');
const { Founders } = require('../../JSON/roles.json');

module.exports = {
  name: '-phone',
  async execute(client, message, args) {
    if (!message.member.roles.cache.some(role => Founders.includes(role.id))) return;

    const thumbnail = message.guild.iconURL({ size: 256, extension: 'png' });
    const accentColor = await getAccentColor(thumbnail);

    const container = new ContainerBuilder()

      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )

      // Buttons Row
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('playerphone-use_phone')
            .setLabel('Use Phone')
            .setStyle(ButtonStyle.Secondary)

        ),
        
      );

    await message.channel.send({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });

    await message.delete();
  }
};

async function getAccentColor(thumbnail) {
  try {
    const palette = await Vibrant.from(thumbnail).getPalette();
    const color = palette.Vibrant?.hex || palette.Dominant?.hex;
    if (color) return parseInt(color.replace('#', ''), 16);
  } catch {}
  return 0x2f3136;
}

