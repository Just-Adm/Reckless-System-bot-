const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, StringSelectMenuBuilder, MessageFlags } = require('discord.js');
const { Vibrant } = require('node-vibrant/node');
const { Banner } = require('../../JSON/images.json')
const { Founders } = require('../../JSON/roles.json')


module.exports = {
  name: '-character',
  async execute(client, message, args) {
    if (!message.member.roles.cache.some(role => Founders.includes(role.id))) return;

    const thumbnail = message.guild.iconURL({ size: 256, extension: 'png' });
    const accentColor = await getAccentColor(thumbnail);

    const container = new ContainerBuilder()
      .setAccentColor(accentColor)

      // Title
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# <:Logo:1497624868827693096> | Characters Section')
      )

      // Separator
      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )

      // Description
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`> <:people:1497627159341174814> | قسم الشخصيات, يمكنك إنشاء وإدارة شخصياتك بكل سهوله من خلال خيارات التحكم`)
      )

      // Separator
      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Large)
      )

      // Banner
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(Banner)
        )
      )

      // Menu
      .addActionRowComponents(
        new ActionRowBuilder()
        .addComponents(
          new StringSelectMenuBuilder()
          .setCustomId('characterMenu')
          .setPlaceholder('Select an option')
          .addOptions([
            { 
              label: 'Show Rules',
              description: 'عرض القوانين',
              emoji: '<:Rules:1497627188139262122>',
              value: 'character-show_rules'
            },
            {
              label: 'Select Character',
              description: 'إختيار الشخصية',
              emoji: '<:choose:1497627026708762764>',
              value: 'character-select_character'
            },
            {
              label: 'Create Character',
              description: 'إنشاء الشخصية',
              emoji: '<:Plus:1497627166966415510>',
              value: 'character-create_character'
            }
        ])
    )
);

    await message.channel.send({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });
    await message.delete();
  }
};

async function getAccentColor(thumbnail) {
  try {
    const palette = await Vibrant.from(thumbnail).getPalette();
    const color = palette.Vibrant?.hex || palette.DominantColor?.hex;
    if (color) return parseInt(color.replace('#', ''), 16);
  } catch {}
  return 0x2f3136;
}