const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { Vibrant } = require('node-vibrant/node');
const { Banner } = require('../../JSON/images.json');
const { Founders } = require('../../JSON/roles.json');

module.exports = {
  name: '-control',
  async execute(client, message, args) {
    if (!message.member.roles.cache.some(role => Founders.includes(role.id))) return;

    const thumbnail = message.guild.iconURL({ size: 256, extension: 'png' });
    const accentColor = await getAccentColor(thumbnail);

    const container = new ContainerBuilder()
      .setAccentColor(accentColor)

      // Title
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('# <:Logo:1497624868827693096> | Charatcer Control')
      )

      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )

      // Description
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `> <:Control:1497627036653715637> | التحكم في الشخصية, يمكنك التحكم في شخصيتك من خلال أزرار التحكم`
        )
      )

      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Large)
      )

      // Banner
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(Banner)
        )
      )

      // Buttons Row
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('charactercontrol-status')
            .setLabel('Status')
            .setEmoji('<:heart2:1497627082845323495>')
            .setStyle(ButtonStyle.Secondary),

          new ButtonBuilder()
            .setCustomId('charactercontrol-show_id')
            .setLabel('Show ID')
            .setEmoji('<:idcard:1497624948699824158>')
            .setStyle(ButtonStyle.Secondary),

          new ButtonBuilder()
            .setCustomId('charactercontrol-show_info')
            .setLabel('Show INFO')
            .setEmoji('<:info:1498310008817848541>')
            .setStyle(ButtonStyle.Secondary),

          new ButtonBuilder()
            .setCustomId('charactercontrol-manage_properties')
            .setLabel('Manage Properties')
            .setEmoji('<:property:1497627170183446731>')
            .setStyle(ButtonStyle.Secondary)
        )
      );

    await message.channel.send({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });

    await message.delete();
  }
};

async function getAccentColor(thumbnail) {
  try {
    const palette = await Vibrant.from(thumbnail).getPalette();
    const color = palette.Vibrant?.hex || palette.Dominant?.hex;
    if (color) return parseInt(color.replace('#', ''), 16);
  } catch {}
  return 0x2f3136;
}