const { 
    SlashCommandBuilder, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    ActionRowBuilder, 
    PermissionFlagsBits 
} = require('discord.js');

// دالة مساعدة لعمل تأخير زمني لحماية البوت من الـ Rate Limit
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dm')
        .setDescription('إرسال رسالة خاصة لجميع أعضاء السيرفر')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        // إنشاء الـ Modal
        const modal = new ModalBuilder()
            .setCustomId('dm_broadcast_modal')
            .setTitle('إرسال رسالة جماعية');

        // حقل إدخال النص
        const messageInput = new TextInputBuilder()
            .setCustomId('broadcast_message')
            .setLabel('اكتب الرسالة هنا:')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('اكتب محتوى الرسالة التي تريد إرسالها للجميع...')
            .setRequired(true);

        const firstActionRow = new ActionRowBuilder().addComponents(messageInput);
        modal.addComponents(firstActionRow);

        // إظهار الـ Modal للمستخدم
        await interaction.showModal(modal);

        // انتظار استلام البيانات من الـ Modal
        const submitted = await interaction.awaitModalSubmit({
            time: 60000,
            filter: i => i.user.id === interaction.user.id
        }).catch(() => null);

        if (!submitted) return;

        // الرد الأولي لتجنب انتهاء وقت التفاعل
        await submitted.reply({ content: '⏳ جاري جلب بيانات الأعضاء وفحص الحالات... يرجى الانتظار.', ephemeral: true });

        const messageToSend = submitted.fields.getTextInputValue('broadcast_message');
        const guild = interaction.guild;

        try {
            // جلب الأعضاء بالكامل
            const membersFetch = await guild.members.fetch();
            // تصفية البوتات
            const allMembers = membersFetch.filter(member => !member.user.bot);

            // تحديث حالة الإرسال للمشرف بالعدد الفعلي
            await submitted.editReply({ 
                content: `⏳ تم جلب \`${allMembers.size}\` عضو (بدون البوتات). جاري بدء الإرسال الآن مع نظام حماية من التقييد...` 
            });

            // تقسيم الأعضاء بناءً على الحالة (تفعيل الـ Presences مطلوب في الـ Developer Portal)
            const onlineMembers = [];
            const offlineMembers = [];

            allMembers.forEach(member => {
                const status = member.presence?.status;
                if (status && status !== 'offline') {
                    onlineMembers.push(member);
                } else {
                    offlineMembers.push(member);
                }
            });

            const sortedMembers = [...onlineMembers, ...offlineMembers];
            const totalToMessage = sortedMembers.length;

            let successCount = 0;
            let failCount = 0;
            let currentProgress = 0;

            console.log(`\x1b[36m[BROADCAST START]\x1b[0m بدء عملية الإرسال الجماعي لـ ${totalToMessage} عضو...`);
            console.log(`--------------------------------------------------`);

            for (const member of sortedMembers) {
                currentProgress++;
                try {
                    await member.send({ content: messageToSend });
                    successCount++;
                    // طباعة النجاح في الكونسول باللون الأخضر
                    console.log(`\x1b[32m[SUCCESS] (${currentProgress}/${totalToMessage})\x1b[0m تم الإرسال بنجاح إلى: ${member.user.tag} (${member.id})`);
                } catch (error) {
                    failCount++;
                    // طباعة الفشل في الكونسول باللون الأحمر
                    console.log(`\x1b[31m[FAILED] (${currentProgress}/${totalToMessage})\x1b[0m فشل الإرسال إلى: ${member.user.tag} (${member.id}) | السبب: الخاص مغلق أو حظر`);
                }

                // تأخير زمني بمقدار 1.2 ثانية (1200ms) بين كل رسالة لتفادي بند الـ Rate Limit القاسي من ديسكورد
                await sleep(1200);
            }

            // طباعة الإحصائيات النهائية في الكونسول بشكل منسق وجذاب
            console.log(`--------------------------------------------------`);
            console.log(`\x1b[35m================= الإحصائيات النهائية =================\x1b[0m`);
            console.log(`\x1b[34m• إجمالي المستهدفين:\x1b[0m ${totalToMessage}`);
            console.log(`\x1b[32m• تم الإرسال بنجاح:\x1b[0m ${successCount}`);
            console.log(`\x1b[31m• فشل الإرسال:\x1b[0m      ${failCount}`);
            console.log(`\x1b[35m======================================================\x1b[0m`);
 
            // إرسال تقرير نهائي للمشرف في الديسكورد بعد الانتهاء الكامل
            await submitted.followUp({
                content: `✅ **اكتملت عملية الإرسال الجماعي بنجاح!**\n\n• إجمالي الأعضاء المستهدفين: \`${totalToMessage}\`\n• تم الإرسال بنجاح إلى: \`${successCount}\` عضو.\n• فشل الإرسال إلى: \`${failCount}\` عضو (بسبب الخاص المغلق).`,
                ephemeral: true
            });

        } catch (error) {
            console.error('\x1b[41m\x1b[30m[CRITICAL ERROR]\x1b[0m حدث خطأ غير متوقع أثناء جلب الأعضاء أو الإرسال:', error);
            await submitted.followUp({ content: '❌ حدث خطأ غير متوقع أثناء محاولة جلب الأعضاء أو معالجة البيانات.', ephemeral: true });
        }
    }
};